MIRAS Experience 3.1.0 — Commands Pack 2
Source: mirascommands2.odt

Preserves account, verification, history, checkout support and the existing business logic.
Homepage injection is disabled when the new native MIRAS homepage sections are present to avoid duplicates.
Contact/social elements are icon-only; homepage loading avoids unnecessary cart-fragments dependencies.

MIRAS Experience 3.2.0: mobile Elementor/menu typography correction scoped to max-width 767px.
