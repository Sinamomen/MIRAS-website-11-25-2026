<?php
if(!defined('ABSPATH'))exit;
get_header();
$logo=function_exists('has_custom_logo')&&has_custom_logo()?get_custom_logo():'<a class="mxe-wordmark" href="'.esc_url(home_url('/')).'">MIRAS</a>';
echo '<main class="mxe-account"><div class="mxe-card"><div class="mxe-brand">'.$logo.'</div>';
if(!is_user_logged_in())echo '<h1 class="mxe-title">Mon compte</h1><p class="mxe-lead">Connectez-vous ou créez votre compte pour commander vos repas MIRAS.</p>';else echo '<h1 class="mxe-title">Mon espace MIRAS</h1><p class="mxe-whisper mxe-center">Votre espace, rien qu’à vous.</p>';
mxe_verification_ui();echo do_shortcode('[woocommerce_my_account]');
if(is_user_logged_in()&&function_exists('mo3_plan')&&mo3_plan())echo '<p><a class="button" href="'.esc_url(function_exists('mo3_url')?mo3_url('livraison'):wc_get_cart_url()).'">Retrouver mes repas et mes réceptions</a></p>';
echo '</div></main>';get_footer();
