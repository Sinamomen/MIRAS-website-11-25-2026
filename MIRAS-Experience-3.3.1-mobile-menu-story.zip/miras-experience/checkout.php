<?php
/* MIRAS 3.0.0 — paiement : fond ivoire, libellés clairs, mention de sécurité visible. Aucune décoration sur les champs ni les boutons. */
if(!defined('ABSPATH'))exit;
add_action('woocommerce_review_order_before_submit',function(){
 echo '<p class="mxe-secure" role="note"><svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false"><path fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" d="M6.5 10.5V8a5.5 5.5 0 0 1 11 0v2.5M5 10.5h14v10H5z"/></svg><span><strong>Paiement sécurisé</strong>'.(is_ssl()?' · connexion chiffrée (HTTPS)':'').'. Vos données bancaires sont traitées directement par notre prestataire de paiement et ne sont jamais conservées par MIRAS.</span></p>';
},5);
add_action('wp_enqueue_scripts',function(){
 if(!function_exists('is_checkout')||!is_checkout())return;
 wp_register_style('mxe-checkout',false,[],MXE_VER);wp_enqueue_style('mxe-checkout');
 wp_add_inline_style('mxe-checkout','
body.woocommerce-checkout{background-color:#fbf7f0}
body.woocommerce-checkout form.checkout{font-family:var(--mxe-f-manrope,"Manrope",system-ui,sans-serif)}
body.woocommerce-checkout form.checkout label{font-weight:600;color:#43121d;font-size:14px;letter-spacing:.01em}
body.woocommerce-checkout form.checkout .required{color:#641c2b;text-decoration:none}
body.woocommerce-checkout form.checkout :is(input.input-text,select,textarea){background:#fffdf9;border:1px solid #d9c8b0;border-radius:6px;min-height:46px;font-size:16px}
body.woocommerce-checkout form.checkout :is(input.input-text,select,textarea):focus{outline:none;border-color:#641c2b;box-shadow:0 0 0 3px rgba(100,28,43,.14)}
.mxe-secure{display:flex;gap:10px;align-items:flex-start;margin:14px 0 16px!important;padding:12px 14px;border:1px solid rgba(184,154,100,.4);border-radius:6px;background:#fffaf2;color:#43121d;font-size:13.5px;line-height:1.55;font-family:var(--mxe-f-manrope,"Manrope",system-ui,sans-serif)!important}
.mxe-secure svg{flex:0 0 auto;margin-top:2px;color:#641c2b}
.mxe-secure strong{font-weight:700}
');
},103);
