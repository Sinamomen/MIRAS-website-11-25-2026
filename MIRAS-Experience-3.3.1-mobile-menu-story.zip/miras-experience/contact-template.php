<?php
if(!defined('ABSPATH'))exit;get_header();echo '<main id="primary">';echo mxe2_contact();echo '</main>';get_footer();
