(function(){document.documentElement.classList.add('mxe-dish-ready');}());
