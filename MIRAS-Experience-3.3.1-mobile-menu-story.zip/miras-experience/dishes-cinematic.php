<?php
if(!defined('ABSPATH'))exit;
function mxe_cinematic_dishes(){
 return [
  'khoresht-morgh'=>['name'=>'Khoresht Morgh','image'=>'01-poulet-riz.webp','description'=>'Une recette généreuse, préparée avec soin.','ingredients'=>['Poulet tendre','Riz parfumé','Épices délicates']],
  'loubia-polo'=>['name'=>'Loubia Polo','image'=>'02-loobia-polo.webp','description'=>'Un mélange généreux et parfumé.','ingredients'=>['Riz parfumé','Haricots verts','Viande hachée']],
  'gheymeh'=>['name'=>'Gheymeh','image'=>'03-gheymeh.webp','description'=>'Veau mijoté, pois cassés et pommes de terre frites.','ingredients'=>['Veau mijoté','Pois cassés','Riz parfumé','Pommes de terre frites']],
  'olivieh'=>['name'=>'Olivieh','image'=>'04-olivieh.webp','description'=>'Une salade originale à partager.','ingredients'=>['Pommes de terre','Petits pois','Carottes','Œuf']],
  'mirza-ghasemi'=>['name'=>'Mirza Ghasemi','image'=>'05-mirza-ghasemi.png','description'=>'Un goût unique, à découvrir.','ingredients'=>['Aubergine fumée','Tomate','Œuf','Ail']],
 ];
}
function mxe_cinematic_dish_page($slug){
 $d=mxe_cinematic_dishes()[$slug]??null;if(!$d)return;
 $img=esc_url(get_template_directory_uri().'/assets/images/food/'.$d['image']);
 echo '<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.esc_html($d['name']).' — MIRAS</title><link rel="stylesheet" href="'.esc_url(plugins_url('dishes-cinematic.css',__FILE__)).'"></head><body class="mxe-dish-page"><main class="mxe-dish"><div class="mxe-dish-atmosphere"></div><section class="mxe-dish-stage"><figure class="mxe-dish-photo"><img src="'.$img.'" alt="'.esc_attr($d['name']).'"></figure><article class="mxe-dish-copy"><h1>'.esc_html($d['name']).'</h1><p>'.esc_html($d['description']).'</p><h2>Composition</h2><ul>';
 foreach($d['ingredients'] as $i)echo '<li>'.esc_html($i).'</li>';
 echo '</ul></article></section></main><script src="'.esc_url(plugins_url('dishes-cinematic.js',__FILE__)).'"></script></body></html>';exit;
}
add_action('template_redirect',function(){ $path=trim((string)wp_parse_url($_SERVER['REQUEST_URI']??'',PHP_URL_PATH),'/');if(str_starts_with($path,'plat/'))mxe_cinematic_dish_page(sanitize_title(substr($path,5)));},2);
