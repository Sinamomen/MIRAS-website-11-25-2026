<?php
/* MIRAS 3.0.0 — l’univers des cinq plats : photo réelle, personnalité, description, ingrédients et allergènes.
   Rien n’est supprimé : les images d’origine des produits restent enregistrées, prix et logique de commande intacts. */
if(!defined('ABSPATH'))exit;

function mxe_dishes(){return [
 'poulet'=>['label'=>'Poulet-Riz','persona'=>'Le Gentleman','tagline'=>'Un classique intemporel, plein de saveurs.','file'=>'poulet-riz.jpg',
  'alt'=>'Poulet-Riz MIRAS : morceaux de poulet en sauce tomate sur riz basmati',
  'keys'=>['poulet','morgh','chicken','khorak morgh'],
  'ing'=>'Riz basmati, poulet, tomate, oignon, huile végétale, safran, curcuma, sel, poivre.','all'=>'Aucun des 14 allergènes majeurs dans la recette type.'],
 'gheimeh'=>['label'=>'Gheimeh','persona'=>'Le Populaire','tagline'=>'Un plat généreux, qui rassemble.','file'=>'gheimeh.jpg',
  'alt'=>'Gheimeh MIRAS : bœuf, pois cassés et pommes paille sur riz au safran',
  'keys'=>['gheimeh','gheymeh','gheyme','gheime','qeymeh','qeyme','qeimeh','geymeh','ghaimeh','pois casse'],
  'ing'=>'Bœuf, pois cassés, tomate, oignon, citron séché, pommes de terre frites, riz basmati, safran, curcuma, cannelle, huile végétale, sel, poivre.','all'=>'Aucun des 14 allergènes majeurs dans la recette type.'],
 'loobia'=>['label'=>'Loobia Polo','persona'=>'Le Rebelle','tagline'=>'Un mélange audacieux de tradition et de caractère.','file'=>'loobia-polo.jpg',
  'alt'=>'Loobia Polo MIRAS : riz aux haricots verts et viande hachée, coriandre fraîche',
  'keys'=>['loobia','lubia','loubia','lobia','loubya','haricot'],
  'ing'=>'Riz basmati, viande hachée de bœuf, haricots verts, tomate, oignon, curcuma, cannelle, huile végétale, sel, poivre.','all'=>'Aucun des 14 allergènes majeurs dans la recette type.'],
 'olivier'=>['label'=>'Olivier','persona'=>'La Sociable','tagline'=>'Une salade originale, parfaite pour partager.','file'=>'olivier.jpg',
  'alt'=>'Salade Olivier MIRAS : pommes de terre, petits pois, carottes et œuf, tomate cerise au centre',
  'keys'=>['olivier','olovieh','olvieh','olivieh','salade russe'],
  'ing'=>'Pommes de terre, poulet, œufs, petits pois, carottes, cornichons, mayonnaise (œuf, huile, moutarde), sel, poivre.','all'=>'Œufs, moutarde.'],
 'mirza'=>['label'=>'Mirza Ghasemi','persona'=>'Le Mystérieux','tagline'=>'Un goût unique, à découvrir absolument.','file'=>'mirza-ghasemi.jpg',
  'alt'=>'Mirza Ghasemi MIRAS : caviar d’aubergine fumée à la tomate, noix au centre',
  'keys'=>['mirza','ghasemi','ghassemi','qasemi','bademjan','badenjan','aubergine'],
  'ing'=>'Aubergines fumées, tomates, œufs, ail, curcuma, huile végétale, sel, poivre, noix.','all'=>'Œufs, fruits à coque (noix).'],
];}
function mxe_dish_norm($s){$s=function_exists('remove_accents')?remove_accents((string)$s):(string)$s;return strtolower(trim(preg_replace('~[^a-z0-9]+~i',' ',$s)));}
function mxe_dish_products(){
 $ids=function_exists('mo_ids')?mo_ids():[];
 if(!$ids&&function_exists('wc_get_products'))$ids=wc_get_products(['limit'=>60,'status'=>'publish','return'=>'ids']);
 return array_values(array_filter(array_map('absint',(array)$ids)));
}
function mxe_dish_guess($pid){
 $p=get_post($pid);if(!$p)return '';$txt=' '.mxe_dish_norm($p->post_title.' '.$p->post_name).' ';$hits=[];
 foreach(mxe_dishes() as $k=>$d)foreach($d['keys'] as $w){if(strpos($txt,' '.mxe_dish_norm($w))!==false){$hits[$k]=1;break;}}
 if(count($hits)>1&&isset($hits['poulet']))unset($hits['poulet']); /* « poulet » peut figurer dans la composition d’un autre plat */
 return count($hits)===1?array_key_first($hits):'';
}
/* clé de plat par produit : choix manuel > association automatique */
function mxe_dish_key($pid){
 static $map=null;if($map===null)$map=(array)get_option('mxe_dish_keys',[]);
 $k=$map[(int)$pid]??'';return ($k&&$k!=='none'&&isset(mxe_dishes()[$k]))?$k:'';
}
function mxe_dish_attachment($key,$import=false){
 $att=(array)get_option('mxe_dish_att',[]);
 if(!empty($att[$key])&&get_post($att[$key]))return (int)$att[$key];
 if(!$import)return 0;
 $d=mxe_dishes()[$key]??null;if(!$d)return 0;$src=__DIR__.'/food/'.$d['file'];if(!is_readable($src))return 0;
 require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';
 $tmp=wp_tempnam($d['file']);if(!$tmp||!@copy($src,$tmp))return 0;
 $id=media_handle_sideload(['name'=>'miras-'.$d['file'],'tmp_name'=>$tmp],0,'MIRAS — '.$d['label']);
 if(is_wp_error($id)){@unlink($tmp);return 0;}
 update_post_meta($id,'_wp_attachment_image_alt',$d['alt']);
 $att[$key]=(int)$id;update_option('mxe_dish_att',$att,false);return (int)$id;
}
/* Une fois par version : association automatique (les choix manuels sont conservés) + import des nouvelles photos */
add_action('admin_init',function(){
 if(!current_user_can('manage_woocommerce')||get_option('mxe_dish_ver')===MXE_VER||!function_exists('wc_get_product'))return;
 $map=(array)get_option('mxe_dish_keys',[]);$manual=(array)get_option('mxe_dish_manual',[]);$used=[];$missing=[];
 foreach($map as $pid=>$k)if(!empty($manual[$pid])&&$k&&$k!=='none')$used[$k]=1;
 foreach(mxe_dish_products() as $pid){
  if(!empty($manual[$pid]))continue;
  $k=mxe_dish_guess($pid);if(!$k||isset($used[$k])){$missing[]=$pid;unset($map[$pid]);continue;}
  $used[$k]=1;$map[$pid]=$k;
 }
 foreach(array_unique(array_values($map)) as $k)if($k&&$k!=='none')mxe_dish_attachment($k,true);
 update_option('mxe_dish_keys',$map,false);update_option('mxe_dish_missing',$missing,false);update_option('mxe_dish_ver',MXE_VER);
 delete_option('mxe_food_map');delete_option('mxe_food_missing'); /* réglages de la 2.5.0 remplacés */
});
add_action('admin_notices',function(){
 $m=(array)get_option('mxe_dish_missing',[]);if(!$m||!current_user_can('manage_woocommerce'))return;
 echo '<div class="notice notice-warning"><p>MIRAS : certains plats n’ont pas pu être reconnus automatiquement. <a href="'.esc_url(admin_url('admin.php?page=mxe-food')).'">Vérifier les plats MIRAS</a></p></div>';
});
/* Photo affichée partout (menu, sélection, panier, boutique) — non destructif */
function mxe_dish_image_for($pid,$fallback){
 $k=mxe_dish_key($pid);if(!$k)return $fallback;$id=mxe_dish_attachment($k);return $id?:$fallback;
}
add_filter('woocommerce_product_get_image_id',function($id,$product){return is_object($product)&&method_exists($product,'get_id')?mxe_dish_image_for($product->get_id(),$id):$id;},20,2);
add_filter('post_thumbnail_id',function($id,$post){$pid=is_object($post)?$post->ID:(int)$post;return ($pid&&get_post_type($pid)==='product')?mxe_dish_image_for($pid,$id):$id;},20,2);

/* Informations du plat pour les cartes (utilisées par MIRAS Orders) */
function mxe_dish_info($pid){
 $k=mxe_dish_key($pid);$d=$k?mxe_dishes()[$k]:null;
 return ['key'=>$k,'persona'=>$d?$d['persona']:'','tagline'=>$d?$d['tagline']:'',
  'ing'=>trim((string)get_post_meta($pid,'_mxe_ingredients',true)),'all'=>trim((string)get_post_meta($pid,'_mxe_allergenes',true))];
}

/* WooCommerce → Plats MIRAS */
add_action('admin_menu',function(){add_submenu_page('woocommerce','Plats MIRAS','Plats MIRAS','manage_woocommerce','mxe-food',function(){
 if(!current_user_can('manage_woocommerce'))return;$dishes=mxe_dishes();
 if(isset($_POST['mxe_food_save'])){check_admin_referer('mxe_food');
  $map=(array)get_option('mxe_dish_keys',[]);$manual=(array)get_option('mxe_dish_manual',[]);
  foreach((array)($_POST['mxe_dish']??[]) as $pid=>$k){$pid=absint($pid);$k=sanitize_key(wp_unslash($k));if(!$pid)continue;
   if(isset($dishes[$k])){$map[$pid]=$k;mxe_dish_attachment($k,true);}else{$map[$pid]='none';}$manual[$pid]=1;}
  foreach((array)($_POST['mxe_ing']??[]) as $pid=>$v)update_post_meta(absint($pid),'_mxe_ingredients',sanitize_textarea_field(wp_unslash($v)));
  foreach((array)($_POST['mxe_all']??[]) as $pid=>$v)update_post_meta(absint($pid),'_mxe_allergenes',sanitize_textarea_field(wp_unslash($v)));
  update_option('mxe_dish_keys',$map,false);update_option('mxe_dish_manual',$manual,false);delete_option('mxe_dish_missing');
  echo '<div class="notice notice-success"><p>Plats enregistrés.</p></div>';}
 $map=(array)get_option('mxe_dish_keys',[]);
 echo '<div class="wrap"><h1>Plats MIRAS</h1><p>Photo, personnalité, ingrédients et allergènes de chaque plat. « Photo d’origine » rétablit l’image enregistrée dans le produit (elle n’est jamais supprimée). Les ingrédients et allergènes ne s’affichent sur le site que lorsqu’ils sont renseignés ici.</p>';
 echo '<p><button type="button" class="button" id="mxe-fill">Pré-remplir les champs vides avec des suggestions</button> <em>Suggestions basées sur les recettes traditionnelles : vérifiez-les avec votre recette avant d’enregistrer (information allergènes obligatoire et engageante).</em></p>';
 echo '<form method="post">';wp_nonce_field('mxe_food');
 echo '<table class="widefat striped"><thead><tr><th style="width:18%">Produit</th><th style="width:20%">Plat / photo</th><th>Ingrédients</th><th style="width:22%">Allergènes</th></tr></thead><tbody>';
 foreach(mxe_dish_products() as $pid){$p=get_post($pid);if(!$p)continue;$cur=$map[$pid]??'';$k=($cur&&$cur!=='none')?$cur:'';
  echo '<tr><td><strong>'.esc_html($p->post_title).'</strong><br><img src="'.esc_url($k?plugins_url('food/'.$dishes[$k]['file'],__FILE__):(get_the_post_thumbnail_url($pid,'thumbnail')?:'')).'" alt="" style="width:110px;height:74px;object-fit:cover;border-radius:6px;margin-top:6px"></td>';
  echo '<td><select name="mxe_dish['.$pid.']" class="mxe-dish-sel"><option value="">Photo d’origine</option>';
  foreach($dishes as $dk=>$d)echo '<option value="'.esc_attr($dk).'" data-ing="'.esc_attr($d['ing']).'" data-all="'.esc_attr($d['all']).'"'.selected($k,$dk,false).'>'.esc_html($d['label'].' — '.$d['persona']).'</option>';
  echo '</select></td><td><textarea name="mxe_ing['.$pid.']" rows="3" style="width:100%">'.esc_textarea((string)get_post_meta($pid,'_mxe_ingredients',true)).'</textarea></td>';
  echo '<td><textarea name="mxe_all['.$pid.']" rows="3" style="width:100%">'.esc_textarea((string)get_post_meta($pid,'_mxe_allergenes',true)).'</textarea></td></tr>';}
 echo '</tbody></table><p><button class="button button-primary" name="mxe_food_save" value="1">Enregistrer</button></p></form></div>';
 echo '<script>document.getElementById("mxe-fill").addEventListener("click",function(){document.querySelectorAll(".mxe-dish-sel").forEach(function(s){var o=s.selectedOptions[0],tr=s.closest("tr");if(!o||!o.dataset.ing)return;var a=tr.querySelectorAll("textarea");if(!a[0].value.trim())a[0].value=o.dataset.ing;if(!a[1].value.trim())a[1].value=o.dataset.all;});});</script>';
});});

add_action('wp_head',function(){
 echo '<style id="mxe-food-css">.product-card img,.mo-card img,.mo-photo img,.woocommerce ul.products li.product img,.mo3-cart img{object-fit:cover;object-position:50% 50%}</style>'."\n";
},20);
