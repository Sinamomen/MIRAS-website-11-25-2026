/* MIRAS Experience 2.4.0 — identité, encre, carrousel, pied de page, compte. Sans bibliothèque externe. */
(function(){
'use strict';
const D=document,W=window;
const ready=fn=>D.readyState!=='loading'?fn():D.addEventListener('DOMContentLoaded',fn);
const mq=q=>W.matchMedia?W.matchMedia(q).matches:false;
const reduce=mq('(prefers-reduced-motion: reduce)');
const conn=navigator.connection||{};
const lite=reduce||conn.saveData===true||(navigator.hardwareConcurrency&&navigator.hardwareConcurrency<=4)||(navigator.deviceMemory&&navigator.deviceMemory<=4);
const data=W.mxeData||{};
const norm=s=>(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim();
const footerEl=()=>D.querySelector('footer, .elementor-location-footer, #colophon');
if(lite)D.documentElement.classList.add('mxe-lite');

/* ------------------------------------------------------------------ *
 * Signature : diffusion d'encre bordeaux (organique, non circulaire)  *
 * ------------------------------------------------------------------ */
const Ink=(function(){
 const LV={strong:{a:.38,d:1000,n:4,s:1.05},medium:{a:.24,d:820,n:3,s:.95},soft:{a:.15,d:640,n:2,s:.8}};
 const lum=c=>{const m=(c||'').match(/[\d.]+/g);if(!m||m.length<3)return 1;if(m.length>3&&Number(m[3])===0)return null;const [r,g,b]=m.map(Number);return (.2126*r+.7152*g+.0722*b)/255;};
 const bgLum=el=>{let n=el;while(n&&n!==D.documentElement){const l=lum(getComputedStyle(n).backgroundColor);if(l!==null)return l;n=n.parentElement;}return 1;};
 const rnd=(a,b)=>a+Math.random()*(b-a);
 const shape=()=>{const v=()=>Math.round(rnd(36,64));return `${v()}% ${v()}% ${v()}% ${v()}% / ${v()}% ${v()}% ${v()}% ${v()}%`;};
 function burst(el,o){
  if(reduce||!el||!el.getBoundingClientRect)return false;o=o||{};
  if(getComputedStyle(el).borderTopLeftRadius==='0px'){const c=el.querySelector(':scope > .mo-mode-inner, :scope > .mo-pack-inner, :scope > span');if(c&&getComputedStyle(c).borderTopLeftRadius!=='0px'&&c.getBoundingClientRect().width>el.getBoundingClientRect().width*.8)el=c;}
  const lv=LV[o.level]||LV.medium,r=el.getBoundingClientRect();if(r.width<4||r.height<4||r.bottom<0||r.top>innerHeight)return false;
  const cs=getComputedStyle(el),dark=bgLum(el)<.42,rgb=dark?'243,227,207':'100,28,43';
  const host=D.createElement('span');host.className='mxe-ink-host';host.setAttribute('aria-hidden','true');
  Object.assign(host.style,{left:r.left+'px',top:r.top+'px',width:r.width+'px',height:r.height+'px',borderRadius:cs.borderRadius});
  const x=o.x!=null?o.x-r.left:r.width/2,y=o.y!=null?o.y-r.top:r.height/2;
  const R=Math.hypot(Math.max(x,r.width-x),Math.max(y,r.height-y))*lv.s;
  const n=lite?Math.min(2,lv.n):lv.n;let left=n;const done=()=>{if(--left<=0)host.remove();};
  for(let i=0;i<n;i++){
   const d=D.createElement('i'),size=R*2*(i?rnd(.45,.75):1),ang=rnd(0,Math.PI*2),dist=i?R*rnd(.15,.45):0;
   const cx=x+Math.cos(ang)*dist,cy=y+Math.sin(ang)*dist;
   Object.assign(d.style,{left:(cx-size/2)+'px',top:(cy-size/2)+'px',width:size+'px',height:size+'px',borderRadius:shape(),
    background:`radial-gradient(closest-side,rgba(${rgb},1) 0%,rgba(${rgb},.85) 38%,rgba(${rgb},.35) 66%,rgba(${rgb},0) 100%)`});
   if(!lite)d.style.filter=`blur(${Math.max(2,size*.025).toFixed(1)}px)`;
   host.append(d);
   const a=lv.a*(i?.75:1),rot=rnd(-35,35),k1=rnd(.5,.62);
   if(d.animate){const an=d.animate([{transform:`scale(.04) rotate(0deg)`,opacity:0,borderRadius:shape()},{transform:`scale(${k1}) rotate(${rot*.4}deg)`,opacity:a,offset:.3},{transform:`scale(1) rotate(${rot}deg)`,opacity:0,borderRadius:shape()}],{duration:lv.d*(1+i*.16),delay:i*85,easing:'cubic-bezier(.22,.68,.3,1)',fill:'both'});an.onfinish=done;an.oncancel=done;}
  }
  D.body.append(host);setTimeout(()=>host.remove(),lv.d*2+500);
  return true;
 }
 return {burst,lite};
})();
W.MIRASInk=Ink;

const STRONG='.elementor-button, .button, button[type=submit], input[type=submit], #place_order, .single_add_to_cart_button, .add_to_cart_button, a.btn, .btn, .mo-submit, .mo-mode-card, .mxe-cart';
const MEDIUM='.mo-pack, .mo-tier-row, .mo-counter button, .faq-q, #faq summary, .e-n-accordion-item-title, .elementor-tab-title, #mainNav a, .main-nav a, .elementor-nav-menu a, .mxe-account-icon, .product-card, .mxe-tabs button';
const SOFT='.mxe-contact-link, footer a, main a, .mo3-map-toggle';
if(!reduce){
 let lastT=0;
 D.addEventListener('pointerdown',e=>{
  if(e.button>0)return;const t=e.target;if(!(t instanceof Element))return;
  if(t.closest('.mo3-map, input[type=text], input[type=email], input[type=tel], input[type=password], textarea, select, .mxe-carousel'))return;
  const now=performance.now();if(now-lastT<90)return;lastT=now;
  let el,level;
  try{if((el=t.closest(STRONG)))level='strong';else if((el=t.closest(MEDIUM)))level='medium';else if((el=t.closest(SOFT)))level='soft';}catch(_){el=t.closest(STRONG);level='strong';}
  if(el)Ink.burst(el,{level,x:e.clientX,y:e.clientY});
 },{passive:true,capture:true});
}

/* ------------------------------------------------------------------ *
 * Notre menu : carrousel continu gauche → droite                      *
 * ------------------------------------------------------------------ */
function carousel(grid){
 const vp=D.createElement('div');vp.className='mxe-carousel';vp.setAttribute('role','region');vp.setAttribute('aria-roledescription','carrousel');vp.setAttribute('aria-label','Notre menu');
 grid.before(vp);vp.append(grid);grid.classList.add('mxe-track');
 const originals=[...grid.children];
 const arrows=D.createElement('div');arrows.className='mxe-carousel-arrows';
 const mkA=(dir,label,txt)=>{const b=D.createElement('button');b.type='button';b.className='mxe-carousel-arrow mxe-'+dir;b.setAttribute('aria-label',label);b.innerHTML='<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="'+txt+'" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';return b;};
 const prev=mkA('prev','Plats précédents','M15 5l-7 7 7 7'),next=mkA('next','Plats suivants','M9 5l7 7-7 7');arrows.append(prev,next);vp.append(arrows);
 let setW=0,step=0,offset=0,speed=0,target=0,base=0,dragging=false,hover=false,focus=false,visible=true,resumeAt=0,glide=null,lastTs=0,raf=0,vel=0;
 const gapOf=()=>parseFloat(getComputedStyle(grid).columnGap||getComputedStyle(grid).gap)||0;
 function build(){
  grid.querySelectorAll('.mxe-clone').forEach(c=>c.remove());
  const gap=gapOf();setW=originals.reduce((a,c)=>a+c.getBoundingClientRect().width+gap,0);
  if(!setW)return;step=originals[0].getBoundingClientRect().width+gap;
  const sets=Math.ceil(vp.clientWidth/setW)+2;
  const frag=D.createDocumentFragment();
  for(let k=1;k<sets;k++)originals.forEach(c=>{const x=c.cloneNode(true);x.classList.add('mxe-clone');x.setAttribute('aria-hidden','true');x.querySelectorAll('a,button,input,select,[tabindex]').forEach(el=>el.setAttribute('tabindex','-1'));x.querySelectorAll('[id]').forEach(el=>el.removeAttribute('id'));frag.append(x);});
  grid.append(frag);base=Math.max(28,Math.min(60,setW/22));if(!speed)speed=0;offset=((offset%setW)+setW)%setW;paint();
 }
 const paint=()=>{grid.style.transform=`translate3d(${(offset-setW).toFixed(2)}px,0,0)`;};
 const wrap=()=>{if(setW)offset=((offset%setW)+setW)%setW;};
 const paused=()=>dragging||hover||focus||!visible||D.hidden||performance.now()<resumeAt;
 function tick(ts){
  raf=requestAnimationFrame(tick);const dt=Math.min(.05,(ts-(lastTs||ts))/1000);lastTs=ts;if(!setW)return;
  if(glide){const k=Math.min(1,(ts-glide.t0)/420),e=1-Math.pow(1-k,3);offset=glide.from+glide.by*e;if(k>=1)glide=null;wrap();paint();return;}
  if(dragging)return;
  if(Math.abs(vel)>4){offset+=vel*dt;vel*=Math.pow(.05,dt);}else vel=0;
  target=paused()?0:base;speed+=(target-speed)*Math.min(1,dt*2.4);
  offset+=speed*dt;wrap();paint();
 }
 const hold=ms=>{resumeAt=performance.now()+(ms||2600);};
 /* drag — touch & souris ; le défilement vertical de la page reste natif (touch-action: pan-y) */
 let sx=0,sy=0,lx=0,lt=0,pid=null,moved=0,axis='';
 vp.addEventListener('pointerdown',e=>{if(e.button>0||e.target.closest('.mxe-carousel-arrow'))return;pid=e.pointerId;sx=lx=e.clientX;sy=e.clientY;lt=performance.now();moved=0;axis='';vel=0;glide=null;});
 vp.addEventListener('pointermove',e=>{if(e.pointerId!==pid)return;const dx=e.clientX-sx,dy=e.clientY-sy;
  if(!axis){if(Math.abs(dx)<6&&Math.abs(dy)<6)return;axis=Math.abs(dx)>Math.abs(dy)?'x':'y';if(axis==='x'){dragging=true;vp.classList.add('is-dragging');try{vp.setPointerCapture(pid);}catch(_){}}}
  if(axis!=='x')return;const now=performance.now(),d=e.clientX-lx;offset+=d;moved+=Math.abs(d);vel=d/Math.max(1,(now-lt))*1000*.6;lx=e.clientX;lt=now;wrap();paint();});
 const end=e=>{if(e.pointerId!==pid)return;pid=null;if(dragging){dragging=false;vp.classList.remove('is-dragging');hold(2200);}axis='';};
 vp.addEventListener('pointerup',end);vp.addEventListener('pointercancel',end);vp.addEventListener('lostpointercapture',end);
 vp.addEventListener('click',e=>{if(moved>8){e.preventDefault();e.stopPropagation();moved=0;}},true);
 vp.addEventListener('dragstart',e=>e.preventDefault());
 /* molette / trackpad : seulement les gestes horizontaux */
 vp.addEventListener('wheel',e=>{const dx=e.shiftKey&&!e.deltaX?e.deltaY:e.deltaX;if(Math.abs(dx)<=Math.abs(e.deltaY)&&!e.shiftKey)return;e.preventDefault();glide=null;vel=0;offset-=dx*(e.deltaMode===1?16:1);wrap();paint();hold(1800);},{passive:false});
 const go=dir=>{glide={from:offset,by:dir*step,t0:performance.now()};hold(3000);};
 prev.addEventListener('click',()=>go(1));next.addEventListener('click',()=>go(-1));
 vp.addEventListener('pointerenter',e=>{if(e.pointerType==='mouse')hover=true;});vp.addEventListener('pointerleave',()=>{hover=false;});
 vp.addEventListener('focusin',()=>{focus=true;});vp.addEventListener('focusout',()=>{focus=false;});
 vp.addEventListener('keydown',e=>{if(e.key==='ArrowLeft'){e.preventDefault();go(1);}else if(e.key==='ArrowRight'){e.preventDefault();go(-1);}});
 if('IntersectionObserver' in W)new IntersectionObserver(es=>es.forEach(en=>{visible=en.isIntersecting;}),{rootMargin:'120px'}).observe(vp);
 let lastW=vp.clientWidth,rt;addEventListener('resize',()=>{clearTimeout(rt);rt=setTimeout(()=>{if(vp.clientWidth!==lastW){lastW=vp.clientWidth;build();}},180);});
 originals.forEach(c=>c.querySelectorAll('img').forEach(i=>{if(!i.complete)i.addEventListener('load',()=>{const w=setW;build();if(!w)paint();},{once:true});}));
 build();raf=requestAnimationFrame(tick);
}

/* ------------------------------------------------------------------ *
 * Ornements persans discrets (coins de sections)                      *
 * ------------------------------------------------------------------ */
function ornaments(){
 const small=innerWidth<700;
 /* 3.0.0 : le lys bordeaux devient la signature ; les coins persans ne restent que sur la FAQ (moins, c’est plus). */
 const hosts=['#faq'];
 hosts.forEach((sel,i)=>{D.querySelectorAll(sel).forEach(h=>{if(h.querySelector(':scope > .mxe-corner'))return;
  if(getComputedStyle(h).position==='static')h.style.position='relative';h.classList.add('mxe-ornamented');
  const corners=small?[i%2?'tr':'tl']:(i%2?['tr','bl']:['tl','br']);
  corners.forEach(c=>{const s=D.createElement('span');s.className='mxe-corner mxe-corner-'+c;s.setAttribute('aria-hidden','true');h.prepend(s);});});});
 const f=footerEl();if(f&&!f.querySelector('.mxe-frieze')){if(getComputedStyle(f).position==='static')f.style.position='relative';const s=D.createElement('span');s.className='mxe-frieze';s.setAttribute('aria-hidden','true');f.prepend(s);}
}

/* ------------------------------------------------------------------ *
 * Pied de page : retrait « NAVIGATION » + section CONTACT premium     *
 * ------------------------------------------------------------------ */
function footer(){
 const f=footerEl();if(!f)return;
 const tw=D.createTreeWalker(f,NodeFilter.SHOW_TEXT);let n;while((n=tw.nextNode()))if(/[◎◉○◌]/.test(n.textContent))n.textContent=n.textContent.replace(/[◎◉○◌]/g,'');
 f.querySelectorAll('h1,h2,h3,h4,h5,h6,p,span,strong,div,.elementor-heading-title').forEach(el=>{if(el.children.length>1)return;if(norm(el.textContent)!=='navigation')return;
  const box=el.closest('.elementor-widget-heading')||el;const parent=box.parentElement;box.remove();if(parent&&!parent.textContent.trim()&&!parent.querySelector('img,svg,a'))parent.classList.add('mxe-empty');});
 /* e-mail */
 const mailIcon=D.querySelector('#mxe-mail-icon'),igIcon=D.querySelector('#mxe-ig-icon');
 const find=(re)=>{const w=D.createTreeWalker(f,NodeFilter.SHOW_TEXT);let t;while((t=w.nextNode()))if(re.test(t.textContent))return t;return null;};
 let mail=f.querySelector('a[href^="mailto:"]');
 if(!mail){const t=find(/mirasfood@yahoo\.com/i);if(t){const i=t.textContent.search(/mirasfood@yahoo\.com/i);const after=t.splitText(i);after.splitText('mirasfood@yahoo.com'.length);mail=D.createElement('a');mail.href='mailto:mirasfood@yahoo.com';after.replaceWith(mail);mail.append(after);}}
 if(mail&&mail.classList.contains('miras-social-icon')){mail.classList.add('mxe-contact-link','mxe-contact-mail');mail.setAttribute('aria-label','Email MIRAS');[...mail.childNodes].filter(x=>x.nodeType===3).forEach(x=>x.remove());}
 if(mail&&!mail.classList.contains('mxe-contact-link')&&!mail.classList.contains('miras-social-icon')){
  const line=mail.closest('li,p,div,span')||mail.parentElement;
  const w=D.createTreeWalker(line,NodeFilter.SHOW_TEXT);let t;const kill=[];while((t=w.nextNode()))if(/[✉📧✉️]/u.test(t.textContent)){t.textContent=t.textContent.replace(/\s*(✉️|✉|📧)\uFE0F?\s*/gu,'');}
  line.querySelectorAll('i,svg:not(.mxe-ico),.elementor-icon-list-icon').forEach(x=>{if(!x.closest('a')||x.closest('a')===mail)kill.push(x);});kill.forEach(x=>x.remove());
  mail.classList.add('mxe-contact-link','mxe-contact-mail');const txt=mail.textContent.trim();mail.textContent='';const sp=D.createElement('span');sp.textContent=txt||'mirasfood@yahoo.com';
  if(mailIcon)mail.append(mailIcon.content.cloneNode(true));mail.append(sp);line.classList.add('mxe-contact-line');
 }
 /* Instagram */
 const links=[...f.querySelectorAll('a[href*="instagram.com"]')];let ig=links[0]||null;
 if(!ig){const t=find(/@mirasfoodfr/i);if(t){const line=t.parentElement;const tpl=D.querySelector('#mxe-instagram-template');const href=tpl?tpl.content.querySelector('a').getAttribute('href'):'https://www.instagram.com/mirasfoodfr/';
   ig=D.createElement('a');ig.href=href;ig.target='_blank';ig.rel='noopener noreferrer';
   if(/instagram/i.test(norm(line.textContent))&&line.children.length===0){ig.textContent=line.textContent.trim();line.textContent='';line.append(ig);}else{const i=t.textContent.search(/@mirasfoodfr/i),a=t.splitText(i);a.splitText('@mirasfoodfr'.length);a.replaceWith(ig);ig.append(a);}}}
 if(!ig){const tpl=D.querySelector('#mxe-instagram-template');if(tpl){const p=D.createElement('p');p.append(tpl.content.cloneNode(true));const ml=mail&&mail.closest('li,p,div');if(ml)ml.after(p);else f.append(p);ig=p.querySelector('a');}}
 links.slice(1).forEach(a=>{if(norm(a.textContent).includes('mirasfoodfr')||!a.textContent.trim())a.remove();});
 if(ig&&ig.classList.contains('miras-social-icon')){ig.classList.add('mxe-contact-link','mxe-contact-ig');ig.setAttribute('aria-label','Instagram MIRAS');[...ig.childNodes].filter(x=>x.nodeType===3).forEach(x=>x.remove());}
 if(ig&&!ig.classList.contains('mxe-contact-link')&&!ig.classList.contains('miras-social-icon')){
  ig.classList.add('mxe-contact-link','mxe-contact-ig');ig.querySelectorAll('svg:not(.mxe-ico-ig),i').forEach(x=>x.remove());
  if(!ig.querySelector('.mxe-ico-ig')&&igIcon)ig.prepend(igIcon.content.cloneNode(true));
  [...ig.childNodes].filter(x=>x.nodeType===3).forEach(x=>x.remove());ig.setAttribute('aria-label','Instagram MIRAS');
  const line=ig.closest('li,p,div');if(line)line.classList.add('mxe-contact-line');
 }
 const box=(mail||ig)&&(mail||ig).closest('.elementor-column, .elementor-widget-wrap, .footer-col, .col, div');if(box)box.classList.add('mxe-contact-box');
 /* signature discrète */
 if(!f.querySelector('.mxe-signature')){const p=D.createElement('p');p.className='mxe-signature';p.tabIndex=0;p.innerHTML='<span class="mxe-signature-main">MIRAS, toujours avec vous.</span><span class="mxe-signature-secret">Les belles choses nous accompagnent.</span>';f.append(p);}
}

/* Header : icône compte */
function accountIcon(){
 if(D.querySelector('.mxe-account-icon')||D.querySelector('header .header-account'))return;const tpl=D.querySelector('#mxe-account-template');if(!tpl)return;
 D.querySelectorAll('.mxe-account-link').forEach(x=>x.remove());
 const header=D.querySelector('header, .elementor-location-header, #masthead');if(!header)return;
 const icon=tpl.content.firstElementChild.cloneNode(true);if(data.loggedIn)icon.classList.add('is-in');
 const toggle=header.querySelector('.menu-toggle, .nav-toggle, .hamburger, .burger, .elementor-menu-toggle, [aria-controls="mainNav"], button[aria-expanded]');
 const nav=header.querySelector('#mainNav, .main-nav, nav, .elementor-nav-menu--main');
 if(toggle){toggle.before(icon);}else if(nav){nav.after(icon);}else{(header.querySelector('.container, .elementor-container')||header).append(icon);}
 const host=icon.parentElement;if(host){const cs=getComputedStyle(host);if(cs.display.includes('flex'))icon.classList.add('in-flex');else{icon.classList.add('is-floating');if(getComputedStyle(header).position==='static')header.style.position='relative';if(icon.parentElement!==header)header.append(icon);}}
}

/* Phrases d’attachement, réparties avec parcimonie */
function whispers(){
 if(!D.body.classList.contains('home'))return;
 const put=(sel,text,where)=>{const s=D.querySelector(sel);if(!s||s.querySelector('.mxe-whisper'))return;const h=s.querySelector('h1,h2,.elementor-heading-title');const p=D.createElement('p');p.className='mxe-whisper';p.textContent=text;if(h&&where!=='end'){(h.closest('.elementor-widget-heading')||h).after(p);}else s.append(p);};
 put('#notre-menu','Un peu de douceur, chaque jour.');
 put('#faq','Chaque instant mérite une attention particulière.');
 const poster=D.querySelector('.mxe-poster');if(poster&&!poster.querySelector('.mxe-whisper')){const p=D.createElement('p');p.className='mxe-whisper mxe-center';p.textContent='Bien plus qu’un repas, un moment à soi.';poster.append(p);}
}

ready(()=>{
 /* textes tarifaires de l’ancienne version */
 const texts=['1–4 repas : 6,85 € chacun · 5–10 : 6,50 € · À partir de 11 : 6,25 €','Choisissez librement vos plats. Le tarif dépend de tous les repas MIRAS au panier, hors livraison.'];D.querySelectorAll('.mo > p').forEach(p=>{if(texts.includes(p.textContent.trim()))p.remove();});
 accountIcon();
 const coins=D.querySelector('.mxe-coins');if(coins){const f=footerEl();if(f)f.before(coins);}
 const cart=D.querySelector('.mxe-cart');const sync=()=>{if(cart)cart.hidden=!(Number(cart.querySelector('.mxe-cart-count')?.textContent)>0);};sync();if(W.jQuery)jQuery(D.body).on('wc_fragments_refreshed wc_fragments_loaded added_to_cart removed_from_cart updated_wc_div',sync);
 if(D.querySelector('.mxe-poster'))D.querySelectorAll('img').forEach(i=>{if(i.src.includes('/IMG_1236.jpg'))i.remove();});
 footer();
 D.querySelectorAll('.mxe-contact-link span').forEach(s=>s.remove());
 /* Mon compte : onglets */
 const login=D.querySelector('.mxe-account .u-column1'),reg=D.querySelector('.mxe-account .u-column2');
 if(login&&reg&&!D.querySelector('.mxe-tabs')){const bar=D.createElement('div');bar.className='mxe-tabs';bar.setAttribute('role','tablist');const mk=(id,label,panel)=>{const b=D.createElement('button');b.type='button';b.id=id;b.setAttribute('role','tab');b.textContent=label;panel.id=panel.id||id+'-panel';b.setAttribute('aria-controls',panel.id);return b;};const bl=mk('mxe-tab-login','Connexion',login),br=mk('mxe-tab-register','Créer un compte',reg);bar.append(bl,br);login.closest('.col2-set,#customer_login').before(bar);D.querySelector('.mxe-account').classList.add('mxe-tabbed');const show=r=>{login.hidden=r;reg.hidden=!r;bl.setAttribute('aria-selected',String(!r));br.setAttribute('aria-selected',String(r));};bl.addEventListener('click',()=>show(false));br.addEventListener('click',()=>show(true));show(location.hash==='#register');}
 /* carrousel */
 const grid=D.querySelector('#notre-menu .products-grid, #nos-repas .products-grid, .products-grid');
 if(grid&&D.body.classList.contains('home')&&grid.children.length){if(reduce)grid.classList.add('mxe-static-scroll');else carousel(grid);}
 /* FAQ */
 const items=[...D.querySelectorAll('.faq-item')];
 if(items.length){const setH=i=>{const a=i.querySelector('.faq-a');if(a)a.style.maxHeight=i.classList.contains('open')?a.scrollHeight+'px':'0px';};
  items.forEach((item,idx)=>{const q=item.querySelector('.faq-q'),a=item.querySelector('.faq-a');if(!q||!a)return;a.id=a.id||'faq-a-'+idx;q.id=q.id||'faq-q-'+idx;q.setAttribute('role','button');q.setAttribute('tabindex','0');q.setAttribute('aria-controls',a.id);q.setAttribute('aria-expanded','false');a.setAttribute('role','region');a.setAttribute('aria-labelledby',q.id);item.classList.remove('open');a.style.maxHeight='0px';
   const toggle=()=>{const open=!item.classList.contains('open');items.forEach(o=>{if(o!==item&&o.classList.contains('open')){o.classList.remove('open');o.querySelector('.faq-q')?.setAttribute('aria-expanded','false');setH(o);}});item.classList.toggle('open',open);q.setAttribute('aria-expanded',String(open));setH(item);};
   q.addEventListener('click',e=>{e.preventDefault();e.stopImmediatePropagation();toggle();},true);q.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();toggle();}});});
  addEventListener('resize',()=>items.forEach(i=>{if(i.classList.contains('open'))setH(i);}));}
 const det=[...D.querySelectorAll('#faq details')];det.forEach(d=>d.addEventListener('toggle',()=>{if(d.open)det.forEach(o=>{if(o!==d)o.open=false;});}));
 const fee='Les frais de livraison varient entre 2 € et 4 €, selon votre adresse de livraison.';
 D.querySelectorAll('.faq-item, #faq details, .e-n-accordion-item, .elementor-accordion-item').forEach(item=>{const q=item.querySelector('.faq-q, summary, .e-n-accordion-item-title, .elementor-tab-title, .elementor-accordion-title');const label=norm(q?q.textContent:'');const hit=(label.includes('frais')&&label.includes('livraison'))||(label.includes('livraison')&&(label.includes('tarif')||label.includes('prix')||label.includes('cout')));if(!hit)return;const box=item.querySelector('.faq-a, .e-n-accordion-item-content, .elementor-tab-content, .elementor-accordion-content');if(box){const p=box.querySelector('p');if(p&&box.querySelectorAll('p').length===1)p.textContent=fee;else box.textContent=fee;return;}if(item.tagName==='DETAILS'){[...item.childNodes].forEach(n=>{if(n.nodeName!=='SUMMARY')n.remove();});const p=D.createElement('p');p.textContent=fee;item.append(p);}});
 /* header au défilement */
 const header=D.querySelector('header, .elementor-location-header, #masthead');if(header){const on=()=>header.classList.toggle('mxe-scrolled',scrollY>12);on();addEventListener('scroll',on,{passive:true});}
 if(!D.querySelector('.mxe-ornament')){const host=D.querySelector('.mxe-poster')||D.querySelector('#notre-menu');if(host){const o=D.createElement('div');o.className='mxe-ornament';o.setAttribute('aria-hidden','true');host.after(o);}}
 whispers();ornaments();
 const sub=D.querySelector('.mxe-hero-sub');if(sub&&getComputedStyle(sub).textAlign==='center'){sub.style.marginLeft='auto';sub.style.marginRight='auto';}
 /* apparition douce */
 if(reduce||!('IntersectionObserver' in W))return;
 const io=new IntersectionObserver(es=>es.forEach(en=>{if(!en.isIntersecting)return;en.target.classList.add('mxe-in');io.unobserve(en.target);}),{threshold:.16,rootMargin:'0px 0px -8% 0px'});
 D.querySelectorAll('main section, .product-card, .faq-item, .elementor-widget-image, .elementor-widget-heading, .mxe-whisper').forEach((el,i)=>{if(el.closest('.mxe-carousel, .mo-menu, .mo3-cart, .woocommerce-checkout, .mxe-story'))return;if(el.getBoundingClientRect().top<innerHeight*.9)return;el.classList.add('mxe-await');el.style.transitionDelay=Math.min(i%4,3)*70+'ms';io.observe(el);});
 setTimeout(()=>D.querySelectorAll('.mxe-await:not(.mxe-in)').forEach(el=>el.classList.add('mxe-in')),2500);
});
})();
