<?php
/* MIRAS 3.0.0 — accueil : nouveau titre et texte du héros, bandeau cinématographique des fondateurs. */
if(!defined('ABSPATH'))exit;

define('MXE_HERO_TITLE','L’émotion d’un souvenir. Le goût d’un héritage.');
define('MXE_HERO_TEXT','Des repas préparés avec amour, inspirés par la tradition et imaginés pour accompagner chaque instant de votre quotidien.');

function mxe_add_class($attrs,$cls){
 if(preg_match('~\bclass=(["\'])(.*?)\1~is',$attrs))return preg_replace('~\bclass=(["\'])(.*?)\1~is','class=$1$2 '.$cls.'$1',$attrs,1);
 return $attrs.' class="'.$cls.'"';
}
/* Remplace uniquement le titre principal (premier h1 du contenu) et le paragraphe qui le suit. */
function mxe_hero_copy($html){
 if(strpos($html,'mxe-hero-title')!==false)return $html;
 $start=stripos($html,'<main');if($start===false){$start=stripos($html,'</header>');}if($start===false)$start=stripos($html,'<body');if($start===false)return $html;
 if(!preg_match_all('~<h1\b([^>]*)>(.*?)</h1>~is',$html,$all,PREG_OFFSET_CAPTURE|PREG_SET_ORDER,$start))return $html;
 foreach($all as $m){
  $attrs=$m[1][0];if(preg_match('~site-title|logo|wordmark|screen-reader~i',$attrs))continue;
  $pos=$m[0][1];$len=strlen($m[0][0]);
  $title='<span class="mxe-hl">L’émotion d’un souvenir.</span> <span class="mxe-hl">Le goût d’un héritage.</span>';
  $inner=$m[2][0];
  /* Elementor : le texte peut être dans un lien ou un span — on garde l’enveloppe */
  if(preg_match('~^(\s*<(a|span)\b[^>]*>)(.*)(</\2>\s*)$~is',$inner,$w))$newInner=$w[1].$title.$w[4];else $newInner=$title;
  $newH1='<h1'.mxe_add_class($attrs,'mxe-hero-title').'>'.$newInner.'</h1>';
  $html=substr($html,0,$pos).$newH1.substr($html,$pos+$len);
  /* paragraphe d’accompagnement : le premier <p> non vide dans les 3000 caractères suivants, avant toute nouvelle section */
  $after=$pos+strlen($newH1);$zone=substr($html,$after,3000);
  $stop=preg_match('~<(h1|h2|section)\b|id=["\']notre-menu~i',$zone,$sm,PREG_OFFSET_CAPTURE)?$sm[0][1]:strlen($zone);
  if(preg_match('~<p\b([^>]*)>(.*?)</p>~is',substr($zone,0,$stop),$pm,PREG_OFFSET_CAPTURE)){
   $txt=trim(wp_strip_all_tags($pm[2][0]));
   if($txt!==''&&mb_strlen($txt)<400&&!preg_match('~<(a|button|input)\b~i',$pm[2][0])){
    $np='<p'.mxe_add_class($pm[1][0],'mxe-hero-sub').'>'.esc_html(MXE_HERO_TEXT).'</p>';
    $html=substr($html,0,$after+$pm[0][1]).$np.substr($html,$after+$pm[0][1]+strlen($pm[0][0]));
   }
  }
  break;
 }
 return $html;
}
function mxe_founders_html(){
 $u=function($f){return esc_url(plugins_url($f,__FILE__));};
 return '<section class="mxe-founders" aria-label="Les fondateurs de MIRAS"><figure class="mxe-founders-fig"><div class="mxe-founders-cam">'
 .'<img src="'.$u('miras-fondateurs.webp').'" srcset="'.$u('miras-fondateurs-900.webp').' 900w, '.$u('miras-fondateurs.webp').' 1800w" sizes="(min-width:1300px) 1240px, 100vw" width="1800" height="1201" decoding="async" '
 .'alt="Illustration : les deux fondateurs de MIRAS, l’un en sweat à capuche noir, l’autre en costume, sur un campus universitaire où des étudiants reçoivent des repas MIRAS dans des boîtes bordeaux.">'
 .'</div><span class="mxe-founders-light" aria-hidden="true"></span></figure></section>';
}
add_shortcode('miras_fondateurs',function(){return mxe_founders_html();});
add_action('template_redirect',function(){
 if(!is_front_page()||is_admin()||isset($_GET['elementor-preview']))return;
 ob_start(function($html){
  if(get_option('mxe_hero_copy','1')==='1')$html=mxe_hero_copy($html);
  if(get_option('mxe_founders_auto','1')==='1'&&strpos($html,'class="mxe-founders"')===false&&strpos($html,'miras-heritage')===false&&strpos($html,'class="miras-home"')===false){
   foreach(['notre-menu','nos-repas','nos-abonnements'] as $id){
    $out=preg_replace_callback('~<(section|div)\b[^>]*\bid=["\x27]'.$id.'["\x27][^>]*>~i',function($m){return mxe_founders_html().$m[0];},$html,1,$n);
    if($n){$html=$out;break;}
   }
  }
  return $html;
 });
},4);
add_action('wp_enqueue_scripts',function(){
 if(!is_front_page())return;
 wp_enqueue_style('mxe-home',plugins_url('home.css',__FILE__),[],MXE_VER);
 wp_add_inline_script('mxe-lily',"(function(){var f=document.querySelector('.mxe-founders');if(!f||!('IntersectionObserver' in window))return;var r=matchMedia('(prefers-reduced-motion: reduce)').matches;var b=f.getBoundingClientRect();if(b.top>innerHeight)f.classList.add('mxe-pre');new IntersectionObserver(function(e){if(e[0].isIntersecting)f.classList.remove('mxe-pre');if(!r)f.classList.toggle('is-live',e[0].isIntersecting);},{rootMargin:'40px 0px'}).observe(f);})();");
},102);
