<?php
/* MIRAS 2.4.0 — identité : typographie, Elementor, pied de page, icônes. */
if(!defined('ABSPATH'))exit;

/* Icons ------------------------------------------------------------------ */
function mxe_icon_mail(){static $n=0;$n++;$g='mxeMailG'.$n;
 return '<svg class="mxe-ico mxe-ico-mail" viewBox="0 0 40 40" width="34" height="34" aria-hidden="true" focusable="false"><defs><linearGradient id="'.$g.'" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8a2a3c"/><stop offset="1" stop-color="#43121d"/></linearGradient></defs><circle cx="20" cy="20" r="19" fill="url(#'.$g.')"/><circle cx="20" cy="20" r="16.6" fill="none" stroke="#e8d3b0" stroke-width=".6" stroke-dasharray="1.2 1.6" opacity=".8"/><rect x="10.5" y="13.5" width="19" height="13.4" rx="2" fill="#f7f0e5"/><path d="M11 14.4l9 7.1 9-7.1" fill="none" stroke="#641c2b" stroke-width="1.4" stroke-linejoin="round"/><circle cx="20" cy="21.6" r="2.3" fill="#a3324a" stroke="#f7f0e5" stroke-width=".7"/></svg>';}
function mxe_icon_instagram(){static $n=0;$n++;$a='mxeIgA'.$n;$b='mxeIgB'.$n;
 return '<svg class="mxe-ico mxe-ico-ig" viewBox="0 0 40 40" width="34" height="34" aria-hidden="true" focusable="false"><defs><radialGradient id="'.$a.'" cx="10.6" cy="43.1" r="43" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#ffdd55"/><stop offset=".1" stop-color="#ffdd55"/><stop offset=".5" stop-color="#ff543e"/><stop offset="1" stop-color="#c837ab"/></radialGradient><radialGradient id="'.$b.'" cx="-6.8" cy="2.9" r="19" gradientTransform="matrix(.2 1 -4.1 .8 2 -4)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#3771c8"/><stop offset=".13" stop-color="#3771c8"/><stop offset="1" stop-color="#6600ff" stop-opacity="0"/></radialGradient></defs><rect width="40" height="40" rx="11" fill="url(#'.$a.')"/><rect width="40" height="40" rx="11" fill="url(#'.$b.')"/><rect x="9" y="9" width="22" height="22" rx="6.5" fill="none" stroke="#fff" stroke-width="2.6"/><circle cx="20" cy="20" r="5.3" fill="none" stroke="#fff" stroke-width="2.6"/><circle cx="26.3" cy="13.7" r="1.6" fill="#fff"/></svg>';}
function mxe_icon_account(){return '<svg class="mxe-ico-account" viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" focusable="false"><circle cx="12" cy="8.2" r="4.1" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M4.2 20.4c.9-4 4-6.2 7.8-6.2s6.9 2.2 7.8 6.2" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>';}

/* Templates used by experience.js (footer contact, header account icon) */
add_action('wp_footer',function(){
 echo '<template id="mxe-mail-icon">'.mxe_icon_mail().'</template><template id="mxe-ig-icon">'.mxe_icon_instagram().'</template>';
 echo '<template id="mxe-account-template"><a class="mxe-account-icon" href="'.esc_url(mxe_account()).'" aria-label="Mon compte" title="Mon compte">'.mxe_icon_account().'</a></template>';
},5);

/* Preload the two fonts visible above the fold */
add_action('wp_head',function(){
 foreach(['cormorant-garamond.woff2','manrope.woff2'] as $f)echo '<link rel="preload" href="'.esc_url(plugins_url('fonts/'.$f,__FILE__)).'" as="font" type="font/woff2" crossorigin>'."\n";
},2);

/* Footer: remove the "NAVIGATION" heading server-side (JS keeps a fallback). */
function mxe_strip_nav_heading($html){
 $p=stripos($html,'<footer');if($p===false)return $html;
 $head=substr($html,0,$p);$foot=substr($html,$p);
 $foot=preg_replace('~<(h[1-6]|p|div|span|strong)\b[^>]*>\s*(?:<(?:span|strong|b)\b[^>]*>\s*)?navigation\s*(?:</(?:span|strong|b)>\s*)?</\1>~iu','',$foot);
 return $head.$foot;
}
add_action('template_redirect',function(){
 if(is_admin()||wp_doing_ajax()||is_feed()||(defined('REST_REQUEST')&&REST_REQUEST)||isset($_GET['elementor-preview']))return;
 ob_start('mxe_strip_nav_heading');
},1);

/* Elementor: declare the two families and set the global typography of the active kit (once per version, with backup). */
add_filter('elementor/fonts/groups',function($g){$g['miras']='MIRAS';return $g;});
add_filter('elementor/fonts/additional_fonts',function($f){foreach(['Cormorant Garamond','Manrope'] as $n)$f[$n]='miras';return $f;});
add_action('elementor/init',function(){
 if(get_option('mxe_kit_typo')===MXE_VER)return;
 $kit=(int)get_option('elementor_active_kit');if(!$kit||!get_post($kit))return;
 $set=get_post_meta($kit,'_elementor_page_settings',true);if(!is_array($set))$set=[];
 if(!get_option('mxe_kit_typo_backup'))update_option('mxe_kit_typo_backup',['kit'=>$kit,'system_typography'=>$set['system_typography']??null],false);
 $role=function($id,$title,$family,$weight){return ['_id'=>$id,'title'=>$title,'typography_typography'=>'custom','typography_font_family'=>$family,'typography_font_weight'=>$weight];};
 $set['system_typography']=[$role('primary','Primary','Cormorant Garamond','500'),$role('secondary','Secondary','Cormorant Garamond','600'),$role('text','Text','Manrope','400'),$role('accent','Accent','Manrope','500')];
 update_post_meta($kit,'_elementor_page_settings',$set);
 update_option('mxe_kit_typo',MXE_VER);
 if(class_exists('\Elementor\Plugin')&&isset(\Elementor\Plugin::$instance->files_manager))\Elementor\Plugin::$instance->files_manager->clear_cache();
});

/* WooCommerce transactional e-mails keep the MIRAS signature */
add_action('woocommerce_email_footer',function(){echo '<p style="text-align:center;font-family:Georgia,serif;color:#641c2b;font-style:italic;margin:18px 0 0">MIRAS, toujours avec vous.</p>';},5);
