/* MIRAS 3.0.0 — lys bordeaux : placement sélectif, animations lentes uniquement à l’écran, pétales à l’ajout au panier. */
(function(){'use strict';
var D=document,W=window;
var reduce=W.matchMedia&&W.matchMedia('(prefers-reduced-motion: reduce)').matches;
var SYM={lily:['mxe-lily','0 0 230 360'],head:['mxe-lily-head','-120 -112 240 220'],petal:['mxe-petal','0 0 44 124']};
function svg(it){
 var s=SYM[it.t];var cls='mxl mxl-'+it.t+' '+(it.a==='float'?'mxl-float':'mxl-sway')+(it.sil?' mxl-sil':'');
 var st='--w:'+it.w+'px;--wm:'+(it.m||0)+'px;--o:'+it.o+';--r:'+(it.r||0)+'deg;--d:'+(it.d||19)+'s;--dl:'+(it.dl||0)+'s;'+it.p;
 return '<svg class="'+cls+'" data-m="'+(it.m?1:0)+'" style="'+st+'" viewBox="'+s[1]+'" aria-hidden="true" focusable="false"><use href="#'+s[0]+'"/></svg>';
}
var io='IntersectionObserver' in W?new IntersectionObserver(function(es){es.forEach(function(e){var f=e.target.querySelector(':scope > .mxe-flora');if(f)f.classList.toggle('on',e.isIntersecting);});},{rootMargin:'60px 0px'}):null;
function flora(host,items){
 if(!host||host.querySelector(':scope > .mxe-flora'))return;
 if(getComputedStyle(host).position==='static')host.style.position='relative';
 host.classList.add('mxe-flora-host');
 var f=D.createElement('div');f.className='mxe-flora';f.setAttribute('aria-hidden','true');f.innerHTML=items.map(svg).join('');
 host.prepend(f);if(io)io.observe(host);else f.classList.add('on');
}
function heroHost(){var h=D.querySelector('.mxe-hero-title')||D.querySelector('main h1, .elementor-location-single h1');if(!h)return null;return h.closest('.elementor-top-section, .e-con.e-parent, section, .hero')||h.parentElement;}
function init(){
 if(!D.getElementById('mxe-lily-sprite'))return;
 var home=D.body.classList.contains('home');
 if(home){
  flora(heroHost(),[{t:'lily',p:'top:-4%;right:-2%',w:300,m:120,o:.13,r:-10},{t:'petal',a:'float',p:'top:20%;right:20%',w:20,m:0,o:.22,r:20,d:26},{t:'petal',a:'float',p:'top:10%;left:7%',w:15,m:0,o:.16,r:-30,d:31,dl:-9}]);
  flora(D.querySelector('#notre-menu, #nos-repas'),[{t:'head',p:'bottom:-46px;left:-56px',w:190,m:96,o:.08,r:14,d:23}]);
  flora(D.querySelector('#nos-abonnements'),[{t:'lily',p:'top:-24px;right:-46px',w:230,m:96,o:.07,r:12,d:21},{t:'petal',a:'float',p:'top:12%;left:4%',w:16,m:0,o:.16,r:40,d:29}]);
  flora(D.querySelector('.mxe-teaser'),[{t:'lily',p:'bottom:-30px;left:-34px',w:250,m:110,o:.1,r:-6},{t:'petal',a:'float',p:'top:14%;right:9%',w:18,m:14,o:.2,r:-20,d:27}]);
 }else{
  var comp=D.querySelector('.mo-composer');if(comp&&!comp.closest('#nos-abonnements'))flora(comp,[{t:'lily',p:'top:-20px;right:-50px',w:220,m:90,o:.07,r:10}]);
 }
 flora(D.querySelector('.mo3-cart'),[{t:'petal',p:'top:14px;right:14px',w:24,m:18,o:.2,r:28}]);
 flora(D.querySelector('.mo-final'),[{t:'head',p:'bottom:-30px;left:-26px',w:96,m:76,o:.08,r:-12}]);
 flora(D.querySelector('.mxe-account .mxe-card, .mxe-contact'),[{t:'lily',p:'top:-30px;right:-44px',w:170,m:90,o:.07,r:12}]);
 flora(D.querySelector('.mxe-story-end'),[{t:'petal',a:'float',p:'top:18%;left:14%',w:18,m:14,o:.22,r:10,d:28,sil:1},{t:'petal',a:'float',p:'top:30%;right:16%',w:14,m:0,o:.18,r:-30,d:34,dl:-12,sil:1}]);
 flora(D.querySelector('.mxe-souvenirs'),[{t:'head',p:'top:-40px;right:-40px',w:160,m:90,o:.08,r:18}]);
 var foot=D.querySelector('footer, .elementor-location-footer, #colophon');
 if(foot)flora(foot,[{t:'lily',p:'bottom:-26px;right:4%',w:190,m:100,o:.1,r:-6,sil:1,d:24}]);
 /* pétales à l’ajout */
 if(reduce||!Element.prototype.animate)return;
 D.addEventListener('click',function(e){var b=e.target.closest('.mo-card [data-step="1"], .add_to_cart_button, .single_add_to_cart_button');if(!b)return;var r=b.getBoundingClientRect();burst(r.left+r.width/2,r.top+r.height/2);},true);
}
function burst(x,y){
 for(var i=0;i<3;i++){(function(i){
  var s=D.createElementNS('http://www.w3.org/2000/svg','svg');s.setAttribute('class','mxl-burst');s.setAttribute('viewBox','0 0 44 124');s.setAttribute('aria-hidden','true');
  var u=D.createElementNS('http://www.w3.org/2000/svg','use');u.setAttribute('href','#mxe-petal');s.appendChild(u);D.body.appendChild(s);
  var dx=(i-1)*26+(Math.random()*10-5),dy=-34-Math.random()*16,rot=(i-1)*50+(Math.random()*30-15);
  var a=s.animate([{transform:'translate('+x+'px,'+y+'px) rotate(0deg) scale(.4)',opacity:0},{transform:'translate('+(x+dx*.6)+'px,'+(y+dy)+'px) rotate('+rot*.6+'deg) scale(.9)',opacity:.85,offset:.35},{transform:'translate('+(x+dx)+'px,'+(y+dy+46)+'px) rotate('+rot+'deg) scale(.8)',opacity:0}],{duration:1100+i*120,easing:'cubic-bezier(.2,.7,.3,1)',fill:'forwards'});
  a.onfinish=function(){s.remove();};
 })(i);}
}
if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',init);else init();
})();
