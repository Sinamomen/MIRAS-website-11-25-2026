<?php
/* MIRAS 3.0.0 — le lys bordeaux, signature silencieuse de MIRAS (SVG léger, un seul sprite pour tout le site). */
if(!defined('ABSPATH'))exit;
function mxe_lily_svg($type='head',$class=''){
 $vb=['lily'=>'0 0 230 360','head'=>'-120 -112 240 220','petal'=>'0 0 44 124'];$id=['lily'=>'mxe-lily','head'=>'mxe-lily-head','petal'=>'mxe-petal'];
 if(!isset($vb[$type]))$type='head';
 return '<svg class="mxl-inline '.esc_attr($class).'" viewBox="'.$vb[$type].'" aria-hidden="true" focusable="false"><use href="#'.$id[$type].'"/></svg>';
}
add_action('wp_footer',function(){if(is_admin())return;$f=__DIR__.'/lily-sprite.svg';if(is_readable($f))echo file_get_contents($f)."\n";},1);
add_action('wp_enqueue_scripts',function(){
 wp_enqueue_style('mxe-lily',plugins_url('lily.css',__FILE__),[],MXE_VER);
 wp_enqueue_script('mxe-lily',plugins_url('lily.js',__FILE__),[],MXE_VER,true);
},101);
