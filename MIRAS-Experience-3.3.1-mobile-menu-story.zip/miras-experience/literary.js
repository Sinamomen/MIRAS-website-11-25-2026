(function(){document.documentElement.classList.add('mxe-literary-ready');}());
