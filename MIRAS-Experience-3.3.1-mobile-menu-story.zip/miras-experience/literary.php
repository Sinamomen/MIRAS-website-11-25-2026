<?php
if(!defined('ABSPATH'))exit;

function mxe_literary_messages(){
 return [
  ['text'=>'La fragilité de la vie n’en diminue pas la beauté ; elle lui donne son éclat.','author'=>'MIRAS — interprétation originale inspirée d’Albert Camus','book'=>'Inspirée de L’Étranger'],
  ['text'=>'Nous ne possédons pas le temps : nous lui confions seulement la lumière de nos jours.','author'=>'MIRAS — interprétation originale inspirée de Marcel Proust','book'=>'Inspirée de Du côté de chez Swann'],
  ['text'=>'Aimer, c’est reconnaître dans le silence de l’autre une maison où revenir.','author'=>'MIRAS — interprétation originale inspirée de Rumi','book'=>'Inspirée de ses œuvres poétiques'],
  ['text'=>'La solitude devient moins vaste lorsqu’un souvenir y allume une petite lampe.','author'=>'MIRAS — interprétation originale inspirée de Franz Kafka','book'=>'Inspirée de La Métamorphose'],
  ['text'=>'Il existe des matins qui ne promettent rien, et qui pourtant nous rendent le monde.','author'=>'MIRAS — interprétation originale inspirée de Friedrich Nietzsche','book'=>'Inspirée d’Ainsi parlait Zarathoustra'],
  ['text'=>'La mémoire ne garde pas les heures ; elle garde la chaleur qu’elles ont laissée.','author'=>'MIRAS — interprétation originale inspirée de Marcel Proust','book'=>'Inspirée de Le Temps retrouvé'],
  ['text'=>'Espérer n’est pas nier la nuit, mais apprendre à y marcher sans perdre son nom.','author'=>'MIRAS — interprétation originale inspirée de Victor Hugo','book'=>'Inspirée de Les Misérables'],
  ['text'=>'Une vie humaine tient parfois dans la douceur d’un geste que personne n’a vu.','author'=>'MIRAS — interprétation originale inspirée de Léon Tolstoï','book'=>'Inspirée de La Mort d’Ivan Ilitch'],
  ['text'=>'Le cœur comprend souvent avant que les mots aient trouvé leur chemin.','author'=>'MIRAS — interprétation originale inspirée de Rainer Maria Rilke','book'=>'Inspirée de Lettres à un jeune poète'],
  ['text'=>'Nous sommes faits des absences que nous avons transformées en tendresse.','author'=>'MIRAS — interprétation originale inspirée de Dostoïevski','book'=>'Inspirée de Les Frères Karamazov'],
  ['text'=>'La beauté ordinaire est une vérité qui ne demande pas à être applaudie.','author'=>'MIRAS — interprétation originale inspirée de John Keats','book'=>'Inspirée de ses poèmes'],
  ['text'=>'Quand tout paraît perdu, il reste encore la manière dont nous nous tenons auprès des autres.','author'=>'MIRAS — interprétation originale inspirée de Simone Weil','book'=>'Inspirée de La Pesanteur et la grâce'],
  ['text'=>'Le passé ne revient pas ; il change simplement de lumière dans nos yeux.','author'=>'MIRAS — interprétation originale inspirée de William Shakespeare','book'=>'Inspirée de ses sonnets'],
  ['text'=>'Un visage aimé peut devenir une patrie, même lorsque le monde nous en éloigne.','author'=>'MIRAS — interprétation originale inspirée de Dante Alighieri','book'=>'Inspirée de La Vita nuova'],
  ['text'=>'La douceur n’est pas une faiblesse : c’est une force qui a choisi de ne pas blesser.','author'=>'MIRAS — interprétation originale inspirée de Saadi','book'=>'Inspirée du Golestan'],
  ['text'=>'Le silence entre deux êtres peut être une conversation lorsque la confiance est là.','author'=>'MIRAS — interprétation originale inspirée de Hafez','book'=>'Inspirée de ses poèmes'],
  ['text'=>'Nous avançons dans le temps en emportant des fragments de maisons qui n’existent plus.','author'=>'MIRAS — interprétation originale inspirée de Virginia Woolf','book'=>'Inspirée de Mrs Dalloway'],
  ['text'=>'La peur rétrécit le monde ; une présence fidèle lui rend ses fenêtres.','author'=>'MIRAS — interprétation originale inspirée de Dostoïevski','book'=>'Inspirée de Crime et Châtiment'],
  ['text'=>'Ce qui donne un sens à la vie n’est pas toujours grand : parfois, c’est seulement rester.','author'=>'MIRAS — interprétation originale inspirée d’Albert Camus','book'=>'Inspirée de La Peste'],
  ['text'=>'Chaque adieu contient une question, et chaque souvenir lui répond à sa manière.','author'=>'MIRAS — interprétation originale inspirée de Rumi','book'=>'Inspirée de ses œuvres poétiques'],
  ['text'=>'La liberté commence lorsque nous cessons de demander au monde de nous expliquer notre cœur.','author'=>'MIRAS — interprétation originale inspirée de Jean-Paul Sartre','book'=>'Inspirée de L’Être et le Néant'],
  ['text'=>'Il faut parfois perdre le chemin pour découvrir la personne qui marchait en nous.','author'=>'MIRAS — interprétation originale inspirée de Hermann Hesse','book'=>'Inspirée de Siddhartha'],
  ['text'=>'Une joie minuscule peut survivre à des années de pluie ; il suffit de la reconnaître.','author'=>'MIRAS — interprétation originale inspirée de Emily Dickinson','book'=>'Inspirée de ses poèmes'],
  ['text'=>'Nous ne guérissons pas de l’amour ; nous apprenons à lui donner une forme habitable.','author'=>'MIRAS — interprétation originale inspirée de Rainer Maria Rilke','book'=>'Inspirée de Duino Elegies'],
  ['text'=>'Le monde est vaste, mais une table partagée sait parfois le rendre proche.','author'=>'MIRAS — interprétation originale inspirée de Gabriel García Márquez','book'=>'Inspirée de Cent ans de solitude'],
  ['text'=>'La patience est une façon de croire que la lumière travaille même derrière les murs.','author'=>'MIRAS — interprétation originale inspirée de Goethe','book'=>'Inspirée de Faust'],
  ['text'=>'Nous devenons humains dans la trace que nous laissons doucement dans la vie d’un autre.','author'=>'MIRAS — interprétation originale inspirée d’Antoine de Saint-Exupéry','book'=>'Inspirée du Petit Prince'],
  ['text'=>'La tristesse n’efface pas la beauté ; elle lui apprend parfois une profondeur nouvelle.','author'=>'MIRAS — interprétation originale inspirée de Baudelaire','book'=>'Inspirée des Fleurs du mal'],
  ['text'=>'Le présent est fragile, et c’est pour cela qu’il mérite toute notre attention.','author'=>'MIRAS — interprétation originale inspirée de Montaigne','book'=>'Inspirée des Essais'],
  ['text'=>'Il y a dans chaque rencontre une possibilité secrète de recommencer le monde.','author'=>'MIRAS — interprétation originale inspirée de Hafez','book'=>'Inspirée de ses poèmes'],
 ];
}
function mxe_literary_page(){
 $m=mxe_literary_messages()[wp_rand(0,count(mxe_literary_messages())-1)];
 $css=plugins_url('literary.css',__FILE__);$js=plugins_url('literary.js',__FILE__);
 nocache_headers();
 echo '<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Un message de MIRAS</title><link rel="stylesheet" href="'.esc_url($css).'"></head><body class="mxe-literary-page"><main class="mxe-literary"><div class="mxe-literary-particles" aria-hidden="true"></div><article class="mxe-literary-message"><p class="mxe-literary-text">'.esc_html($m['text']).'</p><p class="mxe-literary-author">— '.esc_html($m['author']).'</p><p class="mxe-literary-book">Book: '.esc_html($m['book']).'</p></article></main><script src="'.esc_url($js).'"></script></body></html>';exit;
}
add_action('template_redirect',function(){if(trim((string)wp_parse_url($_SERVER['REQUEST_URI']??'',PHP_URL_PATH),'/')==='message-de-miras')mxe_literary_page();},1);
