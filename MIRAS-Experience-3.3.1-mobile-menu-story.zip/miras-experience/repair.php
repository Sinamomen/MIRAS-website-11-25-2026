<?php
/* MIRAS 3.0.0 — réparation des liens (pages en « introuvable » / 404 sauf l’accueil).
   Cause la plus fréquente : fichier .htaccess supprimé, renommé ou modifié chez l’hébergeur (IONOS),
   ou règles de réécriture WordPress périmées. Ce module :
   1. régénère les règles WordPress (base de données + bloc « # BEGIN WordPress » du .htaccess) une fois par version ;
   2. vérifie l’état et affiche une alerte claire dans l’administration si quelque chose bloque encore ;
   3. propose un bouton « Réparer maintenant » et le contenu exact à coller si le fichier n’est pas modifiable. */
if(!defined('ABSPATH'))exit;

function mxe_rw_paths(){
 if(!function_exists('get_home_path'))require_once ABSPATH.'wp-admin/includes/file.php';
 $home=get_home_path();return ['dir'=>$home,'file'=>$home.'.htaccess'];
}
function mxe_rw_expected(){
 $base=wp_parse_url(home_url('/'),PHP_URL_PATH);$base=$base?:'/';
 return "# BEGIN WordPress\n<IfModule mod_rewrite.c>\nRewriteEngine On\nRewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]\nRewriteBase ".$base."\nRewriteRule ^index\\.php$ - [L]\nRewriteCond %{REQUEST_FILENAME} !-f\nRewriteCond %{REQUEST_FILENAME} !-d\nRewriteRule . ".rtrim($base,'/')."/index.php [L]\n</IfModule>\n# END WordPress\n";
}
/* État : structure des permaliens, présence et contenu du .htaccess */
function mxe_rw_status(){
 $p=mxe_rw_paths();$s=['structure'=>(string)get_option('permalink_structure'),'exists'=>file_exists($p['file']),'writable'=>false,'rules'=>false,'file'=>$p['file']];
 $s['writable']=$s['exists']?is_writable($p['file']):is_writable($p['dir']);
 if($s['exists']){$c=(string)@file_get_contents($p['file']);$s['rules']=(strpos($c,'# BEGIN WordPress')!==false&&preg_match('~RewriteRule\s+\.\s+\S*index\.php~',$c)===1);$s['broken_markers']=substr_count($c,'# BEGIN WordPress')!==substr_count($c,'# END WordPress');}
 return $s;
}
/* Réparation : règles en base + bloc WordPress du .htaccess (le reste du fichier, ex. réglages IONOS, est conservé) */
function mxe_rw_repair(){
 if(!function_exists('save_mod_rewrite_rules'))require_once ABSPATH.'wp-admin/includes/misc.php';
 if(!function_exists('get_home_path'))require_once ABSPATH.'wp-admin/includes/file.php';
 if(get_option('permalink_structure')===''){update_option('permalink_structure','/%postname%/');}
 global $wp_rewrite;if($wp_rewrite){$wp_rewrite->init();}
 flush_rewrite_rules(false);
 $s=mxe_rw_status();
 if(!$s['rules']||!empty($s['broken_markers'])){
  if($s['writable']){
   $c=$s['exists']?(string)@file_get_contents($s['file']):'';
   if(!empty($s['broken_markers'])||($c!==''&&strpos($c,'# BEGIN WordPress')===false&&stripos($c,'RewriteRule')!==false&&stripos($c,'index.php')!==false)){
    /* bloc WordPress cassé ou règles à moitié effacées : sauvegarde puis bloc propre en tête */
    @copy($s['file'],$s['file'].'.miras-sauvegarde-'.gmdate('Ymd-His'));
    $c=preg_replace('~# BEGIN WordPress.*?(# END WordPress|\z)~s','',$c);
   }
   if($c===''||strpos($c,'# BEGIN WordPress')===false){@file_put_contents($s['file'],mxe_rw_expected()."\n".ltrim($c));}
   save_mod_rewrite_rules();
  }
 }
 update_option('mxe_rw_checked',time(),false);
 return mxe_rw_status();
}
/* Test réel d’une page intérieure (une seule requête, mise en cache 12 h) */
function mxe_rw_probe($force=false){
 $cached=get_transient('mxe_rw_probe');if($cached!==false&&!$force)return $cached;
 $id=(int)get_option('mxe_story_page');$url=$id?get_permalink($id):'';
 if(!$url){$q=get_posts(['post_type'=>'page','post_status'=>'publish','numberposts'=>1,'exclude'=>[(int)get_option('page_on_front')],'fields'=>'ids']);$url=$q?get_permalink($q[0]):'';}
 if(!$url)return ['url'=>'','code'=>0];
 $r=wp_remote_get($url,['timeout'=>8,'redirection'=>3,'sslverify'=>false,'headers'=>['Cache-Control'=>'no-cache']]);
 $res=['url'=>$url,'code'=>is_wp_error($r)?0:(int)wp_remote_retrieve_response_code($r)];
 set_transient('mxe_rw_probe',$res,12*HOUR_IN_SECONDS);return $res;
}
/* 1. Une fois par version (et à l’activation) : réparation automatique */
add_action('admin_init',function(){
 if(!current_user_can('manage_options')||get_option('mxe_rw_ver')===MXE_VER)return;
 mxe_rw_repair();delete_transient('mxe_rw_probe');update_option('mxe_rw_ver',MXE_VER);
},5);
/* 2. Alerte si les pages intérieures restent introuvables */
add_action('admin_notices',function(){
 if(!current_user_can('manage_options'))return;
 $s=mxe_rw_status();$p=mxe_rw_probe();
 if($s['rules']&&$p['code']!==404)return;
 echo '<div class="notice notice-error"><p><strong>MIRAS : certaines pages du site risquent d’afficher « page introuvable ».</strong> ';
 echo $s['rules']?'Le fichier .htaccess est correct mais une page de test répond 404. ':'Les règles WordPress sont absentes du fichier .htaccess. ';
 echo '<a class="button button-primary" href="'.esc_url(admin_url('tools.php?page=mxe-liens')).'">Réparer les liens</a></p></div>';
});
/* 3. Outils → Réparation des liens MIRAS */
add_action('admin_menu',function(){add_management_page('Réparation des liens MIRAS','Réparation des liens','manage_options','mxe-liens',function(){
 if(!current_user_can('manage_options'))return;
 if(isset($_POST['mxe_rw_fix'])){check_admin_referer('mxe_rw');mxe_rw_repair();delete_transient('mxe_rw_probe');echo '<div class="notice notice-success"><p>Réparation effectuée.</p></div>';}
 $s=mxe_rw_status();$p=mxe_rw_probe(isset($_POST['mxe_rw_fix'])||isset($_GET['test']));
 $ok=function($b){return $b?'<span style="color:#1e7e34">✔</span>':'<span style="color:#b32d2e">✘</span>';};
 echo '<div class="wrap"><h1>Réparation des liens MIRAS</h1><p>Si toutes les pages sauf l’accueil affichent « page introuvable », le fichier <code>.htaccess</code> à la racine de WordPress est presque toujours en cause (supprimé, renommé ou modifié chez l’hébergeur).</p>';
 echo '<table class="widefat striped" style="max-width:860px"><tbody>';
 echo '<tr><td>Structure des permaliens</td><td>'.$ok($s['structure']!=='').' <code>'.esc_html($s['structure']?:'simple (?p=123)').'</code></td></tr>';
 echo '<tr><td>Fichier .htaccess présent</td><td>'.$ok($s['exists']).' <code>'.esc_html($s['file']).'</code></td></tr>';
 echo '<tr><td>Fichier modifiable par WordPress</td><td>'.$ok($s['writable']).'</td></tr>';
 echo '<tr><td>Règles WordPress présentes</td><td>'.$ok($s['rules']).'</td></tr>';
 echo '<tr><td>Test d’une page intérieure</td><td>'.$ok($p['code']>=200&&$p['code']<400).' '.($p['url']?'<a href="'.esc_url($p['url']).'" target="_blank" rel="noopener">'.esc_html($p['url']).'</a> → '.esc_html($p['code']?:'pas de réponse'):'aucune page').'</td></tr>';
 echo '</tbody></table><form method="post" style="margin:16px 0">';wp_nonce_field('mxe_rw');
 echo '<button class="button button-primary" name="mxe_rw_fix" value="1">Réparer maintenant</button> <a class="button" href="'.esc_url(admin_url('tools.php?page=mxe-liens&test=1')).'">Refaire le test</a></form>';
 if(!$s['writable']||!$s['rules']){
  echo '<h2>Réparation manuelle (IONOS)</h2><ol><li>IONOS → Hébergement → <em>Webspace</em> (explorateur de fichiers), ouvrez le dossier de WordPress (celui qui contient <code>wp-config.php</code>).</li><li>Affichez les fichiers cachés, ouvrez ou créez le fichier <code>.htaccess</code> (avec le point au début).</li><li>Collez ce bloc tout en haut, enregistrez, puis cliquez sur « Refaire le test ».</li></ol>';
  echo '<textarea readonly rows="12" style="width:100%;max-width:860px;font-family:monospace">'.esc_textarea(mxe_rw_expected()).'</textarea>';
 }
 echo '</div>';
});});
