<?php
/* MIRAS 3.0.0 — « Les souvenirs partagés » : chaque client peut confier un court souvenir.
   Publication uniquement après modération ET consentement explicite. Aucun email ni adresse IP n’est conservé. */
if(!defined('ABSPATH'))exit;

add_action('init',function(){
 register_post_type('mxe_souvenir',[
  'labels'=>['name'=>'Souvenirs partagés','singular_name'=>'Souvenir','menu_name'=>'Souvenirs','edit_item'=>'Modifier le souvenir','all_items'=>'Tous les souvenirs','search_items'=>'Rechercher','not_found'=>'Aucun souvenir pour le moment'],
  'public'=>false,'show_ui'=>true,'show_in_menu'=>true,'menu_icon'=>'dashicons-heart','menu_position'=>58,
  'supports'=>['editor','title'],'capability_type'=>'post','map_meta_cap'=>true,'show_in_rest'=>false,'exclude_from_search'=>true,
 ]);
});
function mxe_souv_consent($id){return get_post_meta($id,'_mxe_consent',true)==='1';}
function mxe_souv_successful_orders($user_id){
 if(!$user_id||!function_exists('wc_get_orders'))return 0;
 $orders=wc_get_orders(['customer_id'=>$user_id,'status'=>['wc-processing','wc-completed'],'limit'=>-1,'return'=>'ids']);
 return count(array_unique(array_map('absint',(array)$orders)));
}
function mxe_souv_eligible(){return is_user_logged_in()&&mxe_souv_successful_orders(get_current_user_id())>=3;}

/* Jamais publié sans consentement : forcé en privé */
add_filter('wp_insert_post_data',function($data,$arr){
 if(($data['post_type']??'')!=='mxe_souvenir')return $data;
 $id=(int)($arr['ID']??0);
 if($id&&$data['post_status']==='publish'&&!mxe_souv_consent($id))$data['post_status']='private';
 return $data;
},10,2);
add_action('admin_notices',function(){
 $s=function_exists('get_current_screen')?get_current_screen():null;
 if(!$s||$s->post_type!=='mxe_souvenir')return;
 echo '<div class="notice notice-info"><p><strong>Souvenirs partagés :</strong> seuls les souvenirs <em>publiés</em> dont l’auteur a donné son <em>accord</em> apparaissent sur le site. Sans accord, un souvenir publié reste automatiquement privé. Pour retirer un souvenir à la demande d’un client, placez-le simplement à la corbeille.</p></div>';
});
add_filter('manage_mxe_souvenir_posts_columns',function($c){return ['cb'=>$c['cb'],'title'=>'Prénom / titre','mxe_txt'=>'Souvenir','mxe_ok'=>'Accord de publication','date'=>$c['date']];});
add_action('manage_mxe_souvenir_posts_custom_column',function($col,$id){
 if($col==='mxe_txt')echo esc_html(wp_trim_words(get_post_field('post_content',$id),30));
 if($col==='mxe_ok')echo mxe_souv_consent($id)?'<span style="color:#1a7f37">✔ Oui</span>':'<span style="color:#a00">Non — privé</span>';
},10,2);
add_action('add_meta_boxes',function(){add_meta_box('mxe_souv_ok','Accord de publication',function($p){echo mxe_souv_consent($p->ID)?'<p>✔ La personne a accepté la publication.</p>':'<p><strong>Aucun accord</strong> : ce souvenir ne peut pas être publié.</p>';},'mxe_souvenir','side');});

/* Réception du formulaire */
function mxe_souv_back($state){
 $ref=wp_get_referer();$url=$ref?$ref:(function_exists('mxe_story_url')?mxe_story_url():home_url('/'));
 wp_safe_redirect(add_query_arg('souvenir',$state,remove_query_arg('souvenir',$url)).'#souvenirs');exit;
}
function mxe_souv_handle(){
 if(!is_user_logged_in()||!mxe_souv_eligible())mxe_souv_back('verrouille');
 if(!empty($_POST['mxe_site']))mxe_souv_back('merci'); /* pot de miel */
 if(!wp_verify_nonce($_POST['_mxe_sv']??'','mxe_souvenir'))mxe_souv_back('erreur');
 $t=(string)($_POST['mxe_t']??'');$parts=explode('.',$t);
 if(count($parts)!==2||!hash_equals(wp_hash('mxe_sv'.$parts[0]),$parts[1]))mxe_souv_back('erreur');
 $age=time()-(int)$parts[0];if($age<4||$age>DAY_IN_SECONDS)mxe_souv_back('erreur');
 $key='mxe_sv_'.substr(hash('sha256',wp_salt('nonce').(string)($_SERVER['REMOTE_ADDR']??'')),0,32);
 $n=(int)get_transient($key);if($n>=3)mxe_souv_back('limite');
 $txt=trim(sanitize_textarea_field(wp_unslash($_POST['mxe_souvenir']??'')));
 $name=trim(sanitize_text_field(wp_unslash($_POST['mxe_prenom']??'')));
 if(mb_strlen($txt)<8)mxe_souv_back('court');
 $txt=mb_substr(preg_replace('~https?://\S+~i','',$txt),0,220);$name=mb_substr($name,0,30);
 $ok=!empty($_POST['mxe_accord'])?'1':'0';
 $id=wp_insert_post(['post_type'=>'mxe_souvenir','post_status'=>'pending','post_title'=>$name!==''?$name:'Anonyme','post_content'=>$txt],true);
 if(is_wp_error($id))mxe_souv_back('erreur');
 update_post_meta($id,'_mxe_consent',$ok);update_post_meta($id,'_mxe_prenom',$name);
 set_transient($key,$n+1,HOUR_IN_SECONDS);
 mxe_souv_back('merci');
}
add_action('admin_post_nopriv_mxe_souvenir','mxe_souv_handle');
add_action('admin_post_mxe_souvenir','mxe_souv_handle');

/* Affichage */
function mxe_souvenirs_html(){
 $h='<section class="mxe-souvenirs" id="souvenirs" aria-labelledby="mxe-souv-t"><div class="mxe-souv-in">';
 $h.='<p class="mxe-souv-kicker">UNE ATTENTION PARTICULIÈRE</p><h2 class="mxe-souv-title" id="mxe-souv-t">Un souvenir, une création.</h2><p class="mxe-souv-lead">Chaque souvenir mérite une saveur unique.</p>';
 if(!mxe_souv_eligible()){
  $h.='<div class="mxe-souv-locked"><p class="mxe-souv-lock-kicker">MIRAS · EXPÉRIENCE PRIVILÉGIÉE</p><h3>Votre fidélité a une saveur particulière.</h3><p>À partir de votre troisième commande, partagez un souvenir avec nous. Notre équipe s’en inspirera pour imaginer un plat unique, pensé autour de votre histoire.</p><p><em>Une histoire. Un plat. Rien que pour vous.</em></p><strong>Cette expérience se dévoile après votre troisième commande.</strong></div></div></section>';
  return $h;
 }
 $st=isset($_GET['souvenir'])?sanitize_key($_GET['souvenir']):'';
 $msg=['merci'=>'Merci. Votre souvenir nous a bien été confié ; il sera relu avec soin par l’équipe MIRAS.','court'=>'Votre souvenir est un peu court : quelques mots de plus ?','limite'=>'Merci pour vos souvenirs. Vous pourrez en partager un autre un peu plus tard.','erreur'=>'Le souvenir n’a pas pu être envoyé. Merci de réessayer.','verrouille'=>'Cette expérience se dévoile après votre troisième commande.'];
 if(isset($msg[$st]))$h.='<p class="mxe-souv-msg mxe-souv-msg--'.esc_attr($st).'" role="status">'.esc_html($msg[$st]).'</p>';
 $tm=(string)time();
 $h.='<form class="mxe-souv-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
 $h.='<input type="hidden" name="action" value="mxe_souvenir"><input type="hidden" name="mxe_t" value="'.esc_attr($tm.'.'.wp_hash('mxe_sv'.$tm)).'">';
 if(is_user_logged_in())$h.=wp_nonce_field('mxe_souvenir','_mxe_sv',true,false);
 $h.='<div class="mxe-souv-hp" aria-hidden="true"><label for="mxe-site">Site web</label><input id="mxe-site" type="text" name="mxe_site" tabindex="-1" autocomplete="off"></div>';
 $h.='<h3 class="mxe-souv-form-title">Racontez-nous votre souvenir…</h3><label class="mxe-souv-l" for="mxe-souv-txt"><span class="screen-reader-text">Votre souvenir</span></label>';
 $h.='<textarea id="mxe-souv-txt" name="mxe_souvenir" rows="4" maxlength="220" minlength="8" required placeholder="Un goût d’enfance, une personne, une maison…"></textarea>';
 $h.='<label class="mxe-souv-l" for="mxe-souv-nom">Votre prénom (facultatif)</label><input id="mxe-souv-nom" type="text" name="mxe_prenom" maxlength="30" autocomplete="given-name">';
 $h.='<label class="mxe-souv-ok"><input type="checkbox" name="mxe_accord" value="1"> <span>J’accepte que MIRAS publie éventuellement ce souvenir avec mon prénom. Je peux demander sa suppression à <a href="mailto:mirasfood@yahoo.com">mirasfood@yahoo.com</a>.</span></label>';
 $h.='<button type="submit" class="mxe-souv-btn">Confier mon souvenir</button></form><p class="mxe-souv-priv">Une attention particulière, imaginée pour vous.</p></div></section>';
 return $h;
}
add_shortcode('miras_souvenirs',function(){if(function_exists('mxe_story_assets'))mxe_story_assets();return mxe_souvenirs_html();});
