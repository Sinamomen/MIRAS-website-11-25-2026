<?php
if(!defined('ABSPATH'))exit;
get_header();
echo '<main id="primary" class="site-main mxe-story-main">'.mxe_story_html(true).'</main>';
get_footer();
