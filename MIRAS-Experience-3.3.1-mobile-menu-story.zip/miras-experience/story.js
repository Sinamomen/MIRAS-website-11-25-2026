/* MIRAS 3.0.0 — récit « La naissance d’un héritage ».
   Sans dépendance (IntersectionObserver + requestAnimationFrame) : léger, respectueux du mouvement réduit. */
(function(){'use strict';
var W=window,D=document;
function init(){
 var root=D.querySelector('.mxe-story');if(!root||root.dataset.ready)return;root.dataset.ready='1';
 var reduce=W.matchMedia&&W.matchMedia('(prefers-reduced-motion: reduce)').matches;
 var c=navigator.connection||{};var lite=!!(c.saveData||(navigator.deviceMemory&&navigator.deviceMemory<=2));
 if(lite)root.classList.add('is-lite');
 if(!('IntersectionObserver' in W))return; /* sans IO : tout reste visible, statique */
 root.classList.add('mxe-story--js');
 var parts=[].slice.call(root.querySelectorAll('.mxe-ch,.mxe-story-end'));
 var dots=[].slice.call(root.querySelectorAll('.mxe-story-progress i'));
 /* apparition : une seule fois */
 var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('is-in');io.unobserve(e.target);}});},{threshold:.18,rootMargin:'0px 0px -6% 0px'});
 parts.forEach(function(p){
  var r=p.getBoundingClientRect();if(r.top<innerHeight*.85&&r.bottom>0)p.classList.add('is-in');else io.observe(p);
 });
 /* animations d’ambiance uniquement quand le chapitre est visible */
 var live=new IntersectionObserver(function(es){es.forEach(function(e){e.target.classList.toggle('is-live',e.isIntersecting);});},{rootMargin:'80px 0px'});
 parts.forEach(function(p){live.observe(p);});
 /* lecture : indicateur + mouvements de caméra liés au défilement */
 var onScreen=false,raf=0;
 new IntersectionObserver(function(es){onScreen=es[0].isIntersecting;root.classList.toggle('is-reading',onScreen&&es[0].intersectionRatio>0);if(onScreen)kick();},{threshold:[0,.02]}).observe(root);
 var cams=parts.map(function(p){return p.querySelector('.mxe-ch-cam');});
 var media=parts.map(function(p){return p.querySelector('.mxe-ch-media');});
 var clamp=function(v){return v<0?0:v>1?1:v;};
 var wide=function(){return innerWidth>=768;};
 function frame(){
  raf=0;if(!onScreen)return;var vh=innerHeight,active=-1,best=-1;
  for(var i=0;i<parts.length;i++){
   var r=parts[i].getBoundingClientRect();
   var vis=Math.min(r.bottom,vh)-Math.max(r.top,0);if(vis>best&&vis>vh*.25){best=vis;active=i;}
   if(!cams[i]||r.bottom<-50||r.top>vh+50)continue;
   var p=clamp((vh-r.top)/(vh+r.height)); /* 0 → entre, 1 → sort */
   parts[i].style.setProperty('--p',p.toFixed(3));
   if(reduce||lite)continue;
   var t,n=i+1;
   if(n===1)t='scale('+(1.0+.05*p).toFixed(4)+')';
   else if(n===2)t='scale('+(1.0+.06*p).toFixed(4)+')';
   else if(n===3)t='scale(1.05) translate3d('+((p-.5)*-2.4).toFixed(3)+'%,0,0)';
   else t='scale('+(1.07-.07*p).toFixed(4)+')';
   cams[i].style.transform=t;
   if(n===4)parts[i].style.setProperty('--v',clamp((p-.45)/.4).toFixed(3));
   if(media[i]){media[i].style.transform=wide()?'translate3d(0,'+((.5-p)*(n%2?-34:34)).toFixed(1)+'px,0)':'';}
  }
  dots.forEach(function(d,k){d.classList.toggle('on',k===active);});
 }
 function kick(){if(!raf)raf=requestAnimationFrame(frame);}
 addEventListener('scroll',kick,{passive:true});addEventListener('resize',kick,{passive:true});kick();
 /* si un observateur ne se déclenche pas (onglet en arrière-plan…), on montre tout */
 setTimeout(function(){parts.forEach(function(p){var r=p.getBoundingClientRect();if(r.top<innerHeight&&r.bottom>0)p.classList.add('is-in');});},3000);
}
if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',init);else init();

/* aperçu de l’accueil : ambiance seulement à l’écran */
function teaser(){var t=document.querySelector('.mxe-teaser');if(!t||!('IntersectionObserver' in window))return;if(window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches)return;new IntersectionObserver(function(es){t.classList.toggle('is-live',es[0].isIntersecting);},{rootMargin:'60px 0px'}).observe(t);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',teaser);else teaser();
})();
