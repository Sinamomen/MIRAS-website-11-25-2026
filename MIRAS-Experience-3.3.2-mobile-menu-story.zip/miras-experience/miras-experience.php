<?php
/**
 * Plugin Name: MIRAS Experience
 * Description: Complément MIRAS Orders : compte, vérification email, panier flottant, identité visuelle (Cormorant Garamond & Manrope, bordeaux & crème, lys bordeaux), page « Notre histoire », fondateurs, les cinq plats et leurs personnalités, « Les souvenirs partagés », réparation automatique des liens (erreurs 404).
 * Version: 3.3.2
 * Requires Plugins: woocommerce
 */
if(!defined('ABSPATH'))exit;
define('MXE_VER','3.3.2');
function mxe_account(){return function_exists('wc_get_page_permalink')?wc_get_page_permalink('myaccount'):home_url('/mon-compte/');}
register_activation_hook(__FILE__,function(){
 delete_option('mxe_rw_ver');delete_transient('mxe_rw_probe');
 if(!get_option('woocommerce_myaccount_page_id')||!get_post(get_option('woocommerce_myaccount_page_id'))){$p=get_page_by_path('mon-compte');$id=$p?$p->ID:wp_insert_post(['post_type'=>'page','post_status'=>'publish','post_title'=>'Mon compte','post_name'=>'mon-compte','post_content'=>'[woocommerce_my_account]']);if($id&&!is_wp_error($id))update_option('woocommerce_myaccount_page_id',$id);}
});
add_filter('pre_option_woocommerce_enable_myaccount_registration',function(){return 'yes';});
add_filter('template_include',function($template){if(function_exists('is_account_page')&&is_account_page())return plugin_dir_path(__FILE__).'account-template.php';return $template;},100);
function mxe_pending($id){return get_user_meta($id,'_mxe_pending',true)==='yes';}
function mxe_send($id){$user=get_userdata($id);if(!$user||!mxe_pending($id))return false;$token=bin2hex(random_bytes(32));update_user_meta($id,'_mxe_hash',hash('sha256',$token));update_user_meta($id,'_mxe_expiry',time()+DAY_IN_SECONDS);$url=add_query_arg(['mxe_user'=>$id,'mxe_token'=>$token],mxe_account());return wp_mail($user->user_email,'MIRAS — Confirmez votre adresse email',"Bienvenue chez MIRAS !\n\nOuvrez ce lien puis confirmez votre adresse email :\n".$url."\n\nCe lien expire dans 24 heures et ne peut être utilisé qu’une fois. Si vous n’êtes pas à l’origine de cette demande, ignorez cet email.");}
add_action('woocommerce_created_customer',function($id){if(!empty($GLOBALS['mxe_google_creating']))return;if(is_admin()&&!wp_doing_ajax())return;update_user_meta($id,'_mxe_pending','yes');mxe_send($id);},10);
add_filter('woocommerce_registration_auth_new_customer',function($allow,$id){return mxe_pending($id)?false:$allow;},99,2);
add_filter('woocommerce_registration_success_message',function($message){return 'Compte créé. Consultez votre email pour confirmer votre adresse avant de vous connecter. Vous pouvez demander un nouveau lien ci-dessous.';});
add_filter('authenticate',function($user){if($user instanceof WP_User&&mxe_pending($user->ID)&&!user_can($user,'manage_options'))return new WP_Error('mxe_pending','Confirmez votre adresse email avant de vous connecter. Un nouveau lien peut être demandé dans Mon compte.');return $user;},100);
add_filter('woocommerce_checkout_registration_enabled','__return_false');
add_action('woocommerce_checkout_process',function(){if(is_user_logged_in()&&mxe_pending(get_current_user_id()))wc_add_notice('Confirmez votre email dans Mon compte avant de poursuivre.','error');});
function mxe_token_valid($id,$token){$hash=get_user_meta($id,'_mxe_hash',true);return mxe_pending($id)&&is_string($token)&&preg_match('/^[a-f0-9]{64}$/',$token)&&$hash&&(int)get_user_meta($id,'_mxe_expiry',true)>=time()&&hash_equals($hash,hash('sha256',$token));}
add_action('template_redirect',function(){
 if(!function_exists('is_account_page')||!is_account_page())return;
 if(isset($_POST['mxe_confirm'])){check_admin_referer('mxe_confirm');$id=absint($_POST['mxe_user']??0);$token=sanitize_text_field(wp_unslash($_POST['mxe_token']??''));if(mxe_token_valid($id,$token)){delete_user_meta($id,'_mxe_pending');delete_user_meta($id,'_mxe_hash');delete_user_meta($id,'_mxe_expiry');wc_add_notice('Adresse email confirmée. Vous pouvez maintenant vous connecter.','success');}else wc_add_notice('Lien invalide ou expiré. Demandez un nouveau lien.','error');wp_safe_redirect(mxe_account());exit;}
 if(isset($_POST['mxe_resend'])){check_admin_referer('mxe_resend');$email=sanitize_email(wp_unslash($_POST['mxe_email']??''));$ip=hash('sha256',(string)($_SERVER['REMOTE_ADDR']??''));$key='mxe_r_'.hash('sha256',strtolower($email));if(!get_transient($key)&&!get_transient('mxe_ip_'.$ip)){set_transient($key,1,5*MINUTE_IN_SECONDS);set_transient('mxe_ip_'.$ip,1,MINUTE_IN_SECONDS);$u=get_user_by('email',$email);if($u&&mxe_pending($u->ID))mxe_send($u->ID);}wc_add_notice('Si un compte en attente correspond à cette adresse, un nouveau lien a été demandé. Vérifiez aussi les courriers indésirables.','success');wp_safe_redirect(mxe_account());exit;}
});
function mxe_verification_ui(){
 if(isset($_GET['mxe_token'],$_GET['mxe_user'])){$id=absint($_GET['mxe_user']);$token=sanitize_text_field(wp_unslash($_GET['mxe_token']));echo '<section class="mxe-verify"><h2>Confirmer mon email</h2>';if(mxe_token_valid($id,$token)){echo '<form method="post" action="'.esc_url(mxe_account()).'">';wp_nonce_field('mxe_confirm');echo '<input type="hidden" name="mxe_user" value="'.esc_attr($id).'"><input type="hidden" name="mxe_token" value="'.esc_attr($token).'"><button class="button" name="mxe_confirm" value="1">Confirmer mon adresse email</button></form>';}else echo '<p>Lien invalide ou expiré. Demandez un nouveau lien ci-dessous.</p>';echo '</section>';}
}
add_action('woocommerce_after_customer_login_form',function(){echo '<details class="mxe-verify"><summary>Renvoyer le lien de confirmation</summary><form method="post" action="'.esc_url(mxe_account()).'">';wp_nonce_field('mxe_resend');echo '<label for="mxe-email">Adresse email</label><input id="mxe-email" type="email" name="mxe_email" required autocomplete="email"><button class="button" name="mxe_resend" value="1">Renvoyer le lien</button></form></details>';});
add_filter('woocommerce_add_to_cart_fragments',function($parts){$n=WC()->cart?WC()->cart->get_cart_contents_count():0;$parts['span.mxe-cart-count']='<span class="mxe-cart-count">'.absint($n).'</span>';return $parts;});
add_filter('body_class',function($classes){$classes[]='mxe-premium';return $classes;});
add_action('wp_enqueue_scripts',function(){if(!function_exists('WC'))return;wp_enqueue_style('mxe-fonts',plugins_url('fonts.css',__FILE__),[],MXE_VER);wp_enqueue_style('mxe',plugins_url('experience.css',__FILE__),['mxe-fonts'],MXE_VER);$mxe_deps=is_front_page()?[]:['jquery','wc-cart-fragments'];wp_enqueue_script('mxe',plugins_url('experience.js',__FILE__),$mxe_deps,MXE_VER,true);wp_localize_script('mxe','mxeData',['account'=>mxe_account(),'cart'=>wc_get_cart_url(),'home'=>is_front_page(),'loggedIn'=>is_user_logged_in()]);},99);
add_action('wp_footer',function(){if(!function_exists('WC'))return;$n=WC()->cart?WC()->cart->get_cart_contents_count():0;echo '<a class="mxe-cart" href="'.esc_url(wc_get_cart_url()).'" aria-label="Voir mon panier">Panier · <span class="mxe-cart-count">'.absint($n).'</span></a>';});
add_shortcode('miras_coins',function(){if(!function_exists('WC'))return ''; $html='<div class="mxe-coins" aria-hidden="true">';for($i=1;$i<=3;$i++)$html.='<img class="mxe-coin mxe-coin-'.$i.'" src="'.esc_url(plugins_url('coin.png',__FILE__)).'" alt="" width="90" height="90" loading="lazy">';return $html.'</div>';});

require_once __DIR__.'/google-login.php';
require_once __DIR__.'/site-content.php';
require_once __DIR__.'/identity.php';
require_once __DIR__.'/story.php';
require_once __DIR__.'/repair.php';
require_once __DIR__.'/dishes.php';
require_once __DIR__.'/home.php';
require_once __DIR__.'/lily.php';
require_once __DIR__.'/souvenirs.php';
require_once __DIR__.'/literary.php';
require_once __DIR__.'/dishes-cinematic.php';
require_once __DIR__.'/checkout.php';
