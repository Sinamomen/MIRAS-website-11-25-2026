<?php
/* MIRAS 3.0.0 — « Notre histoire » : page dédiée (quatre chapitres) + section compacte sur l’accueil. */
if(!defined('ABSPATH'))exit;

function mxe_story_chapters(){
 return [
  ['n'=>'01','label'=>'À l’origine','img'=>'01-a-l-origine.webp','w'=>509,'h'=>764,
   'alt'=>'Peinture : un jeune couple cuisine ensemble dans une cuisine chaleureuse, une casserole fumante devant eux.',
   'title'=>'Tout héritage commence par un geste.',
   'text'=>'Avant MIRAS, il y eut une table, une attention, le désir de faire du bien à quelqu’un. Dans chaque cuisine, ces gestes simples deviennent des souvenirs que l’on emporte avec soi.'],
  ['n'=>'02','label'=>'Les souvenirs','img'=>'02-les-souvenirs.webp','w'=>503,'h'=>755,
   'alt'=>'Peinture : le couple, assis de dos, contemple un ciel étoilé au-dessus des lumières de la ville.',
   'title'=>'Les souvenirs savent franchir les distances.',
   'text'=>'La vie nous entraîne parfois sur des chemins différents. Pourtant, le parfum d’un plat peut rapprocher les époques et les lieux, faire revenir une voix, une présence, la joie d’avoir été ensemble.'],
  ['n'=>'03','label'=>'La transformation','img'=>'03-la-transformation.webp','w'=>512,'h'=>768,
   'alt'=>'Peinture : le jeune homme prépare des repas MIRAS pour de nombreuses personnes, devant des boîtes portant le logo MIRAS.',
   'title'=>'Une histoire intime, ouverte sur le monde.',
   'text'=>'Ce qui se préparait pour une personne est devenu une invitation adressée à tous. Fidèle à ses racines et ouverte à chaque rencontre, cette cuisine transforme la mémoire en partage.'],
  ['n'=>'04','label'=>'La promesse invisible','img'=>'04-la-promesse-invisible.webp','w'=>503,'h'=>755,
   'alt'=>'Peinture : une jeune femme sourit en recevant un repas MIRAS parmi ses amis ; au loin, un jeune homme la regarde.',
   'title'=>'Un sourire suffit à donner tout son sens.',
   'text'=>'Un jour, elle a reçu un repas sans en connaître l’histoire. De loin, il a vu son sourire. Il n’attendait rien de plus : seulement que la chaleur, les souvenirs et les gestes d’une histoire puissent continuer leur chemin.'],
 ];
}
function mxe_story_cta(){
 $url=function_exists('mo_composer_url')?mo_composer_url():home_url('/#notre-menu');
 return apply_filters('mxe_story_cta_url',$url);
}
function mxe_story_fx($n){
 switch($n){
  case '01':return '<span class="mxe-fx mxe-fx-glow mxe-fx-glow-1"></span><span class="mxe-fx mxe-fx-steam mxe-steam-1"><i></i><i></i><i></i></span>';
  case '02':$s='';foreach([[12,9,2],[27,18,3],[41,6,2],[58,14,2],[66,30,3],[79,8,2],[88,22,2],[35,33,2],[50,40,2],[20,44,2],[72,47,2],[93,38,2]] as $i=>$p)$s.='<i style="left:'.$p[0].'%;top:'.$p[1].'%;--d:'.(2.8+($i%5)*0.9).'s;--o:-'.($i*0.7).'s;--s:'.$p[2].'px"></i>';return '<span class="mxe-fx mxe-fx-night"></span><span class="mxe-fx mxe-fx-stars">'.$s.'</span>';
  case '03':return '<span class="mxe-fx mxe-fx-glow mxe-fx-glow-3"></span><span class="mxe-fx mxe-fx-steam mxe-steam-3"><i></i><i></i><i></i></span><span class="mxe-fx mxe-fx-crowd"></span>';
  case '04':return '<span class="mxe-fx mxe-fx-glow mxe-fx-glow-4"></span><span class="mxe-fx mxe-fx-veil"></span>';
 }
 return '';
}
/* Page dédiée « Notre histoire » : créée une seule fois, jamais écrasée */
function mxe_story_page_id(){
 $id=(int)get_option('mxe_story_page');
 if($id&&get_post_status($id)==='publish')return $id;
 $p=get_page_by_path('notre-histoire');if($p&&$p->post_status==='publish'){update_option('mxe_story_page',$p->ID,false);return (int)$p->ID;}
 return 0;
}
function mxe_story_url(){$id=mxe_story_page_id();return $id?get_permalink($id):home_url('/notre-histoire/');}
add_action('admin_init',function(){
 if(!current_user_can('publish_pages')||mxe_story_page_id())return;
 if(get_option('mxe_story_page_created'))return; /* supprimée volontairement : on ne la recrée pas */
 $id=wp_insert_post(['post_type'=>'page','post_status'=>'publish','post_title'=>'Notre histoire','post_name'=>'notre-histoire','post_content'=>'[miras_histoire]','comment_status'=>'closed'],true);
 if(!is_wp_error($id)){update_option('mxe_story_page',(int)$id,false);update_option('mxe_story_page_created',1,false);flush_rewrite_rules(false);}
});
function mxe_is_story_page(){$id=mxe_story_page_id();return $id&&is_page($id);}
/* Gabarit pleine largeur (en-tête et pied de page du thème conservés). Si la page est construite avec Elementor, on la laisse à Elementor. */
add_filter('template_include',function($t){
 if(!mxe_is_story_page())return $t;
 if(get_post_meta(get_queried_object_id(),'_elementor_edit_mode',true)==='builder')return $t;
 return __DIR__.'/story-template.php';
},99);
add_filter('body_class',function($c){if(mxe_is_story_page())$c[]='mxe-story-page';return $c;});
add_filter('document_title_parts',function($t){if(mxe_is_story_page())$t['title']='Notre histoire — La naissance d’un héritage';return $t;});

function mxe_story_html($page=false){
 $base=plugins_url('story/',__FILE__);$h='<section class="mxe-story'.($page?' mxe-story--page':'').'" id="notre-histoire" aria-labelledby="mxe-story-heading">';
 if($page)$h.='<div class="mxe-story-intro"><h1 id="mxe-story-heading" class="mxe-story-kicker mxe-story-h1">Notre histoire</h1><p class="mxe-story-heading">La naissance d’un héritage</p></div>';
 else $h.='<div class="mxe-story-intro"><p class="mxe-story-kicker">Notre histoire</p><h2 id="mxe-story-heading" class="mxe-story-heading">La naissance d’un héritage</h2></div>';
 foreach(mxe_story_chapters() as $i=>$c){
  $h.='<article class="mxe-ch mxe-ch-'.$c['n'].'" data-ch="'.($i+1).'" aria-labelledby="mxe-ch-t'.$c['n'].'">';
  $h.='<figure class="mxe-ch-media"><div class="mxe-ch-frame" style="aspect-ratio:'.$c['w'].'/'.$c['h'].'"><div class="mxe-ch-cam"><img src="'.esc_url($base.$c['img']).'" width="'.$c['w'].'" height="'.$c['h'].'" alt="'.esc_attr($c['alt']).'" '.($i===0&&$page?'fetchpriority="high"':'loading="lazy"').' decoding="async"></div>'.mxe_story_fx($c['n']).'</div></figure>';
  $h.='<div class="mxe-ch-text"><p class="mxe-ch-label"><span class="mxe-ch-num">'.$c['n'].'</span><span class="mxe-ch-dash" aria-hidden="true"></span>'.esc_html($c['label']).'</p>';
  $h.='<h'.($page?'2':'3').' class="mxe-ch-title" id="mxe-ch-t'.$c['n'].'">'.wp_kses($c['title'],['em'=>[]]).'</h'.($page?'2':'3').'><p class="mxe-ch-body">'.esc_html($c['text']).'</p></div></article>';
 }
 $h.='<div class="mxe-story-end" data-ch="5"><span class="mxe-end-lily" aria-hidden="true">'.(function_exists('mxe_lily_svg')?mxe_lily_svg('head'):'').'</span><div class="mxe-end-inner">';
 $h.='<p class="mxe-end-brand">MIRAS</p><p class="mxe-end-l1">Plus qu’un repas.</p><p class="mxe-end-l2"><em>Un héritage.</em></p>';
 $h.='<span class="mxe-end-rule" aria-hidden="true"></span><p class="mxe-end-l3">Né d’un souvenir. Fait pour être partagé.</p>';
 $h.='<p class="mxe-end-final"><em>Certaines histoires ne se racontent pas. Elles se transmettent.</em></p>';
 $h.='<a class="mxe-end-cta" href="'.esc_url(mxe_story_cta()).'">Découvrir MIRAS</a></div></div>';
 $h.='<nav class="mxe-story-progress" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></nav>';
 $h.='</section>';
 if($page&&function_exists('mxe_souvenirs_html'))$h.=mxe_souvenirs_html();
 return $h;
}
function mxe_story_assets(){
 wp_enqueue_style('mxe-story',plugins_url('story.css',__FILE__),[],MXE_VER);
 wp_enqueue_script('mxe-story',plugins_url('story.js',__FILE__),[],MXE_VER,true);
}
add_shortcode('miras_histoire',function(){mxe_story_assets();return mxe_story_html(true);});

/* Accueil : section compacte (une illustration, une courte introduction, « En savoir plus ») */
function mxe_story_teaser(){
 $img=plugins_url('story/01-a-l-origine.webp',__FILE__);
 return '<section class="mxe-teaser" id="notre-histoire-accueil" aria-labelledby="mxe-teaser-t"><div class="mxe-teaser-in">'
 .'<figure class="mxe-teaser-media"><div class="mxe-ch-frame mxe-teaser-frame" style="aspect-ratio:509/764"><div class="mxe-ch-cam"><img src="'.esc_url($img).'" width="509" height="764" loading="lazy" decoding="async" alt="Peinture : un jeune couple cuisine ensemble dans une cuisine chaleureuse, une casserole fumante devant eux."></div>'.mxe_story_fx('01').'</div></figure>'
 .'<div class="mxe-teaser-text"><p class="mxe-teaser-kicker">Notre histoire</p><h2 class="mxe-teaser-title" id="mxe-teaser-t">La naissance d’un héritage</h2>'
 .'<p class="mxe-teaser-body">Avant d’être un nom, MIRAS était un souvenir : une cuisine, deux cœurs et des repas préparés avec tendresse. Une histoire d’amour devenue une promesse, partagée aujourd’hui à chaque repas.</p>'
 .'<a class="mxe-teaser-link" href="'.esc_url(mxe_story_url()).'">En savoir plus<span aria-hidden="true"></span></a></div></div></section>';
}
/* The homepage no longer injects the Notre histoire teaser. The dedicated /notre-histoire/ page remains available. */
add_action('wp_enqueue_scripts',function(){
 $p=get_post();
 if(mxe_is_story_page()||($p&&has_shortcode((string)$p->post_content,'miras_histoire')))mxe_story_assets();
},100);
