<?php
/**
 * Plugin Name: MIRAS Orders
 * Description: Sélection de repas, préparation de commande et checkout WooCommerce avec paiement réel via les passerelles configurées.
 * Version: 4.5.1
 * Requires Plugins: woocommerce
 */
if(!defined('ABSPATH')) exit;

function mo_ids(){return array_values(array_filter(array_map('absint',explode(',',get_option('mo_ids','')))));}
function mo_dish_image_asset($product){
 $name=strtolower(remove_accents(wp_strip_all_tags($product->get_name())));
 $map=[
  'mirza ghasemi'=>'mirza-ghasemi.png',
  'olivieh'=>'olivieh.webp',
  'loobia polo'=>'loobia-polo.webp',
  'lubia polo'=>'loobia-polo.webp',
  'gheymeh'=>'gheymeh.webp',
  'poulet riz'=>'poulet-riz.webp',
  'khoresh morgh'=>'poulet-riz.webp',
 ];
 foreach($map as $needle=>$file){
  if(strpos($name,$needle)!==false)return plugins_url('food/'.$file,__FILE__);
 }
 return '';
}
add_filter('woocommerce_product_get_image','mo_dish_product_image',10,6);
function mo_dish_product_image($image,$product,$size,$attr,$placeholder,$image_class){
 $asset=mo_dish_image_asset($product);
 if(!$asset)return $image;
 $attrs=is_array($attr)?$attr:[];
 $attrs['src']=$asset;
 $attrs['alt']=$attrs['alt']??$product->get_name();
 $attrs['loading']=$attrs['loading']??'lazy';
 $attrs['decoding']='async';
 $html='<img';
 foreach($attrs as $key=>$value)$html.=' '.esc_attr($key).'="'.esc_attr(is_array($value)?implode(' ',array_filter($value)): (string)$value).'"';
 return $html.'>';
}
function mo_mode(){if(!function_exists('WC')||!WC()->session)return 'libre';return WC()->session->get('mo_mode')==='abonnement'?'abonnement':'libre';}
function mo_pack(){if(!function_exists('WC')||!WC()->session)return 0;$p=(int)WC()->session->get('mo_pack',0);return in_array($p,[1,5,10],true)?$p:0;}
function mo_rate($q){$q=(int)$q;if(mo_mode()==='abonnement'){$p=mo_pack();if($p===10&&$q===$p)return 6.25;if($p===5&&$q===$p)return 6.50;if($p===1&&$q===$p)return 6.85;}return $q>=10?6.25:($q>=5?6.50:6.85);}
function mo_qty(){ $n=0; if(function_exists('WC')&&WC()->cart) foreach(WC()->cart->get_cart() as $i) if(in_array($i['product_id'],mo_ids(),true)) $n+=(int)$i['quantity']; return $n; }
function mo_price_parts(){$q=mo_qty();$base=0.0;$after=0.0;$lines=[];if(function_exists('WC')&&WC()->cart){foreach(WC()->cart->get_cart() as $key=>$item){$n=(int)$item['quantity'];$lines[$key]=['qty'=>$n,'name'=>$item['data']->get_name(),'unit'=>WC()->cart->get_product_price($item['data']),'subtotal'=>WC()->cart->get_product_subtotal($item['data'],$n)];if(!in_array($item['product_id'],mo_ids(),true))continue;$base+=(float)wc_get_price_to_display($item['data'],['price'=>6.85,'qty'=>$n]);$after+=(float)wc_get_price_to_display($item['data'],['price'=>mo_rate($q),'qty'=>$n]);}}$saved=max(0,$base-$after);return ['qty'=>$q,'base'=>round($base,2),'saved'=>round($saved,2),'after'=>round($after,2),'mode'=>mo_mode(),'pack'=>mo_pack(),'rate'=>mo_rate($q),'lines'=>$lines,'base_html'=>wc_price($base),'saved_html'=>wc_price($saved),'after_html'=>wc_price($after)];}
add_action('admin_menu',function(){add_submenu_page('woocommerce','MIRAS','MIRAS','manage_woocommerce','miras-orders',function(){
if(!current_user_can('manage_woocommerce'))return;
if(isset($_POST['mo_save'])){check_admin_referer('mo_settings'); foreach(['mo_ids','mo_point1','mo_point2','mo_map1','mo_map2'] as $k) update_option($k,sanitize_text_field(wp_unslash($_POST[$k]??'')));}
echo '<div class="wrap"><h1>MIRAS — Configuration</h1><p>Indiquez les ID exacts des cinq produits repas. Aucun autre produit ne reçoit la remise. Configurez les zones WooCommerce avec livraison à tarif fixe (3 à 5 €) avant ouverture.</p><form method="post">';wp_nonce_field('mo_settings');foreach(['mo_ids'=>'ID des cinq repas, séparés par des virgules','mo_point1'=>'Adresse Lyon 1','mo_point2'=>'Adresse Lyon 2 / Lyon 3','mo_map1'=>'Lien Google Maps Lyon 1','mo_map2'=>'Lien Google Maps Lyon 2 / Lyon 3'] as $k=>$l)echo '<p><label>'.esc_html($l).'<br><input style="width:90%" name="'.$k.'" value="'.esc_attr(get_option($k,'')).'"></label></p>';echo '<button class="button button-primary" name="mo_save">Enregistrer</button></form><p>Shortcode sélection : [miras_composer]. Shortcode accueil : [miras_menu]. Désactivez les anciens plugins de remise et MIRAS Core avant test.</p></div>';
});});
add_action('woocommerce_before_calculate_totals',function($cart){if(is_admin()&&!wp_doing_ajax())return;$q=mo_qty();foreach($cart->get_cart() as $i)if(in_array($i['product_id'],mo_ids(),true))$i['data']->set_price(mo_rate($q));},30);

function mo_composer_url(){return home_url('/composez-votre-commande/');}
add_shortcode('miras_menu',function(){if(!function_exists('wc_get_product'))return '';ob_start();echo '<div class="products-grid">';foreach(mo_ids() as $id){$p=wc_get_product($id);if(!$p||!$p->is_visible())continue;$dish_url=home_url('/plat/'.sanitize_title($p->get_name()).'/');echo '<article class="product-card">'.$p->get_image('medium').'<div class="product-body"><h3>'.esc_html($p->get_name()).'</h3><p>À partir de 6,25 € / repas</p><a class="btn btn-primary" href="'.esc_url($dish_url).'">Voir</a></div></article>';}echo '</div>';return ob_get_clean();});
function mo_fr($n){return number_format((float)$n,2,',',' ').'&nbsp;€';}
add_filter('woocommerce_product_get_short_description','mo_dish_descriptions',20,2);
function mo_dish_descriptions($description,$product){
 $name=strtolower(remove_accents(wp_strip_all_tags($product->get_name())));
 if(strpos($name,'gheymeh')!==false||strpos($name,'gheime')!==false||strpos($name,'qeymeh')!==false){
  return 'Veau mijoté, pois cassés, riz parfumé et lentilles frites.';
 }
 return $description;
}
add_shortcode('miras_composer',function(){
 if(!function_exists('WC'))return '<p>Veuillez activer WooCommerce.</p>';
 $products=[];foreach(mo_ids() as $id){$p=wc_get_product($id);if($p&&$p->is_purchasable()&&$p->is_in_stock())$products[$id]=$p;}
 $selected=absint($_GET['plat']??0);$featured=isset($products[$selected]);
 $req=isset($_GET['mode'])?sanitize_key(wp_unslash($_GET['mode'])):'';
 $mode=in_array($req,['abonnement','libre'],true)?$req:'';
 $pack=absint($_GET['pack']??0);if($mode!=='abonnement'||!in_array($pack,[1,5,10],true))$pack=0;
 $existing=mo_mode()==='libre'?mo_qty():0;
 ob_start();
 echo '<section class="mo mo-composer"><h1 class="mo-title">Composez votre commande</h1><p class="mxe-whisper mo-whisper">La chaleur des souvenirs, au rythme de vos journées.</p>';
 if(!$products){echo '<p>Aucun repas disponible actuellement.</p>';if(current_user_can('manage_woocommerce'))echo '<p>Vérifiez les ID dans WooCommerce → MIRAS.</p>';echo '</section>';return ob_get_clean();}
 if(function_exists('wc_print_notices'))wc_print_notices();
 echo '<form class="mo-form" method="post" action="'.esc_url(add_query_arg($featured?['plat'=>$selected]:[],mo_composer_url())).'" data-mode="'.esc_attr($mode).'" data-pack="'.esc_attr($pack).'" data-existing="'.esc_attr($existing).'">';wp_nonce_field('mo_add');
 echo '<ol class="mo-steps" aria-label="Étapes de commande"><li data-step-label="1">01 — Votre formule</li><li data-step-label="2">02 — Vos plats</li><li data-step-label="3">03 — Récapitulatif</li></ol>';
 /* 1. Two choices only */
 echo '<fieldset class="mo-modes"><legend class="mo-sr">Choisissez votre formule</legend>';
 foreach(['abonnement'=>['Abonnement','Vos repas, au fil de la semaine'],'libre'=>['Commande libre','Composez selon vos envies']] as $k=>$t){echo '<label class="mo-mode-card"><input class="mo-mode-input" type="radio" name="mo_mode" value="'.esc_attr($k).'" '.checked($mode,$k,false).' required><span class="mo-mode-inner"><span class="mo-mode-mark" aria-hidden="true"></span><span class="mo-mode-title">'.esc_html($t[0]).'</span><span class="mo-mode-sub">'.esc_html($t[1]).'</span></span></label>';}
 echo '</fieldset>';
 /* 2. Abonnement: names and prices only */
 echo '<div class="mo-stage mo-stage-abo" data-stage="abonnement"><h2 class="mo-stage-title">Nos abonnements</h2><div class="mo-packs" role="radiogroup" aria-label="Abonnements">';
 foreach([1=>6.85,5=>6.50,10=>6.25] as $n=>$unit){echo '<label class="mo-pack"><input class="mo-pack-input" type="radio" name="mo_pack" value="'.esc_attr($n).'" '.checked($pack,$n,false).'><span class="mo-pack-inner"><span class="mo-pack-n">'.esc_html($n.' repas').'</span><span class="mo-pack-total">'.mo_fr($n*$unit).'</span><span class="mo-pack-unit">'.mo_fr($unit).' / repas</span></span></label>';}
 echo '</div><p class="mo-quiet">Paiement unique, sans renouvellement.</p></div>';
 /* 3. Commande libre: exact pricing */
 echo '<div class="mo-stage mo-stage-libre" data-stage="libre"><h2 class="mo-stage-title">Commande libre</h2><div class="mo-tiers">';
 foreach([[1,4,'1–4 repas',6.85,''],[5,9,'5–9 repas',6.50,'Économisez 0,35 € par repas'],[10,0,'10 repas et plus',6.25,'Économisez 0,60 € par repas']] as $i=>$t){if($i)echo '<hr class="mo-tier-divider">';echo '<div class="mo-tier-row" data-min="'.$t[0].'" data-max="'.$t[1].'"><span class="mo-tier-name">'.esc_html($t[2]).'</span><span class="mo-tier-price"><strong>'.mo_fr($t[3]).'</strong><small>/ repas</small></span>'.($t[4]?'<span class="mo-badge">'.esc_html($t[4]).'</span>':'').'</div>';}
 echo '</div></div>';
 /* 4. Menu, shown only once a formula is chosen */
 echo '<div class="mo-menu '.((($mode==='abonnement' && !$pack) || $mode==='') ? 'mo-menu-locked' : '').'" data-stage="menu"><h2 class="mo-stage-title mo-menu-title">Choisissez vos repas</h2><div class="mo-selection" data-cart-qty="'.esc_attr($existing).'">';
 $render=function($p,$big=false){
  $id=$p->get_id();$desc=mo_dish_descriptions($p->get_short_description(),$p);if(!$desc)$desc=$p->get_description();
  echo '<article class="mo-card '.($big?'mo-featured':'').'" data-id="'.esc_attr($id).'">';
  echo '<div class="mo-photo">'.$p->get_image($big?'large':'woocommerce_thumbnail').'</div>';
  echo '<div class="mo-info"><h3 class="mo-name">'.esc_html($p->get_name()).'</h3>';
  echo '<div class="mo-description">'.wp_kses_post(wpautop($desc)).'</div>';
  $dish_url=home_url('/plat/'.sanitize_title($p->get_name()).'/');
  echo '<a class="mo-voir" href="'.esc_url($dish_url).'" aria-label="'.esc_attr(sprintf('Voir %s',$p->get_name())).'">Voir</a>';
  echo '<div class="mo-counter"><button type="button" data-step="-1" aria-label="'.esc_attr('Retirer un '.$p->get_name()).'">−</button><input class="mo-q" id="mo-q-'.$id.'" name="mo_q['.$id.']" type="number" min="0" step="1" value="0" inputmode="numeric" aria-label="'.esc_attr('Quantité de '.$p->get_name()).'"><button type="button" data-step="1" aria-label="'.esc_attr('Ajouter un '.$p->get_name()).'">+</button></div>';
  echo '</div></article>';
 };
 if($featured){$render($products[$selected],true);unset($products[$selected]);echo '<h3 class="mo-complete">Complétez votre sélection</h3>';}
 echo '<div class="mo-grid '.($featured?'mo-grid-four':'mo-grid-five').'">';foreach($products as $p)$render($p);echo '</div></div>';
 echo '<div class="mo-dock" data-tier="1"><div class="mo-dock-stats">';
 foreach([['qty','Repas sélectionnés','0'],['unit','Prix par repas',mo_fr(6.85)],['per','Économie par repas',mo_fr(0)],['saved','Économie totale',mo_fr(0)],['total','Total',mo_fr(0)]] as $s)echo '<div class="mo-stat mo-stat-'.$s[0].'"><span class="mo-stat-l">'.esc_html($s[1]).'</span><span class="mo-stat-v" data-k="'.$s[0].'">'.$s[2].'</span></div>';
 echo '</div><div class="mo-progress" aria-hidden="true"><div class="mo-progress-track"><span class="mo-progress-fill"></span></div><ol class="mo-progress-labels"><li data-tier="1">6,85 €</li><li data-tier="5">6,50 €</li><li data-tier="10">6,25 €</li></ol></div>';
 echo '<p class="mo-msg" role="status" aria-live="polite"></p><p class="mo-hint" aria-live="polite"></p><div class="mo-summary-live" aria-live="polite"></div>'.($existing?'<p class="mo-existing">'.esc_html(sprintf(_n('Dont %d repas déjà dans votre panier.','Dont %d repas déjà dans votre panier.',$existing,'miras'),$existing)).'</p>':'');
 echo '<button type="submit" class="button mo-submit" name="mo_add" value="1">Continuer vers le paiement</button></div></div></form></section>';
 return ob_get_clean();
});
add_action('template_redirect',function(){
 if(!isset($_POST['mo_add'])||!function_exists('WC'))return;
 if(!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce']??'')),'mo_add'))wp_die('Session expirée.');
 if(WC()->session&&!WC()->cart)wc_load_cart();
 if(!WC()->session||!WC()->cart)return;
 $mode=sanitize_key(wp_unslash($_POST['mo_mode']??''))==='abonnement'?'abonnement':'libre';
 $pack=absint($_POST['mo_pack']??0);
 $wanted=[];
 foreach((array)wp_unslash($_POST['mo_q']??[]) as $id=>$n){$id=absint($id);$n=absint($n);if($n&&in_array($id,mo_ids(),true))$wanted[$id]=$n;}
 $sum=array_sum($wanted);
 $back=wp_get_referer()?:mo_composer_url();
 if(!$sum){wc_add_notice('Choisissez au moins un repas.','error');wp_safe_redirect($back);exit;}
 if($mode==='abonnement'&&(!in_array($pack,[1,5,10],true)||$sum!==$pack)){wc_add_notice('Pour un abonnement, répartissez exactement 1, 5 ou 10 repas.','error');wp_safe_redirect($back);exit;}
 $prev=WC()->session->get('mo_mode','libre');
 if($mode==='abonnement'||($prev==='abonnement'&&$mode==='libre')){foreach(WC()->cart->get_cart() as $key=>$item){if(in_array($item['product_id'],mo_ids(),true))WC()->cart->remove_cart_item($key);}}
 WC()->session->set('mo_mode',$mode);
 WC()->session->set('mo_pack',$mode==='abonnement'?$pack:0);
 $added=false;foreach($wanted as $id=>$n){if(WC()->cart->add_to_cart($id,$n))$added=true;}
 if(!$added){wc_add_notice('Impossible d’ajouter cette sélection.','error');wp_safe_redirect($back);exit;}
 WC()->session->set('mo_plan',[]);WC()->session->set('mo3_sig','');WC()->session->set('mo3_address',null);
 wp_safe_redirect(wc_get_cart_url());exit;
});
/* The 5-meal ordering notice must appear only inside the FAQ. */
function mo_notice_regex(){$s='(?:\s|&nbsp;|&#160;|&#8239;|\x{00A0}|\x{202F})+';$a='(?:’|\'|&rsquo;|&#8217;|&#039;|&#39;)';return '(?:Les'.$s.'commandes'.$s.'de'.$s.'5'.$s.'repas'.$s.'ou'.$s.'plus'.$s.'sont'.$s.'accept(?:é|&eacute;)es'.$s.'jusqu'.$a.'(?:à|&agrave;)'.$s.'23'.$s.'h'.$s.'59,'.$s.'deux'.$s.'jours'.$s.'avant'.$s.'la'.$s.'date'.$s.'de'.$s.'r(?:é|&eacute;)ception'.$s.'souhait(?:é|&eacute;)e\.?)';}
function mo_strip_notice_outside_faq($html){
 if(!is_string($html)||$html==='')return $html;
 if(!preg_match('~<[a-z0-9]+\b[^>]*\bid=["\']faq["\'][^>]*>~i',$html,$m,PREG_OFFSET_CAPTURE))return $html;
 $cut=$m[0][1];$before=substr($html,0,$cut);$after=substr($html,$cut);
 $re=mo_notice_regex();
 $clean=preg_replace('~<(p|div|span|small|li|em|strong)\b[^>]*>\s*'.$re.'\s*</\1>~iu','',$before);
 if($clean===null)return $html;
 $clean=preg_replace('~'.$re.'~iu','',$clean);
 return ($clean===null?$before:$clean).$after;
}
require_once __DIR__.'/planner.php';
function mo_order_info($o){$plan=$o->get_meta('_mo_plan');if(!$plan)return;echo '<h3>Réceptions MIRAS</h3><ul>';foreach($plan as $r){$slot=$r['slot']??(($r['mode']??'')==='delivery'?mo3_hours_delivery():mo3_hours_pickup());$where=($r['mode']??'')==='delivery'?'Livraison à domicile':('Retrait — '.(mo3_point($r['point']??'')['label']??''));echo '<li>'.esc_html($r['date'].' — '.$where.' — '.$slot).'<ul>';foreach($r['items'] as $id=>$n)echo '<li>'.esc_html(get_the_title($id).' × '.$n).'</li>';echo '</ul></li>';}echo '</ul>';}

function mo_savings(){
 if(!function_exists('WC')||!WC()->cart)return;$p=mo_price_parts();if(!$p['qty'])return;
 foreach([['mo-row-base','Repas avant remise',$p['base'],$p['base_html']],['mo-row-save','Économisés',$p['saved'],$p['saved_html']],['mo-row-after','Repas après remise',$p['after'],$p['after_html']]] as $r){
  echo '<tr class="mo-breakdown '.esc_attr($r[0]).'"><th>'.esc_html($r[1]).'</th><td data-title="'.esc_attr($r[1]).'"><span class="mo-arrow" aria-hidden="true"></span><span class="mo-price" data-amount="'.esc_attr($r[2]).'">'.$r[3].'</span></td></tr>';
 }
}
add_action('woocommerce_cart_totals_before_order_total','mo_savings');
add_action('woocommerce_review_order_before_order_total','mo_savings');
// The existing reception planner requires the classic cart/checkout hooks.
add_filter('render_block',function($html,$block){
 if(is_admin()||!function_exists('WC'))return $html;
 if(($block['blockName']??'')==='woocommerce/cart'&&is_cart())return do_shortcode('[woocommerce_cart]');
 if(($block['blockName']??'')==='woocommerce/checkout'&&is_checkout()&&!is_order_received_page())return do_shortcode('[woocommerce_checkout]');
 return $html;
},20,2);
add_action('wp_enqueue_scripts',function(){if(!is_page('composez-votre-commande')&&!is_cart()&&!is_checkout()&&!is_order_received_page())return;wp_enqueue_style('mo',plugins_url('orders.css',__FILE__),[], '4.5.1');wp_enqueue_script('mo',plugins_url('orders.js',__FILE__),[],'4.5.1',true);wp_localize_script('mo','moRates',['mid'=>5,'low'=>10]);});
add_filter('wp_nav_menu_objects',function($items){foreach($items as $i){$title=strtolower(remove_accents(trim(wp_strip_all_tags($i->title))));if(in_array($title,['menu','nos repas'],true))$i->url=home_url('/composez-votre-commande/');if($title==='notre histoire'){$i->title='NOTRE HISTOIRE';$i->url=home_url('/notre-histoire/');}}return $items;},40);
add_action('template_redirect',function(){if(is_page('menu')){wp_safe_redirect(home_url('/#notre-menu'),302);exit;}});

add_filter('template_include',function($template){if(is_page(['composez-votre-commande','composer'])&&function_exists('WC'))return plugin_dir_path(__FILE__).'composer-template.php';return $template;},99);
add_action('template_redirect',function(){if(is_page('composer')&&!isset($_POST['mo_add'])){$args=[];if(isset($_GET['plat']))$args['plat']=absint($_GET['plat']);wp_safe_redirect(add_query_arg($args,mo_composer_url()),302);exit;}},2);
register_activation_hook(__FILE__,function(){if(!get_page_by_path('composez-votre-commande'))wp_insert_post(['post_type'=>'page','post_status'=>'publish','post_title'=>'Composez votre commande','post_name'=>'composez-votre-commande','post_content'=>'[miras_composer]']);});
add_filter('wp_nav_menu_objects',function($items){foreach($items as $i){$title=strtolower(remove_accents(trim(wp_strip_all_tags($i->title))));if(in_array($title,['abonnement','abonnements','nos abonnements','nos formules'],true))$i->url=home_url('/#nos-abonnements');if(in_array($title,['faq','questions frequentes'],true))$i->url=home_url('/#faq');}return $items;},99);
add_action('template_redirect',function(){if(!is_front_page())return;ob_start(function($html){
 $html=str_replace([home_url('/composer/'),home_url('/composer')],mo_composer_url(),$html);
 $html=str_replace(['Exemple : 20 repas pour 125,00 €','Exemple : 5 repas pour 32,50 €'],'',$html);
 $html=str_replace(['À partir de 11 : 6,25 €','À partir de 11 repas','à partir de 11 repas','dès 11 repas','Dès 11 repas','5–10 : 6,50 €','5-10 : 6,50 €','5–10 repas','5-10 repas'],['À partir de 10 : 6,25 €','À partir de 10 repas','à partir de 10 repas','dès 10 repas','Dès 10 repas','5–9 : 6,50 €','5–9 : 6,50 €','5–9 repas','5–9 repas'],$html);
 $html=str_replace('Dès 5 repas : commande au plus tard à 23 h 59 deux jours avant réception. Pas de réception le dimanche.','Les commandes de 5 repas ou plus sont acceptées jusqu’à 23 h 59, deux jours avant la date de réception souhaitée.',$html);
 $html=str_replace('Dès 5 repas, commandez au plus tard à 23 h 59 deux jours calendaires avant la réception. Aucune réception le dimanche.','Dès 5 repas, commandez au plus tard à 23 h 59 deux jours avant la réception.',$html);
 return mo_strip_notice_outside_faq($html);
});},1);

add_action('template_redirect',function(){if(!is_404()||!function_exists('WC'))return;$req=trim((string)wp_parse_url($_SERVER['REQUEST_URI']??'',PHP_URL_PATH),'/');if($req==='composez-votre-commande'||$req==='composer'){status_header(200);nocache_headers();include plugin_dir_path(__FILE__).'composer-template.php';exit;}},1);

