MIRAS Orders 4.4.0 — Commands Pack 2
Source: mirascommands2.odt

Three-step subscription flow, exact package prices, controlled meal quantities, live summary,
requested date/time slots (18 h–20 h 30 and 20 h 30–22 h 30), responsive ordering and existing
WooCommerce protections are preserved.

Online card payment remains disabled for now: MIRAS registers the order and the existing gateway
keeps the order on-hold until online payment is enabled in the future.

MIRAS Orders 4.4.1: packaging/version refresh only; no ordering or payment logic changed by this command pack update.
