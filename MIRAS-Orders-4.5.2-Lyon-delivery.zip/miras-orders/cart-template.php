<?php
if(!defined('ABSPATH'))exit;
get_header();
$step=sanitize_key($_GET['mstep']??'');
if(!in_array($step,['methode','compte','adresse','date','hebdo'],true))$step='cart';
echo '<main class="mo mo3-cart"><div class="mo3-wrap">';
mo3_header($step);
wc_print_notices();
if(!WC()->cart||WC()->cart->is_empty()){
 echo '<div class="mo3-box mo3-narrow"><h1 class="mo3-h1">Votre panier est vide</h1><a class="button" href="'.esc_url(mo_composer_url()).'">Choisir mes repas</a></div></div></main>';
 get_footer();return;
}
$parts=mo_price_parts();
$q=(int)$parts['qty'];
$plan=mo3_plan();
if($step==='cart'){
 $mode_label=$parts['mode']==='abonnement'?('Abonnement'.($parts['pack']?' · '.$parts['pack'].' repas':'')):'Commande libre';
 echo '<section class="mo3-box mo3-narrow"><h1 class="mo3-h1">Mon panier</h1><p class="mxe-whisper mo3-center">Votre sélection, en toute sérénité.</p><p class="mo3-center mo3-small" id="mo-cart-mode">'.esc_html($mode_label).'</p><form method="post" id="mo3-cart-form">';
 wp_nonce_field('mo3_cart');
 foreach(WC()->cart->get_cart() as $key=>$i){
  $p=$i['data'];
  echo '<article class="mo3-cart-row"><div>'.$p->get_image('woocommerce_thumbnail').'</div><div><h3>'.esc_html($p->get_name()).'</h3><p class="mo3-unit">'.WC()->cart->get_product_price($p).' / repas</p><div class="mo-counter"><button type="button" data-cart-step="-1" aria-label="Retirer un repas">−</button><input id="qty-'.esc_attr($key).'" type="number" min="0" step="1" name="qty['.esc_attr($key).']" value="'.absint($i['quantity']).'" inputmode="numeric" aria-label="'.esc_attr('Quantité de '.$p->get_name()).'"><button type="button" data-cart-step="1" aria-label="Ajouter un repas">+</button></div><button type="button" class="mo3-remove">Supprimer</button></div><div class="mo3-line"><span class="mo3-small">Sous-total</span><br><span class="mo3-line-price">'.WC()->cart->get_product_subtotal($p,$i['quantity']).'</span></div></article>';
 }
 echo '<div class="mo3-prices" aria-live="polite"><table class="shop_table"><tbody>';
 mo_savings();
 echo '</tbody></table><dl class="mo3-summary"><div><dt>Nombre de repas</dt><dd id="mo-cart-count">'.absint($q).'</dd></div><div class="total"><dt>Total des repas</dt><dd id="mo-cart-total">'.wp_kses_post($parts['after_html']).'</dd></div></dl></div><p id="mo3-cart-status" class="mo3-small" role="status"></p><button class="button mo-submit" name="mo3_update" value="go">Continuer</button></form></section></div></main>';
 get_footer();return;
}
if($step==='methode'){
 echo '<section class="mo3-box mo3-narrow"><h1 class="mo3-h1">Livraison</h1><form method="post" id="mo3-method-form">';
 wp_nonce_field('mo3_method');
 $current=mo3_method();
 echo '<div class="mo3-method-grid">';
 echo '<label class="mo3-method"><input type="radio" name="method" value="pickup" '.checked($current,'pickup',false).' required><span><svg viewBox="0 0 48 48" aria-hidden="true"><path d="M8 20h32v16H8z"/><path d="M16 20v-4a8 8 0 0 1 16 0v4"/><path d="M24 28v4"/></svg><strong>Livraison gratuite</strong></span></label>';
 echo '<label class="mo3-method"><input type="radio" name="method" value="delivery" '.checked($current,'delivery',false).'><span><svg viewBox="0 0 48 48" aria-hidden="true"><path d="M8 22 L24 8 L40 22"/><path d="M14 20 v16 h20 v-16"/><path d="M22 36 v-8 h4 v8"/></svg><strong>Livraison à domicile</strong></span></label>';
 echo '</div><button class="button mo-submit" name="mo3_method_save" value="1">Continuer</button></form></section></div></main>';
 get_footer();return;
}
if($step==='compte'){
 echo '<section class="mo3-box mo3-narrow mo3-auth"><h1 class="mo3-h1">Compte</h1>';
 if(function_exists('mxe2_button')) mxe2_button();
 echo '<div class="mxe-tabs mo3-auth-tabs" role="tablist"><button type="button" id="mo3-tab-login" aria-selected="true">Connexion</button><button type="button" id="mo3-tab-register" aria-selected="false">Créer un compte</button></div>';
 echo '<form class="mo3-auth-panel" id="mo3-login" method="post" action="'.esc_url(mo3_url('compte')).'">';
 echo '<label>Adresse email<input type="email" name="username" required autocomplete="username"></label>';
 echo '<label>Mot de passe<input type="password" name="password" required autocomplete="current-password"></label>';
 wp_nonce_field('woocommerce-login','woocommerce-login-nonce');
 echo '<input type="hidden" name="redirect" value="'.esc_url(mo3_url('adresse')).'">';
 echo '<button class="button mo-submit" type="submit" name="login" value="1">Connexion</button></form>';
 echo '<form class="mo3-auth-panel" id="mo3-register" method="post" action="'.esc_url(mo3_url('compte')).'" hidden>';
 echo '<label>Adresse email<input type="email" name="email" required autocomplete="email"></label>';
 echo '<label>Mot de passe<input type="password" name="password" required autocomplete="new-password" minlength="8"></label>';
 echo '<label>Confirmation du mot de passe<input type="password" name="password_confirm" required autocomplete="new-password" minlength="8"></label>';
 wp_nonce_field('woocommerce-register','woocommerce-register-nonce');
 echo '<input type="hidden" name="redirect" value="'.esc_url(mo3_url('compte')).'">';
 echo '<button class="button mo-submit" type="submit" name="register" value="1">Créer un compte</button></form>';
 echo '</section></div></main>';
 get_footer();return;
}
if($step==='adresse'){
 $phone=mo3_phone();if(!$phone&&is_user_logged_in())$phone=(string)get_user_meta(get_current_user_id(),'billing_phone',true);
 $name=mo3_name();if(!$name&&is_user_logged_in()){$u=wp_get_current_user();$name=trim($u->first_name.' '.$u->last_name);}
 $saved=mo3_address();
 echo '<section class="mo3-box mo3-narrow"><h1 class="mo3-h1">Adresse</h1><form method="post" id="mo3-address-form">';
 wp_nonce_field('mo3_address');
 echo '<label>Nom et prénom<input type="text" name="full_name" required autocomplete="name" value="'.esc_attr($name).'"></label>';
 echo '<label>Numéro de téléphone<input type="tel" name="phone" required inputmode="tel" autocomplete="tel" value="'.esc_attr($phone).'"></label>';
 $src=$saved['source']??'search';$geo=$saved['geo']??null;$pin=in_array($src,['map','client'],true)&&is_array($geo);
 echo '<label>Adresse exacte de livraison<input type="text" class="mo3-address-input" name="address" required autocomplete="street-address" placeholder="Numéro, rue, code postal, ville" value="'.esc_attr($saved['address']??'').'"></label>';
 echo '<input class="mo3-token" type="hidden" name="token" value="">';
 echo '<input class="mo3-lat" type="hidden" name="lat" value="'.esc_attr($pin?$geo[0]:'').'"><input class="mo3-lng" type="hidden" name="lng" value="'.esc_attr($pin?$geo[1]:'').'"><input class="mo3-src" type="hidden" name="geo_source" value="'.esc_attr($pin?$src:'').'">';
 echo '<div class="mo3-results" role="listbox" aria-label="Adresses proposées"></div><p class="mo3-address-status" role="status" aria-live="polite"></p>';
 echo '<p class="mo3-map-toggle-wrap"><button type="button" class="mo3-map-toggle" aria-expanded="'.($pin?'true':'false').'" aria-controls="mo3-map-panel">Vous ne trouvez pas votre adresse ? Indiquez-la sur la carte</button></p>';
 echo '<div class="mo3-map-panel" id="mo3-map-panel"'.($pin?'':' hidden').'><p class="mo3-small mo3-map-help">Déplacez la carte pour placer le repère sur votre porte d’entrée.</p><div class="mo3-map" id="mo3-map" role="application" aria-label="Carte : déplacez la carte pour placer le repère sur votre adresse"><div class="mo3-map-pin" aria-hidden="true"></div><div class="mo3-map-tools"><button type="button" data-zoom="1" aria-label="Zoomer">+</button><button type="button" data-zoom="-1" aria-label="Dézoomer">−</button></div><button type="button" class="mo3-map-locate">Ma position</button><div class="mo3-map-attr">© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a></div></div>';
 echo '<div class="mo3-grid2"><label>Code postal<input type="text" class="mo3-postcode" name="postcode" inputmode="numeric" pattern="[0-9]{5}" maxlength="5" autocomplete="postal-code" value="'.esc_attr($saved['postcode']??'').'"></label><p class="mo3-map-status" role="status" aria-live="polite"></p></div></div>';
 echo '<button class="button mo-submit" name="mo3_address_save" value="1">Confirmer</button></form></section></div></main>';
 get_footer();return;
}
if($step==='hebdo'){
 $dates=array_column($plan,'date');sort($dates);$next=$dates?wp_date('d/m/Y',strtotime($dates[0].' +7 days')):'';
 $amount=(float)WC()->cart->get_total('edit');
 echo '<section class="mo3-box mo3-narrow"><h1 class="mo3-h1">Chaque semaine ?</h1><form method="post">';wp_nonce_field('mo3_weekly');
 echo '<label class="mo3-choice"><input type="radio" name="weekly" value="yes" required><span><strong>Oui</strong></span></label><div class="mo3-terms"><p>Mêmes repas, chaque semaine. Prochaine échéance indicative : '.esc_html($next).'. Montant indicatif : '.wp_kses_post(wc_price($amount)).'.</p><label><input type="checkbox" name="weekly_consent" value="1"> J’autorise les paiements hebdomadaires décrits ci-dessus.</label></div>';
 echo '<label class="mo3-choice"><input type="radio" name="weekly" value="no"><span><strong>Non</strong></span></label><button class="button mo-submit" name="mo3_weekly_save" value="1">Continuer</button></form></section></div></main>';
 get_footer();return;
}
$method=mo3_method();
[$min,$max]=mo3_date_bounds();
$slots=mo3_slots($method?:'delivery');
$points=mo3_points();
$chosen=$plan[0]['date']??'';
$chosen_slot=$plan[0]['slot']??'';
$chosen_point=$plan[0]['point']??($points[0]['id']??'');
echo '<section class="mo3-box mo3-narrow"><h1 class="mo3-h1">Date</h1><form method="post" id="mo3-date-form" data-min="'.esc_attr($min).'" data-max="'.esc_attr($max).'" data-sunday="'.esc_attr(get_option('mo3_closed_sunday','1')).'">';
wp_nonce_field('mo3_date');
echo '<div id="mo3-cal" class="mo3-cal" aria-label="Calendrier"></div>';
echo '<label class="mo3-native-date">Date<input id="mo3-date-value" type="date" name="date" required min="'.esc_attr($min).'" max="'.esc_attr($max).'" value="'.esc_attr($chosen).'"></label>';
if($method==='pickup'&&count($points)>1){
 echo '<fieldset class="mo3-points"><legend>Lieu</legend>';
 foreach($points as $p)echo '<label class="mo3-choice"><input type="radio" name="point" value="'.esc_attr($p['id']).'" '.checked($chosen_point,$p['id'],false).' required><span>'.esc_html($p['label']).'</span></label>';
 echo '</fieldset>';
}elseif($method==='pickup'&&$points){
 echo '<input type="hidden" name="point" value="'.esc_attr($points[0]['id']).'">';
}
echo '<fieldset class="mo3-slots"><legend>Horaire</legend>';
foreach($slots as $i=>$s){$id='mo3-slot-'.$i;$on=($chosen_slot!==''&&$chosen_slot===$s)||($chosen_slot===''&&count($slots)===1);echo '<label class="mo3-slot" for="'.esc_attr($id).'"><input id="'.esc_attr($id).'" type="radio" name="slot" value="'.esc_attr($s).'" '.checked($on,true,false).' required><span>'.esc_html($s).'</span></label>';}
echo '</fieldset><button class="button mo-submit" name="mo3_date_save" value="1">Continuer</button></form></section></div></main>';
get_footer();
