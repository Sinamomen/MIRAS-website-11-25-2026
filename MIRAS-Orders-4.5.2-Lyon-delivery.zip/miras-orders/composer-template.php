<?php
if(!defined('ABSPATH'))exit;
get_header();echo '<main id="primary" class="site-main">';$out=do_shortcode('[miras_composer]');echo trim($out)!==''?$out:'<section class="mo"><h1>Composez votre commande</h1><p>Le menu est momentanément indisponible. Veuillez réessayer.</p></section>';echo '</main>';get_footer();
