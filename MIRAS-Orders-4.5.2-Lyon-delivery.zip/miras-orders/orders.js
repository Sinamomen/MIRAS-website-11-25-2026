/* MIRAS Orders 4.2.0 — sélection des repas, calculateur d'économies en direct */
(function(){
'use strict';
const ready=fn=>document.readyState!=='loading'?fn():document.addEventListener('DOMContentLoaded',fn);

/* Remove the 5-meal ordering notice everywhere except inside the FAQ (server already does it on the homepage). */
function stripNotice(){
 const norm=s=>(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[\u00a0\u202f\s]+/g,' ').replace(/[’']/g,"'").trim().toLowerCase();
 const target=norm('Les commandes de 5 repas ou plus sont acceptées jusqu’à 23 h 59, deux jours avant la date de réception souhaitée.');
 const inFaq=n=>{const el=n.nodeType===1?n:n.parentElement;return !!(el&&el.closest('#faq,.faq,.faq-item,.e-n-accordion,.elementor-accordion,.elementor-toggle,details,[class*="faq"]'));};
 const root=document.querySelector('main')||document.body;if(!root)return;
 const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);const hits=[];let n;
 while((n=walker.nextNode())){if(norm(n.textContent).includes(target.slice(0,40))&&!inFaq(n))hits.push(n);}
 hits.forEach(t=>{const el=t.parentElement;if(!el)return;
  if(norm(el.textContent)===target||norm(el.textContent)===target.replace(/\.$/,'')){const box=el.closest('p,li,small,.elementor-widget-text-editor,.elementor-widget-heading')||el;
   if(norm(box.textContent).replace(/\.$/,'')===target.replace(/\.$/,'')){box.remove();return;}el.remove();return;}
  t.textContent=t.textContent.replace(/Les commandes de 5 repas ou plus sont accept[ée]es jusqu[’']à[\s\u00a0\u202f]*23[\s\u00a0\u202f]*h[\s\u00a0\u202f]*59, deux jours avant la date de r[ée]ception souhait[ée]e\.?/i,'');
 });
}

ready(()=>{
stripNotice();
if(window.jQuery){
 const $=window.jQuery; let mirasSubmitting=false;
 $(document.body).on('checkout_place_order','form.checkout',function(){
   if(mirasSubmitting)return false;
   mirasSubmitting=true;
   $(this).addClass('miras-checkout-submitting').attr('aria-busy','true');
   setTimeout(()=>{mirasSubmitting=false;$(this).removeClass('miras-checkout-submitting').removeAttr('aria-busy');},15000);
   return true;
 });
 $(document.body).on('checkout_error updated_checkout',function(){mirasSubmitting=false;$('form.checkout').removeClass('miras-checkout-submitting').removeAttr('aria-busy');});
}
const form=document.querySelector('.mo-form');
if(!form)return;
form.classList.add('mo-js');
const menu=form.querySelector('.mo-menu'),steps=[...form.querySelectorAll('.mo-steps li')],summaryLive=form.querySelector('.mo-summary-live');
const selection=form.querySelector('.mo-selection');
const inputs=[...form.querySelectorAll('.mo-q')];
const dock=form.querySelector('.mo-dock');
const msg=form.querySelector('.mo-msg'),hint=form.querySelector('.mo-hint');
const fill=form.querySelector('.mo-progress-fill');
const submit=form.querySelector('[name="mo_add"]');
const STD=685; /* centimes : tarif standard 6,85 € */
const mid=(window.moRates&&moRates.mid)||5, low=(window.moRates&&moRates.low)||10;
const fmt=new Intl.NumberFormat('fr-FR',{style:'currency',currency:'EUR'});
const money=c=>fmt.format(c/100);
const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
const tierOf=q=>q>=low?10:q>=mid?5:1;
const rateOf=q=>q>=low?625:q>=mid?650:685;
const packRate={1:685,5:650,10:625};
const existing=Number(form.dataset.existing)||0;
let lastTier=0,lastQty=null,msgTimer,celebrateUntil=0;

function mode(){return form.querySelector('input[name="mo_mode"]:checked')?.value||'';}
function pack(){return Number(form.querySelector('input[name="mo_pack"]:checked')?.value||0);}
function ink(el,level){if(window.MIRASInk&&el)window.MIRASInk.burst(el,{level:level||'strong'});else if(el){el.classList.remove('mo-celebrate');void el.offsetWidth;el.classList.add('mo-celebrate');}}
function setVal(k,text){const el=dock&&dock.querySelector('[data-k="'+k+'"]');if(!el||el.textContent===text)return;el.textContent=text;if(!reduce){el.classList.remove('is-fresh');void el.offsetWidth;el.classList.add('is-fresh');}}
function renderSummary(){if(!summaryLive)return;const rows=[];inputs.forEach(i=>{const q=Number(i.value)||0;if(q>0){const card=i.closest('.mo-card');rows.push(`<span>${card?.querySelector('.mo-name')?.textContent||'Plat'} × ${q}</span>`);}});summaryLive.innerHTML=rows.length?('<strong>Votre sélection</strong><div>'+rows.join('')+'</div>'):'';}
function say(text,celebrate){if(!msg)return;if(celebrate)clearTimeout(msgTimer);msg.textContent=text;msg.classList.toggle('is-celebration',!!celebrate);}

function stage(){
 const m=mode(),p=pack();
 form.dataset.mode=m;form.dataset.pack=m==='abonnement'?String(p||''):'';
 const ready=m==='libre'||(m==='abonnement'&&p>0);
 form.dataset.ready=ready?'1':'0';
 if(menu) menu.classList.toggle('mo-menu-locked',!ready || (m==='abonnement'&&!p));
 steps.forEach((s,i)=>{s.classList.toggle('is-active',(ready&&i===1)||(ready&&m==='abonnement'&&p&&i>=1)||(!ready&&i===0));});
 /* keep the choice if the server sends the customer back with a notice */
 try{const u=new URL(form.action,location.href);if(m)u.searchParams.set('mode',m);else u.searchParams.delete('mode');if(m==='abonnement'&&p)u.searchParams.set('pack',String(p));else u.searchParams.delete('pack');form.action=u.toString();}catch(e){}
 return ready;
}

function update(fromUser){
 let added=0;inputs.forEach(i=>{const v=Math.max(0,Math.floor(Number(i.value)||0));if(String(v)!==i.value)i.value=String(v);added+=v;});
 const m=mode(),p=pack();
 if(!dock)return;
 dock.dataset.mode=m;
 if(m==='abonnement'){
  const unit=packRate[p]||685,diff=p-added;
  setVal('qty',p?`${added} / ${p}`:String(added));
  setVal('unit',money(unit));setVal('per',money(STD-unit));
  setVal('saved',money(p*(STD-unit)));setVal('total',money(p*unit));
  dock.dataset.tier=String(p>=10?10:p>=5?5:1);
  if(fill)fill.style.transform=`scaleX(${p?Math.min(1,added/p):0})`;
  if(!p){say('');if(hint)hint.textContent='Choisissez d’abord votre abonnement.';}
  else{say(diff===0?'Votre abonnement est complet.':'');if(hint)hint.textContent=diff>0?`Encore ${diff} repas à répartir.`:diff<0?`Retirez ${-diff} repas pour correspondre à votre abonnement.`:'';}
  form.querySelectorAll('[data-step="1"]').forEach(b=>{b.disabled=p>0&&added>=p;});
  if(submit)submit.disabled=!p||added!==p;
  if(fromUser&&p&&added===p&&lastQty!==null&&lastQty!==added)ink(dock,'strong');
  renderSummary(); lastQty=added;return;
 }
 form.querySelectorAll('[data-step="1"]').forEach(b=>{b.disabled=false;});
 const q=existing+added,unit=rateOf(q),tier=tierOf(q);
 const saved=q*(STD-unit);
 setVal('qty',String(q));setVal('unit',money(unit));setVal('per',money(STD-unit));setVal('saved',money(saved));setVal('total',money(q*unit));
 dock.dataset.tier=String(tier);
 if(fill){const k=q>=low?1:q>=mid?.5+.5*(q-mid)/(low-mid):.5*q/mid;fill.style.transform=`scaleX(${Math.min(1,k)})`;}
 form.querySelectorAll('.mo-tier-row').forEach(r=>{const a=Number(r.dataset.min),b=Number(r.dataset.max)||Infinity;r.classList.toggle('is-on',q>=a&&q<=b&&q>0);});
 if(hint)hint.textContent=q<mid?`Plus que ${mid-q} repas pour profiter du tarif de 6,50 € par repas.`:q<low?`Plus que ${low-q} repas pour profiter du tarif de 6,25 € par repas.`:'Vous profitez du meilleur tarif : 6,25 € par repas.';
 const savingsText=saved>0?`Vous économisez actuellement ${money(saved)} sur votre commande.`:'';
 if(fromUser&&tier>lastTier){
  say(tier===10?'Excellent choix ! Vous économisez maintenant 0,60 € par repas.':'Félicitations ! Vous économisez maintenant 0,35 € par repas.',true);
  ink(dock,'strong');celebrateUntil=Date.now()+4000;
  msgTimer=setTimeout(()=>{celebrateUntil=0;update(false);},4100);
 }else if(Date.now()>=celebrateUntil||tier<lastTier){celebrateUntil=0;say(savingsText);}
 if(submit)submit.disabled=added===0;
 renderSummary(); lastTier=tier;lastQty=added;
}

function onChoice(e){
 const before=form.dataset.ready;
 const ok=stage();
 if(e&&e.target&&e.target.name==='mo_mode'){lastTier=tierOf(existing);celebrateUntil=0;}
 update(false);
 if(ok&&before!=='1'&&e){const menu=form.querySelector('.mo-menu');if(menu)setTimeout(()=>{const r=menu.getBoundingClientRect();if(r.top>innerHeight*.8)menu.scrollIntoView({behavior:reduce?'auto':'smooth',block:'start'});},260);}
}
form.querySelectorAll('input[name="mo_mode"],input[name="mo_pack"]').forEach(i=>i.addEventListener('change',onChoice));
selection&&selection.querySelectorAll('[data-step]').forEach(b=>b.addEventListener('click',()=>{const i=b.parentElement.querySelector('input');i.value=String(Math.max(0,(Number(i.value)||0)+Number(b.dataset.step)));const card=b.closest('.mo-card');if(card){card.classList.toggle('is-picked',Number(i.value)>0);}update(true);}));
inputs.forEach(i=>i.addEventListener('input',()=>{const card=i.closest('.mo-card');if(card)card.classList.toggle('is-picked',Number(i.value)>0);update(true);}));
form.addEventListener('submit',e=>{if(!stage()){e.preventDefault();form.querySelector('.mo-modes')?.scrollIntoView({behavior:'smooth',block:'center'});}});
stage();lastTier=tierOf(existing);update(false);
});
})();
