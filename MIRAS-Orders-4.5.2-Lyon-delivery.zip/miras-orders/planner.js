document.addEventListener('DOMContentLoaded',()=>{
const login=document.querySelector('#mo3-tab-login'),reg=document.querySelector('#mo3-tab-register');
if(login&&reg){const a=document.querySelector('#mo3-login'),b=document.querySelector('#mo3-register');const show=r=>{a.hidden=!r?false:true;b.hidden=r?false:true;login.setAttribute('aria-selected',String(!r));reg.setAttribute('aria-selected',String(r));};login.addEventListener('click',()=>show(false));reg.addEventListener('click',()=>show(true));if(location.hash==='#register')show(true);}
const form=document.querySelector('#mo3-cart-form');
if(form&&window.mo3Data){
 const status=document.querySelector('#mo3-cart-status');
 let timer=null,seq=0;
 const paint=(el,amount,html)=>{
  if(!el)return;const from=Number(el.dataset.amount),to=Number(amount);
  if(!Number.isFinite(from)||!Number.isFinite(to)||from===to||matchMedia('(prefers-reduced-motion: reduce)').matches){el.dataset.amount=String(to);el.innerHTML=html;return;}
  const t0=performance.now();
  const step=now=>{const k=Math.min(1,(now-t0)/460),e=1-Math.pow(1-k,3);el.textContent=new Intl.NumberFormat('fr-FR',{style:'currency',currency:'EUR'}).format(from+(to-from)*e);if(k<1)requestAnimationFrame(step);else{el.dataset.amount=String(to);el.innerHTML=html;el.classList.add('is-fresh');setTimeout(()=>el.classList.remove('is-fresh'),700);}};
  requestAnimationFrame(step);
 };
 const apply=data=>{
  const map={base:['.mo-row-base',data.base,data.base_html],save:['.mo-row-save',data.saved,data.saved_html],after:['.mo-row-after',data.after,data.after_html]};
  Object.values(map).forEach(([sel,amount,html])=>paint(form.querySelector(sel+' .mo-price'),amount,html));
  const count=document.querySelector('#mo-cart-count'),total=document.querySelector('#mo-cart-total'),mode=document.querySelector('#mo-cart-mode');
  if(count)count.textContent=String(data.qty||0);
  if(total)total.innerHTML=data.after_html||'';
  if(mode&&data.mode_label)mode.textContent=data.mode_label;
  const lines=data.lines||{};
  form.querySelectorAll('.mo3-cart-row').forEach(row=>{
   const input=row.querySelector('input[type=number]');if(!input)return;
   const key=input.name.slice(4,-1);const line=lines[key];
   if(!line){row.remove();return;}
   input.value=String(line.qty);
   const unit=row.querySelector('.mo3-unit'),sub=row.querySelector('.mo3-line-price');
   if(unit)unit.innerHTML=line.unit+' / repas';
   if(sub)sub.innerHTML=line.subtotal;
  });
  if(status)status.textContent=(data.messages||[]).join(' ');
  if(data.empty)location.reload();
 };
 const sync=async()=>{
  const my=++seq;form.classList.add('is-pending');
  const body=new FormData();body.append('action','mo3_cart_sync');body.append('nonce',mo3Data.cartNonce);
  form.querySelectorAll('input[type=number][name^="qty["]').forEach(i=>body.append(i.name,i.value));
  try{const res=await fetch(mo3Data.ajax,{method:'POST',body,credentials:'same-origin'});const data=await res.json();if(my!==seq)return;if(!data.success)throw new Error();apply(data.data);}
  catch(err){if(my===seq&&status)status.textContent='Le total sera confirmé avec Continuer.';}
  finally{if(my===seq)form.classList.remove('is-pending');}
 };
 const queue=()=>{clearTimeout(timer);timer=setTimeout(sync,160);};
 form.querySelectorAll('[data-cart-step]').forEach(b=>b.addEventListener('click',()=>{const i=b.parentElement.querySelector('input');i.value=String(Math.max(0,(Number(i.value)||0)+Number(b.dataset.cartStep)));queue();}));
 form.querySelectorAll('.mo3-remove').forEach(b=>b.addEventListener('click',()=>{const i=b.closest('.mo3-cart-row').querySelector('input[type=number]');i.value='0';queue();}));
 form.querySelectorAll('input[type=number]').forEach(i=>i.addEventListener('change',queue));
}
const address=document.querySelector('#mo3-address-form');
if(address&&window.mo3Data){
 const input=address.querySelector('.mo3-address-input'),results=address.querySelector('.mo3-results'),notice=address.querySelector('.mo3-address-status'),token=address.querySelector('.mo3-token');
 const latI=address.querySelector('.mo3-lat'),lngI=address.querySelector('.mo3-lng'),srcI=address.querySelector('.mo3-src'),pcI=address.querySelector('.mo3-postcode');
 const toggle=address.querySelector('.mo3-map-toggle'),panel=address.querySelector('.mo3-map-panel'),mapStatus=address.querySelector('.mo3-map-status');
 const C=mo3Data.center||[45.758,4.835],B=mo3Data.bbox||[45.55,4.6,46,5.2];
 const post=async(params)=>{const res=await fetch(mo3Data.ajax,{method:'POST',body:new URLSearchParams(Object.assign({nonce:mo3Data.nonce},params)),credentials:'same-origin'});return res.json();};
 const clearPoint=()=>{latI.value='';lngI.value='';srcI.value='';};
 let timer,seq=0,map=null,checkSeq=0;
 const usePoint=(lat,lng,src,label,postcode)=>{latI.value=lat.toFixed(6);lngI.value=lng.toFixed(6);srcI.value=src;token.value='';if(label)input.value=label;if(postcode&&pcI&&!pcI.value)pcI.value=postcode;};
 const zoneCheck=async(lat,lng,out)=>{const my=++checkSeq;try{const d=await post({action:'mo3_zone_check',lat,lng});if(my!==checkSeq)return null;const ok=!!(d.success&&d.data.available);if(out)out.textContent=ok?'Livraison disponible à cet endroit.':'La livraison à domicile n’est pas disponible à cet endroit.';return ok;}catch(e){if(my===checkSeq&&out)out.textContent='Position enregistrée. La zone de livraison sera confirmée à la validation.';return null;}};
 /* Browser-side backup: Photon (OpenStreetMap) answers directly when the server cannot reach any service */
 const photon=async(q)=>{const u=new URL('https://photon.komoot.io/api/');u.search=new URLSearchParams({q,limit:'6',lang:'fr',lat:String(C[0]),lon:String(C[1])}).toString();const ctl=new AbortController();const t=setTimeout(()=>ctl.abort(),6000);try{const r=await fetch(u,{signal:ctl.signal});if(!r.ok)throw 0;const d=await r.json();return (d.features||[]).map(f=>{const p=f.properties||{},c=(f.geometry||{}).coordinates||[];const street=p.street||((p.osm_key==='highway'||p.osm_key==='place')?p.name:'');if(!street||String(p.countrycode).toUpperCase()!=='FR'||c.length<2)return null;const lat=c[1],lng=c[0];if(lat<B[0]||lat>B[2]||lng<B[1]||lng>B[3])return null;const line=[p.housenumber,street].filter(Boolean).join(' ');return {address:[line,p.postcode,p.city].filter(Boolean).join(' '),postcode:p.postcode||'',lat,lng};}).filter(Boolean).slice(0,5);}finally{clearTimeout(t);}};
 const list=(items,onPick)=>{results.replaceChildren();items.forEach(p=>{const b=document.createElement('button');b.type='button';b.setAttribute('role','option');b.textContent=p.address;b.addEventListener('click',()=>{results.replaceChildren();onPick(p);});results.append(b);});};
 const openMap=(msg)=>{if(!panel)return;panel.hidden=false;toggle&&toggle.setAttribute('aria-expanded','true');if(pcI)pcI.required=true;if(msg)notice.textContent=msg;if(!map)map=initMap();else map.refresh();};
 const closeMap=()=>{if(!panel)return;panel.hidden=true;toggle&&toggle.setAttribute('aria-expanded','false');if(pcI)pcI.required=false;if(srcI.value==='map')clearPoint();};
 toggle&&toggle.addEventListener('click',()=>{panel.hidden?openMap():closeMap();});
 input.addEventListener('input',()=>{token.value='';if(srcI.value==='client')clearPoint();clearTimeout(timer);const request=++seq;results.replaceChildren();notice.textContent='';if(input.value.trim().length<5)return;
  timer=setTimeout(async()=>{let data=null;try{data=await post({action:'mo3_geo',q:input.value});}catch(e){data=null;}if(request!==seq)return;
   if(data&&data.success){if(!data.data.length){notice.textContent='Adresse introuvable. Vérifiez l’adresse ou indiquez-la sur la carte.';return;}
    list(data.data,p=>{input.value=p.address;clearPoint();if(!p.available){token.value='';notice.textContent='La livraison à domicile n’est pas disponible à cette adresse.';return;}token.value=p.token;notice.textContent='Adresse confirmée.';if(panel&&!panel.hidden)closeMap();});return;}
   if(data&&!data.success&&!(data.data&&data.data.fallback)){notice.textContent=(data.data&&data.data.message)||'Recherche indisponible.';return;}
   /* every server-side service is down: try from the browser, then the map */
   notice.textContent='Recherche en cours…';
   let items=[];try{items=await photon(input.value);}catch(e){items=null;}if(request!==seq)return;
   if(items&&items.length){notice.textContent='';list(items,async p=>{usePoint(p.lat,p.lng,'client',p.address,p.postcode);if(pcI&&p.postcode)pcI.value=p.postcode;notice.textContent='Vérification…';const ok=await zoneCheck(p.lat,p.lng,notice);if(ok===false)clearPoint();else if(ok)notice.textContent='Adresse confirmée.';});return;}
   if(items&&!items.length){notice.textContent='Adresse introuvable. Indiquez-la sur la carte.';openMap();return;}
   openMap('Le service d’adresses est momentanément indisponible. Indiquez simplement votre adresse sur la carte.');
  },450);});
 address.addEventListener('submit',e=>{const mapOpen=panel&&!panel.hidden;if(token.value)return;if(srcI.value==='client'&&latI.value)return;
  if(mapOpen&&map){const c=map.center();usePoint(c.lat,c.lng,'map');if(pcI&&!/^\d{5}$/.test(pcI.value)){e.preventDefault();pcI.focus();mapStatus.textContent='Indiquez votre code postal.';}return;}
  if(mo3Data.saved&&mo3Data.saved.address===input.value.trim())return;
  e.preventDefault();notice.textContent='Choisissez une adresse dans la liste ou indiquez-la sur la carte.';});
 /* --- Lightweight map: OpenStreetMap tiles, no external library, centre pin --- */
 function initMap(){
  const el=address.querySelector('#mo3-map');if(!el)return null;
  const T=256,MIN=11,MAX=19,servers=['https://tile.openstreetmap.org/{z}/{x}/{y}.png','https://a.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png'];
  const layer=document.createElement('div');layer.className='mo3-map-layer';el.prepend(layer);
  const s=mo3Data.saved;let z=16,cx,cy;
  const proj=(lat,lng,zz)=>{const n=T*Math.pow(2,zz),r=lat*Math.PI/180;return [(lng+180)/360*n,(1-Math.log(Math.tan(r)+1/Math.cos(r))/Math.PI)/2*n];};
  const unproj=(x,y,zz)=>{const n=T*Math.pow(2,zz),lng=x/n*360-180,lat=Math.atan(Math.sinh(Math.PI*(1-2*y/n)))*180/Math.PI;return {lat,lng};};
  const start=(latI.value&&lngI.value)?[Number(latI.value),Number(lngI.value)]:((s&&s.geo&&s.geo[0])?s.geo:C);[cx,cy]=proj(start[0],start[1],z);
  const tiles=new Map();let moveT;
  const draw=()=>{const w=el.clientWidth,h=el.clientHeight;if(!w||!h)return;const n=Math.pow(2,z),x0=cx-w/2,y0=cy-h/2;const keep=new Set();
   for(let tx=Math.floor(x0/T);tx<=Math.floor((x0+w)/T);tx++)for(let ty=Math.floor(y0/T);ty<=Math.floor((y0+h)/T);ty++){if(ty<0||ty>=n)continue;const wx=((tx%n)+n)%n,key=z+'/'+wx+'/'+ty+'/'+tx;keep.add(key);let img=tiles.get(key);
    if(!img){img=new Image();img.alt='';img.draggable=false;img.decoding='async';img.dataset.s='0';img.onerror=()=>{const k=Number(img.dataset.s)+1;if(k<servers.length){img.dataset.s=String(k);img.src=servers[k].replace('{z}',z).replace('{x}',wx).replace('{y}',ty);}};img.onload=()=>img.classList.add('is-on');img.src=servers[0].replace('{z}',z).replace('{x}',wx).replace('{y}',ty);tiles.set(key,img);layer.append(img);}
    img.style.transform=`translate3d(${Math.round(tx*T-x0)}px,${Math.round(ty*T-y0)}px,0)`;}
   tiles.forEach((img,key)=>{if(!keep.has(key)){img.remove();tiles.delete(key);}});};
  const changed=()=>{clearTimeout(moveT);moveT=setTimeout(async()=>{const c=api.center();usePoint(c.lat,c.lng,'map');mapStatus.textContent='Vérification…';await zoneCheck(c.lat,c.lng,mapStatus);
   if(pcI&&!pcI.value){try{const r=await fetch(`https://photon.komoot.io/reverse?lat=${c.lat}&lon=${c.lng}&lang=fr&limit=1`);const d=await r.json();const p=(d.features&&d.features[0]&&d.features[0].properties)||{};if(p.postcode&&!pcI.value)pcI.value=p.postcode;if((!input.value||input.value.trim().length<6)&&p.street)input.value=[p.housenumber,p.street,p.postcode,p.city].filter(Boolean).join(' ');}catch(e){}}},450);};
  const zoomTo=(nz,ax,ay)=>{nz=Math.max(MIN,Math.min(MAX,nz));if(nz===z)return;const w=el.clientWidth,h=el.clientHeight;ax=ax??w/2;ay=ay??h/2;const k=Math.pow(2,nz-z);const px=cx-w/2+ax,py=cy-h/2+ay;cx=px*k-(ax-w/2);cy=py*k-(ay-h/2);z=nz;layer.replaceChildren();tiles.clear();draw();changed();};
  const pts=new Map();let pinch=0,last=null;
  el.addEventListener('pointerdown',e=>{if(e.target.closest('button,a'))return;el.setPointerCapture(e.pointerId);pts.set(e.pointerId,[e.clientX,e.clientY]);last=[e.clientX,e.clientY];if(pts.size===2){const [a,b]=[...pts.values()];pinch=Math.hypot(a[0]-b[0],a[1]-b[1]);}el.classList.add('is-drag');});
  el.addEventListener('pointermove',e=>{if(!pts.has(e.pointerId))return;pts.set(e.pointerId,[e.clientX,e.clientY]);
   if(pts.size===2){const [a,b]=[...pts.values()];const d=Math.hypot(a[0]-b[0],a[1]-b[1]);if(pinch&&d/pinch>1.45){pinch=d;zoomTo(z+1);}else if(pinch&&d/pinch<.69){pinch=d;zoomTo(z-1);}return;}
   if(last){cx-=e.clientX-last[0];cy-=e.clientY-last[1];last=[e.clientX,e.clientY];draw();}});
  const up=e=>{if(!pts.has(e.pointerId))return;pts.delete(e.pointerId);if(pts.size<2)pinch=0;if(!pts.size){last=null;el.classList.remove('is-drag');changed();}else{last=[...pts.values()][0];}};
  el.addEventListener('pointerup',up);el.addEventListener('pointercancel',up);
  el.addEventListener('dblclick',e=>{const r=el.getBoundingClientRect();zoomTo(z+1,e.clientX-r.left,e.clientY-r.top);});
  el.addEventListener('wheel',e=>{if(!e.ctrlKey&&!el.classList.contains('is-active'))return;e.preventDefault();const r=el.getBoundingClientRect();zoomTo(z+(e.deltaY<0?1:-1),e.clientX-r.left,e.clientY-r.top);},{passive:false});
  el.addEventListener('click',()=>el.classList.add('is-active'));
  el.querySelectorAll('[data-zoom]').forEach(b=>b.addEventListener('click',()=>zoomTo(z+Number(b.dataset.zoom))));
  const loc=el.querySelector('.mo3-map-locate');
  if(loc){if(!('geolocation' in navigator))loc.hidden=true;else loc.addEventListener('click',()=>{mapStatus.textContent='Localisation…';navigator.geolocation.getCurrentPosition(p=>{[cx,cy]=proj(p.coords.latitude,p.coords.longitude,z);if(z<17)z=17,[cx,cy]=proj(p.coords.latitude,p.coords.longitude,17),layer.replaceChildren(),tiles.clear();draw();changed();},()=>{mapStatus.textContent='Position indisponible. Déplacez la carte manuellement.';},{enableHighAccuracy:true,timeout:9000,maximumAge:60000});});}
  addEventListener('resize',()=>draw());
  const api={center:()=>{const w=el.clientWidth,h=el.clientHeight;return unproj(cx,cy,z);},refresh:()=>draw()};
  requestAnimationFrame(()=>{draw();changed();});
  return api;
 }
 if(panel&&!panel.hidden){if(pcI)pcI.required=true;map=initMap();}
}
const dateForm=document.querySelector('#mo3-date-form');
if(dateForm){
 const cal=document.querySelector('#mo3-cal'),field=document.querySelector('#mo3-date-value');
 const min=dateForm.dataset.min,max=dateForm.dataset.max,noSunday=dateForm.dataset.sunday!=='0';
 const parse=s=>{const [y,m,d]=s.split('-').map(Number);return new Date(y,m-1,d);};
 const iso=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
 const minD=parse(min),maxD=parse(max);
 let cursor=field.value?parse(field.value):new Date(minD);
 if(cursor<minD)cursor=new Date(minD);
 const allowed=d=>d>=minD&&d<=maxD&&!(noSunday&&d.getDay()===0);
 const draw=()=>{
  const y=cursor.getFullYear(),m=cursor.getMonth();
  const first=new Date(y,m,1),start=(first.getDay()+6)%7,days=new Date(y,m+1,0).getDate();
  const names=['Lun','Mar','Mer','Jeu','Ven','Sam','Dim'];
  cal.replaceChildren();
  const head=document.createElement('div');head.className='mo3-cal-head';
  const prev=document.createElement('button');prev.type='button';prev.textContent='‹';prev.setAttribute('aria-label','Mois précédent');
  const next=document.createElement('button');next.type='button';next.textContent='›';next.setAttribute('aria-label','Mois suivant');
  const title=document.createElement('strong');title.textContent=first.toLocaleDateString('fr-FR',{month:'long',year:'numeric'});
  const canPrev=new Date(y,m,1)>minD,canNext=new Date(y,m+1,0)<maxD;
  prev.disabled=!canPrev;next.disabled=!canNext;
  prev.addEventListener('click',()=>{cursor=new Date(y,m-1,1);draw();});
  next.addEventListener('click',()=>{cursor=new Date(y,m+1,1);draw();});
  head.append(prev,title,next);cal.append(head);
  const grid=document.createElement('div');grid.className='mo3-cal-grid';
  names.forEach(n=>{const s=document.createElement('span');s.textContent=n;grid.append(s);});
  for(let i=0;i<start;i++)grid.append(document.createElement('span'));
  for(let day=1;day<=days;day++){
   const date=new Date(y,m,day),b=document.createElement('button');b.type='button';b.textContent=String(day);
   const ok=allowed(date);b.disabled=!ok;if(field.value===iso(date))b.className='is-on';b.setAttribute('aria-pressed',field.value===iso(date)?'true':'false');
   b.addEventListener('click',()=>{if(!ok)return;field.value=iso(date);draw();});
   grid.append(b);
  }
  cal.append(grid);
 };
 if(cal){dateForm.classList.add('mo3-has-cal');draw();}
}
});
