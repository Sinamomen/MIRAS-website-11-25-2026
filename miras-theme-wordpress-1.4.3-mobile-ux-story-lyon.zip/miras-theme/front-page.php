<?php
/**
 * Front page template — MIRAS homepage.
 *
 * @package MIRAS
 */
get_header();

$theme_uri = get_template_directory_uri();
$story_url = home_url( '/notre-histoire/' );
$message_url = home_url( '/message-de-miras/' );
$compose_url = home_url( '/composez-votre-commande/' );

$food_items = array(
    array(
        'file' => '01-poulet-riz.webp',
        'name' => 'Khoresht Morgh',
        'description' => 'Poulet mijoté, riz parfumé et épices délicates.',
        'ingredients' => 'Poulet, riz, épices délicates.',
    ),
    array(
        'file' => '02-loobia-polo.webp',
        'name' => 'Loubia Polo',
        'description' => 'Un mélange généreux et parfumé.',
        'ingredients' => 'Riz, haricots verts, viande hachée, herbes et épices.',
    ),
    array(
        'file' => '03-gheymeh.webp',
        'name' => 'Gheymeh',
        'description' => 'Veau mijoté, pois cassés, riz parfumé et pommes de terre frites.',
        'ingredients' => 'Veau, pois cassés, riz, pommes de terre et épices.',
    ),
    array(
        'file' => '04-olivieh.webp',
        'name' => 'Olivieh',
        'description' => 'Une salade originale à partager.',
        'ingredients' => 'Pommes de terre, carottes, petits pois, œufs, poulet et mayonnaise.',
    ),
    array(
        'file' => '05-mirza-ghasemi.webp',
        'name' => 'Mirza Ghasemi',
        'description' => 'Un goût unique à découvrir.',
        'ingredients' => 'Aubergines, tomates, œufs, ail et épices.',
    ),
);

$modal_items = array();
foreach ( $food_items as $food ) {
    $product = null;
    $product_id = 0;
    $name_key = sanitize_title( $food['name'] );
    if ( function_exists( 'mo_ids' ) ) {
        foreach ( (array) mo_ids() as $candidate_id ) {
            $candidate = wc_get_product( $candidate_id );
            if ( $candidate instanceof WC_Product && strcasecmp( remove_accents( $candidate->get_name() ), remove_accents( $food['name'] ) ) === 0 ) {
                $product = $candidate; $product_id = $candidate->get_id(); break;
            }
        }
    }
    if ( ! $product && function_exists( 'wc_get_products' ) ) {
        $found = wc_get_products( array( 'limit' => 10, 'status' => 'publish', 'search' => $food['name'] ) );
        foreach ( $found as $candidate ) {
            if ( $candidate instanceof WC_Product && stripos( remove_accents( $candidate->get_name() ), remove_accents( $food['name'] ) ) !== false ) {
                $product = $candidate; $product_id = $candidate->get_id(); break;
            }
        }
    }
    $description = $food['description'];
    if ( $product ) {
        $short = trim( wp_strip_all_tags( $product->get_short_description() ) );
        if ( $short !== '' ) {
            $description = $short;
        }
    }
    $ingredients = $food['ingredients'];
    if ( $product ) {
        $meta = get_post_meta( $product_id, '_mxe_ingredients', true );
        if ( is_string( $meta ) && trim( $meta ) !== '' ) {
            $ingredients = wp_strip_all_tags( $meta );
        }
    }
    $image_url = $theme_uri . '/assets/images/food/' . $food['file'];
    $isolated = $theme_uri . '/assets/images/food-isolated/' . $name_key . '.webp';
    $modal_items[ $name_key ] = array(
        'name'        => $food['name'],
        'description' => $description,
        'ingredients' => $ingredients,
        'image'       => $image_url,
        'isolated'    => $isolated,
        'detailUrl'   => home_url( '/plat/' . $name_key . '/' ),
        'price'       => $product ? wc_price( $product->get_price() ) : '',
    );
}
?>

<main class="miras-home">
    <section id="accueil" class="hero-cinematic" aria-labelledby="hero-title">
        <picture>
            <source media="(max-width: 860px)" srcset="<?php echo esc_url( $theme_uri . '/assets/images/miras-hero-wide-768.webp' ); ?>" type="image/webp">
            <source srcset="<?php echo esc_url( $theme_uri . '/assets/images/miras-hero-wide.webp' ); ?>" type="image/webp">
            <img src="<?php echo esc_url( $theme_uri . '/assets/images/miras-hero-wide.png' ); ?>" alt="<?php esc_attr_e( 'Deux hommes portant des boîtes repas MIRAS dans les rues de Lyon', 'miras' ); ?>" fetchpriority="high" decoding="async" width="1280" height="853">
        </picture>
        <div class="hero-ink-layer" aria-hidden="true">
            <span class="hero-ink-blob hero-ink-blob-a"></span>
            <span class="hero-ink-blob hero-ink-blob-b"></span>
            <span class="hero-ink-blob hero-ink-blob-c"></span>
            <img class="hero-lily hero-lily-left" src="<?php echo esc_url( $theme_uri . '/assets/images/miras-lily-emblem.svg' ); ?>" alt="" aria-hidden="true" loading="lazy" width="220" height="220">
            <img class="hero-lily hero-lily-right" src="<?php echo esc_url( $theme_uri . '/assets/images/miras-lily-emblem.svg' ); ?>" alt="" aria-hidden="true" loading="lazy" width="180" height="180">
        </div>
        <div class="hero-copy">
            <p class="hero-kicker"><?php esc_html_e( 'MIRAS', 'miras' ); ?></p>
            <h1 id="hero-title"><?php esc_html_e( 'L’émotion d’un souvenir.', 'miras' ); ?><br><?php esc_html_e( 'Le goût d’un héritage.', 'miras' ); ?></h1>
            <p class="lead"><?php esc_html_e( 'Des repas préparés avec amour, inspirés par la tradition et imaginés pour accompagner chaque instant de votre quotidien.', 'miras' ); ?></p>
            <a href="#nos-abonnements" class="btn btn-primary"><?php esc_html_e( 'Découvrir nos formules', 'miras' ); ?></a>
        </div>
        <div class="hero-burgundy-bridge" aria-hidden="true"></div>
    </section>

    <section id="nos-repas" class="food-gallery-section" aria-labelledby="food-gallery-title">
        <div class="container">
            <div class="section-title food-gallery-heading">
                <p class="eyebrow"><?php esc_html_e( 'L’art de la table', 'miras' ); ?></p>
                <h2 id="food-gallery-title"><?php esc_html_e( 'Nos plats emblématiques', 'miras' ); ?></h2>
            </div>
            <div class="miras-food-stage" data-food-stage aria-label="Plats emblématiques MIRAS">
                <div class="miras-food-column miras-food-column-left" data-food-column="left">
                    <div class="miras-food-track-inner" data-food-track>
                        <?php foreach ( array( $food_items[0], $food_items[1] ) as $food_item ) : $slug = sanitize_title( $food_item['name'] ); ?>
                            <button class="food-card miras-gallery-card" type="button" data-food-slug="<?php echo esc_attr( $slug ); ?>" aria-haspopup="dialog" aria-controls="miras-food-modal">
                                <img src="<?php echo esc_url( $theme_uri . '/assets/images/food/' . $food_item['file'] ); ?>" alt="<?php echo esc_attr( $food_item['name'] ); ?>" loading="lazy" decoding="async" width="1200" height="1200">
                                <span class="food-card-name"><?php echo esc_html( $food_item['name'] ); ?></span>
                            </button>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="miras-food-column miras-food-column-featured" data-food-column="featured">
                    <?php $featured_food = $food_items[4]; $featured_slug = sanitize_title( $featured_food['name'] ); ?>
                    <button class="food-card miras-gallery-card miras-gallery-card-featured" type="button" data-food-featured data-food-slug="<?php echo esc_attr( $featured_slug ); ?>" aria-haspopup="dialog" aria-controls="miras-food-modal">
                        <img src="<?php echo esc_url( $theme_uri . '/assets/images/food/' . $featured_food['file'] ); ?>" alt="<?php echo esc_attr( $featured_food['name'] ); ?>" loading="lazy" decoding="async" width="1200" height="1200">
                        <span class="miras-featured-tag" aria-hidden="true">MIRAS</span>
                        <span class="food-card-name"><?php echo esc_html( $featured_food['name'] ); ?></span>
                    </button>
                </div>

                <div class="miras-food-column miras-food-column-right" data-food-column="right">
                    <div class="miras-food-track-inner" data-food-track>
                        <?php foreach ( array( $food_items[2], $food_items[3] ) as $food_item ) : $slug = sanitize_title( $food_item['name'] ); ?>
                            <button class="food-card miras-gallery-card" type="button" data-food-slug="<?php echo esc_attr( $slug ); ?>" aria-haspopup="dialog" aria-controls="miras-food-modal">
                                <img src="<?php echo esc_url( $theme_uri . '/assets/images/food/' . $food_item['file'] ); ?>" alt="<?php echo esc_attr( $food_item['name'] ); ?>" loading="lazy" decoding="async" width="1200" height="1200">
                                <span class="food-card-name"><?php echo esc_html( $food_item['name'] ); ?></span>
                            </button>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <noscript>
                <div class="miras-food-noscript" aria-label="Plats MIRAS sans animation">
                    <?php foreach ( $food_items as $food_item ) : ?>
                        <div class="miras-gallery-card miras-gallery-card-static">
                            <img src="<?php echo esc_url( $theme_uri . '/assets/images/food/' . $food_item['file'] ); ?>" alt="<?php echo esc_attr( $food_item['name'] ); ?>" width="1200" height="1200">
                            <span class="food-card-name"><?php echo esc_html( $food_item['name'] ); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </noscript>
        </div>
    </section>

    <section id="miras-message" class="message-section" aria-labelledby="message-title">
        <div class="message-frame">
            <div class="message-emblem" aria-hidden="true"><img src="<?php echo esc_url( $theme_uri . '/assets/images/miras-lily-emblem.svg' ); ?>" alt="" width="150" height="150"></div>
            <div class="message-copy">
                <p class="eyebrow"><?php esc_html_e( 'Le goût d’un héritage', 'miras' ); ?></p>
                <h2 id="message-title"><?php esc_html_e( 'Un message de MIRAS', 'miras' ); ?></h2>
                <p><?php esc_html_e( 'Une pensée, un instant, une émotion.', 'miras' ); ?></p>
            </div>
            <a class="message-cta" href="<?php echo esc_url( $message_url ); ?>"><?php esc_html_e( 'Découvrir le message', 'miras' ); ?></a>
        </div>
    </section>

    <section id="notre-concept" class="section concept-section" aria-labelledby="concept-title">
        <div class="container">
            <div class="section-title concept-heading">
                <span class="concept-ornament" aria-hidden="true"></span>
                <h2 id="concept-title"><?php esc_html_e( 'Notre concept', 'miras' ); ?></h2>
            </div>
            <div class="pillars">
                <article class="pillar" data-value="I">
                    <span class="pillar-index" aria-hidden="true">I</span>
                    <h3><?php esc_html_e( 'Authenticité', 'miras' ); ?></h3>
                    <p><?php esc_html_e( 'Des recettes traditionnelles inspirées d’un riche héritage culinaire.', 'miras' ); ?></p>
                </article>
                <article class="pillar" data-value="II">
                    <span class="pillar-index" aria-hidden="true">II</span>
                    <h3><?php esc_html_e( 'Qualité', 'miras' ); ?></h3>
                    <p><?php esc_html_e( 'Des repas préparés par un chef professionnel à l’expérience culinaire internationale, avec des ingrédients soigneusement sélectionnés.', 'miras' ); ?></p>
                </article>
                <article class="pillar" data-value="III">
                    <span class="pillar-index" aria-hidden="true">III</span>
                    <h3><?php esc_html_e( 'Accessibilité', 'miras' ); ?></h3>
                    <p><?php esc_html_e( 'Des formules flexibles et des repas accessibles, conçus pour le quotidien des étudiants et des professionnels.', 'miras' ); ?></p>
                </article>
            </div>
        </div>
    </section>

    <section id="miras-heritage" class="heritage-section" aria-labelledby="heritage-title">
        <div class="heritage-atmosphere" aria-hidden="true"></div>
        <div class="container heritage-inner">
            <figure class="heritage-media">
                <picture>
                    <source srcset="<?php echo esc_url( $theme_uri . '/assets/images/miras-heritage.webp' ); ?>" type="image/webp">
                    <img src="<?php echo esc_url( $theme_uri . '/assets/images/miras-heritage.png' ); ?>" alt="MIRAS — cuisine, héritage et plats emblématiques" loading="lazy" decoding="async" width="1280" height="853">
                </picture>
            </figure>
        </div>
    </section>

    <section id="notre-histoire-apercu" class="section miras-history-cinema" aria-labelledby="history-cinema-title">
        <div class="container miras-history-cinema-inner">
            <div class="miras-history-cinema-intro">
                <p class="eyebrow"><?php esc_html_e( 'Notre histoire', 'miras' ); ?></p>
                <h2 id="history-cinema-title"><?php esc_html_e( 'Une histoire racontée en quatre chapitres.', 'miras' ); ?></h2>
            </div>
            <div class="miras-history-cinema-grid" data-history-cinema>
                <figure class="miras-history-cinema-media">
                    <img src="<?php echo esc_url( $theme_uri . '/assets/images/story/01-a-l-origine.webp' ); ?>" alt="MIRAS — à l’origine, deux personnes cuisinent ensemble" width="768" height="1152" loading="lazy" decoding="async">
                </figure>
                <div class="miras-history-chapters">
                    <article class="miras-history-chapter is-visible">
                        <span class="miras-history-index">01</span>
                        <h3><?php esc_html_e( 'Tout commence par une émotion.', 'miras' ); ?></h3>
                        <p><?php esc_html_e( 'Un parfum, une table, un geste simple. La cuisine fait naître des souvenirs qui nous rapprochent.', 'miras' ); ?></p>
                    </article>
                    <article class="miras-history-chapter">
                        <span class="miras-history-index">02</span>
                        <h3><?php esc_html_e( 'Le goût des souvenirs.', 'miras' ); ?></h3>
                        <p><?php esc_html_e( 'Un plat peut traverser les années et les frontières, réveiller une présence, une joie, un moment partagé.', 'miras' ); ?></p>
                    </article>
                    <article class="miras-history-chapter">
                        <span class="miras-history-index">03</span>
                        <h3><?php esc_html_e( 'Plus qu’un repas, un moment à partager.', 'miras' ); ?></h3>
                        <p><?php esc_html_e( 'Autour d’une même table, les différences s’effacent. Chaque bouchée devient un langage universel.', 'miras' ); ?></p>
                    </article>
                    <article class="miras-history-chapter">
                        <span class="miras-history-index">04</span>
                        <h3><?php esc_html_e( 'Une histoire qui continue avec vous.', 'miras' ); ?></h3>
                        <p><?php esc_html_e( 'MIRAS célèbre les gestes sincères du quotidien, l’authenticité des savoir-faire et le plaisir de partager.', 'miras' ); ?></p>
                        <a class="history-teaser-link" href="<?php echo esc_url( $story_url ); ?>"><?php esc_html_e( 'DÉCOUVRIR L’UNIVERS MIRAS', 'miras' ); ?><span aria-hidden="true">→</span></a>
                    </article>
                </div>
            </div>
        </div>
    </section>

    <section id="nos-abonnements" class="section pricing-section" aria-labelledby="pricing-title">
        <div class="container">
            <div class="section-title pricing-heading"><p class="eyebrow"><?php esc_html_e( 'Nos formules', 'miras' ); ?></p><h2 id="pricing-title"><?php esc_html_e( 'Choisissez votre rythme.', 'miras' ); ?></h2></div>
            <div class="plans pricing-premium">
                <a class="plan-card" href="<?php echo esc_url( home_url( '/composez-votre-commande/?mode=abonnement&pack=1' ) ); ?>">
                    <span class="plan-number">01</span><h3><?php esc_html_e( '1 repas', 'miras' ); ?></h3><div class="per-meal">6,85 € <small>/ repas</small></div>
                </a>
                <a class="plan-card featured" href="<?php echo esc_url( home_url( '/composez-votre-commande/?mode=abonnement&pack=5' ) ); ?>">
                    <span class="plan-number">02</span><h3><?php esc_html_e( '5 repas', 'miras' ); ?></h3><div class="per-meal">6,50 € <small>/ repas</small></div>
                </a>
                <a class="plan-card" href="<?php echo esc_url( home_url( '/composez-votre-commande/?mode=abonnement&pack=10' ) ); ?>">
                    <span class="plan-number">03</span><h3><?php esc_html_e( '10 repas', 'miras' ); ?></h3><div class="per-meal">6,25 € <small>/ repas</small></div>
                </a>
            </div>
        </div>
    </section>

    <?php echo do_shortcode( '[miras_coins]' ); ?>

    <section id="faq" class="section faq-section" aria-labelledby="faq-title">
        <div class="container">
            <div class="section-title faq-heading">
                <span class="faq-ornament" aria-hidden="true"></span>
                <h2 id="faq-title"><?php esc_html_e( 'Questions fréquentes', 'miras' ); ?></h2>
                <p class="faq-subtitle mxe-whisper"><?php esc_html_e( 'Chaque instant mérite une attention particulière.', 'miras' ); ?></p>
            </div>
            <div class="faq-list">
                <div class="faq-item"><button class="faq-q" type="button" aria-expanded="false"><span>Quels sont les modes de livraison disponibles ?</span><span class="chevron" aria-hidden="true">+</span></button><div class="faq-a"><p>Deux options sont disponibles :</p><p>Retrait gratuit sur les campus universitaires partenaires.</p><p>Livraison à domicile, selon votre adresse, avec des frais compris entre 2 € et 4 €.</p></div></div>
                <div class="faq-item"><button class="faq-q" type="button" aria-expanded="false"><span>Quelles sont les formules proposées par MIRAS ?</span><span class="chevron" aria-hidden="true">+</span></button><div class="faq-a"><p>MIRAS propose trois options :</p><p>À l’unité. 5 repas. 10 repas.</p><p>Chaque formule permet de profiter de tarifs adaptés à la quantité commandée.</p></div></div>
                <div class="faq-item"><button class="faq-q" type="button" aria-expanded="false"><span>Comment fonctionnent les tarifs ?</span><span class="chevron" aria-hidden="true">+</span></button><div class="faq-a"><p>Les tarifs sont dégressifs selon le nombre de repas commandés :</p><p>De 1 à 4 repas : 6,85 € par repas.</p><p>De 5 à 9 repas : 6,50 € par repas.</p><p>À partir de 10 repas : 6,25 € par repas.</p></div></div>
                <div class="faq-item"><button class="faq-q" type="button" aria-expanded="false"><span>La livraison à domicile est-elle gratuite ?</span><span class="chevron" aria-hidden="true">+</span></button><div class="faq-a"><p>Non. Les frais de livraison à domicile dépendent de votre adresse et varient entre 2 € et 4 €.</p><p>Le retrait sur les campus universitaires partenaires est gratuit.</p></div></div>
                <div class="faq-item"><button class="faq-q" type="button" aria-expanded="false"><span>MIRAS est-il disponible à Paris ?</span><span class="chevron" aria-hidden="true">+</span></button><div class="faq-a"><p>MIRAS arrive bientôt à Paris.</p><p>Restez connectés pour découvrir notre prochaine destination.</p></div></div>
            </div>
        </div>
    </section>

    <div id="miras-food-modal" class="miras-food-modal" hidden aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="miras-food-modal-title">
        <div class="food-modal-backdrop" data-food-modal-close></div>
        <div class="food-modal-panel" role="document">
            <button type="button" class="food-modal-close" aria-label="Fermer" data-food-modal-close>×</button>
            <div class="food-modal-image"><img src="" alt="" data-modal-image></div>
            <div class="food-modal-copy">
                <p class="eyebrow">MIRAS · PLAT</p>
                <h2 id="miras-food-modal-title" data-modal-name></h2>
                <p class="food-modal-description" data-modal-description></p>
                <div class="food-modal-detail"><h3>Composition</h3><p data-modal-ingredients></p></div>
                <p class="food-modal-price" data-modal-price></p>
                <a class="food-modal-link" href="#" data-modal-link>Voir la fiche complète <span aria-hidden="true">→</span></a>
            </div>
        </div>
    </div>
</main>
<script type="application/json" id="miras-food-data"><?php echo wp_json_encode( $modal_items, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ); ?></script>
<?php get_footer(); ?>
