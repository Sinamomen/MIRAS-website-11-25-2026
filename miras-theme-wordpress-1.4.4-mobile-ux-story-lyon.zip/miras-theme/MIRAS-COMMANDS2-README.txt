MIRAS Theme 1.4.0 — Commands Pack 2
Source: mirascommands2.odt

Highlights: unified luxury visual system, cinematic hero transition, premium food showcase,
food detail modal, exact supplied heritage image, exact first Notre Histoire image,
luxury hamburger navigation, concept/FAQ redesign, icon-only contact, responsive/performance fixes.

Food cards now open the in-page cinematic food modal per the latest command set.
The complete /plat/<slug>/ page remains available from the modal.

MIRAS 1.4.1: mobile menu-only typography fix; mobile hero contain/blank-space fix; stable five-dish editorial gallery; homepage-only four-chapter Notre Histoire; left-aligned premium contact graphics. Desktop/tablet navigation rules remain unchanged.
