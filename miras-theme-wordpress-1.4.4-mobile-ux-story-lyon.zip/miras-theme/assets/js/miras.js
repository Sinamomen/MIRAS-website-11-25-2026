/* MIRAS 1.4 — unified navigation, food carousel/modal and FAQ interactions. */
(function(){
'use strict';
const D=document,W=window,$=s=>D.querySelector(s),$$=s=>Array.from(D.querySelectorAll(s));
const reduce=W.matchMedia&&W.matchMedia('(prefers-reduced-motion: reduce)').matches;
const ready=fn=>D.readyState!=='loading'?fn():D.addEventListener('DOMContentLoaded',fn,{once:true});

function menu(){
 const header=$('.site-header'),toggle=$('#navToggle'),nav=$('#mainNav');
 if(!header||!toggle||!nav)return;
 const set=open=>{header.classList.toggle('menu-open',open);toggle.setAttribute('aria-expanded',open?'true':'false');toggle.setAttribute('aria-label',open?'Fermer le menu':'Ouvrir le menu');D.body.classList.toggle('nav-locked',open);};
 toggle.addEventListener('click',()=>set(!header.classList.contains('menu-open')));
 nav.addEventListener('click',e=>{if(e.target.closest('a'))set(false);});
 D.addEventListener('keydown',e=>{if(e.key==='Escape'&&header.classList.contains('menu-open'))set(false);});
}
function faq(){
 const items=$$('.faq-item');
 if(!items.length)return;
 const close=(item)=>{const a=item.querySelector('.faq-a');item.classList.remove('open');item.querySelector('.faq-q')?.setAttribute('aria-expanded','false');if(a){a.style.maxHeight='0px';a.setAttribute('aria-hidden','true');}};
 items.forEach((item,i)=>{const q=item.querySelector('.faq-q'),a=item.querySelector('.faq-a');if(!q||!a)return;q.id=q.id||('faq-q-'+i);a.id=a.id||('faq-a-'+i);q.setAttribute('aria-controls',a.id);q.setAttribute('aria-expanded','false');a.setAttribute('role','region');a.setAttribute('aria-labelledby',q.id);a.setAttribute('aria-hidden','true');close(item);
   const open=()=>{items.forEach(other=>{if(other!==item)close(other);});const isOpen=!item.classList.contains('open');if(isOpen){item.classList.add('open');q.setAttribute('aria-expanded','true');a.setAttribute('aria-hidden','false');a.style.maxHeight=a.scrollHeight+'px';}else close(item);};
   q.addEventListener('click',e=>{e.preventDefault();open();});q.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();open();}});
 });
 addEventListener('resize',()=>items.forEach(item=>{if(item.classList.contains('open')){const a=item.querySelector('.faq-a');if(a)a.style.maxHeight=a.scrollHeight+'px';}}),{passive:true});
}
function foodGallery(){
 const stage=$('[data-food-stage]');
 if(!stage)return;
 const images=Array.from(stage.querySelectorAll('img'));
 const activate=()=>{
   if(reduce){stage.classList.add('miras-food-static');return;}
   stage.classList.add('miras-food-enhanced');
   if('IntersectionObserver' in W){
     const io=new IntersectionObserver(entries=>entries.forEach(en=>stage.classList.toggle('miras-food-inview',en.isIntersecting)),{threshold:.12});
     io.observe(stage);
   }else stage.classList.add('miras-food-inview');
 };
 let pending=images.filter(img=>!img.complete).length;
 if(!pending)activate();
 images.forEach(img=>{if(img.complete)return;const done=()=>{pending--;if(pending<=0)activate();};img.addEventListener('load',done,{once:true});img.addEventListener('error',done,{once:true});});
 W.addEventListener('load',activate,{once:true});
 const pause=()=>stage.classList.add('miras-food-paused');
 const resume=()=>stage.classList.remove('miras-food-paused');
 stage.addEventListener('mouseenter',pause);stage.addEventListener('mouseleave',resume);stage.addEventListener('focusin',pause);stage.addEventListener('focusout',e=>{if(!stage.contains(e.relatedTarget))resume();});
 D.addEventListener('visibilitychange',()=>{if(D.hidden)pause();else resume();});
}

function foodModal(){
 const modal=$('#miras-food-modal'),dataEl=$('#miras-food-data');if(!modal||!dataEl)return;
 let data={};try{data=JSON.parse(dataEl.textContent||'{}')}catch(_){data={};}
 const image=$('[data-modal-image]',modal),name=$('[data-modal-name]',modal),desc=$('[data-modal-description]',modal),ingredients=$('[data-modal-ingredients]',modal),price=$('[data-modal-price]',modal),link=$('[data-modal-link]',modal);
 let prevFocus=null;
 const close=()=>{modal.hidden=true;modal.setAttribute('aria-hidden','true');D.body.classList.remove('miras-modal-open');if(prevFocus){prevFocus.focus();prevFocus=null;}};
 const open=slug=>{const item=data[slug];if(!item)return;prevFocus=D.activeElement;modal.hidden=false;modal.setAttribute('aria-hidden','false');D.body.classList.add('miras-modal-open');name.textContent=item.name;desc.textContent=item.description||'';ingredients.textContent=item.ingredients||'Informations disponibles sur la fiche du plat.';price.innerHTML=item.price||'';link.href=item.detailUrl||'#';image.alt=item.name;image.src=item.isolated||item.image;image.onerror=()=>{if(image.src!==item.image)image.src=item.image;};setTimeout(()=>modal.querySelector('.food-modal-close')?.focus(),80);};
 $$('.food-card').forEach(card=>card.addEventListener('click',()=>open(card.dataset.foodSlug)));
 $$('[data-food-modal-close]').forEach(x=>x.addEventListener('click',e=>{e.preventDefault();close();}));
 D.addEventListener('keydown',e=>{if(e.key==='Escape'&&!modal.hidden)close();});
}
function homepageHistory(){
 const root=$('[data-history-cinema]');
 if(!root)return;
 const chapters=$$('.miras-history-chapter',root);
 if(!chapters.length)return;
 const reveal=el=>el.classList.add('is-visible');
 root.classList.add('miras-history-js');
 if(reduce||!('IntersectionObserver' in W)){chapters.forEach(reveal);return;}
 const io=new IntersectionObserver(entries=>entries.forEach(en=>{if(en.isIntersecting){reveal(en.target);io.unobserve(en.target);}}),{threshold:.18,rootMargin:'0px 0px -10% 0px'});
 chapters.forEach((ch,i)=>{if(i===0&&ch.classList.contains('is-visible'))reveal(ch);else io.observe(ch);});
}
function featuredFoodReveal(){
 const card=$('[data-food-featured]'); if(!card)return;
 if(reduce){card.classList.add('miras-featured-visible');return;}
 if(!('IntersectionObserver' in W)){card.classList.add('miras-featured-visible');return;}
 card.classList.add('miras-featured-observe');
 const io=new IntersectionObserver(entries=>entries.forEach(en=>{if(en.isIntersecting){card.classList.add('miras-featured-visible');card.classList.remove('miras-featured-observe');io.disconnect();}}),{threshold:.18});
 io.observe(card);
 let frame=0;
 const updateDepth=()=>{
   if(innerWidth>767)return;
   if(frame)return;
   frame=requestAnimationFrame(()=>{
     frame=0;
     const bounds=card.getBoundingClientRect();
     if(bounds.bottom<0||bounds.top>innerHeight){card.style.setProperty('--miras-featured-depth','0px');return;}
     const offset=(bounds.top+bounds.height/2-innerHeight/2)/innerHeight;
     const depth=Math.max(-3,Math.min(3,offset*-6));
     card.style.setProperty('--miras-featured-depth',depth.toFixed(2)+'px');
   });
 };
 W.addEventListener('scroll',updateDepth,{passive:true});
 W.addEventListener('resize',updateDepth,{passive:true});
 updateDepth();
}
function footerContact(){
 // Keep contact icons icon-only even when the Experience plugin inspects the footer.
 $$('.miras-social-icon,.mxe-contact-link').forEach(a=>{if(a.querySelector('svg')){a.removeAttribute('title');if(!a.getAttribute('aria-label'))a.setAttribute('aria-label',a.classList.contains('mxe-contact-ig')?'Instagram MIRAS':'Email MIRAS');Array.from(a.childNodes).forEach(n=>{if(n.nodeType===3)n.remove();});}});
}
ready(()=>{menu();faq();foodGallery();featuredFoodReveal();homepageHistory();foodModal();footerContact();});
})();
