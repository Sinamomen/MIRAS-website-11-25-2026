<?php /** Footer template. @package MIRAS */ ?>
<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div><h4><?php esc_html_e( 'Navigation', 'miras' ); ?></h4><?php if ( has_nav_menu( 'footer' ) ) { wp_nav_menu( array( 'theme_location'=>'footer', 'container'=>false ) ); } ?></div>
      <div class="miras-contact-column"><h4><?php esc_html_e( 'Contact', 'miras' ); ?></h4>
        <div class="miras-footer-social miras-contact-art" aria-label="<?php esc_attr_e( 'Nous contacter', 'miras' ); ?>">
          <a class="miras-social-icon miras-social-email" href="mailto:mirasfood@yahoo.com" aria-label="Email MIRAS" title="Email MIRAS">
            <svg viewBox="0 0 96 96" aria-hidden="true">
              <defs><linearGradient id="mirasMailBg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f8efe4"/><stop offset="1" stop-color="#d8b98a"/></linearGradient><linearGradient id="mirasMailBody" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fffaf3"/><stop offset="1" stop-color="#eadbc8"/></linearGradient><filter id="mirasMailShadow"><feDropShadow dx="0" dy="7" stdDeviation="6" flood-color="#160b11" flood-opacity=".28"/></filter></defs>
              <circle cx="48" cy="48" r="44" fill="url(#mirasMailBg)"/>
              <circle cx="48" cy="48" r="39" fill="#6a1d34" opacity=".92"/>
              <rect x="20" y="29" width="56" height="40" rx="11" fill="url(#mirasMailBody)" filter="url(#mirasMailShadow)"/>
              <path d="M23 34l25 20 25-20" fill="none" stroke="#6a1d34" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M23 64l18-16M73 64L55 48" fill="none" stroke="#b98f5e" stroke-width="3.5" stroke-linecap="round" opacity=".9"/>
              <circle cx="69" cy="23" r="4" fill="#f5dec0" opacity=".85"/>
            </svg>
          </a>
          <a class="miras-social-icon miras-social-instagram instagram" href="https://www.instagram.com/mirasfoodfr/" target="_blank" rel="noopener noreferrer" aria-label="Instagram MIRAS" title="Instagram MIRAS">
            <svg viewBox="0 0 96 96" aria-hidden="true">
              <defs><linearGradient id="mirasIgBg" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#5d1730"/><stop offset=".45" stop-color="#9d466f"/><stop offset=".78" stop-color="#d29a88"/><stop offset="1" stop-color="#f1d1ad"/></linearGradient><filter id="mirasIgShadow"><feDropShadow dx="0" dy="8" stdDeviation="7" flood-color="#160b11" flood-opacity=".28"/></filter></defs>
              <circle cx="48" cy="48" r="44" fill="url(#mirasIgBg)"/>
              <circle cx="48" cy="48" r="36" fill="#f7eee3" opacity=".12"/>
              <rect x="23" y="23" width="50" height="50" rx="16" fill="none" stroke="#fff8ef" stroke-width="5.5" filter="url(#mirasIgShadow)"/>
              <circle cx="48" cy="48" r="12" fill="none" stroke="#fff8ef" stroke-width="5"/>
              <circle cx="62.5" cy="33.5" r="4" fill="#fff8ef"/>
              <path d="M34 62c4 4 9 6 14 6 9 0 17-5 21-13" fill="none" stroke="#f3d4a6" stroke-width="3" stroke-linecap="round" opacity=".9"/>
              <circle cx="70" cy="25" r="4" fill="#fff4df" opacity=".85"/>
            </svg>
          </a>
        </div>
        <p class="footer-lyon"><?php esc_html_e( 'Lyon, France', 'miras' ); ?></p>
      </div>
      <?php if ( is_active_sidebar( 'footer-widgets' ) ) : ?><div><?php dynamic_sidebar( 'footer-widgets' ); ?></div><?php endif; ?>
    </div>
    <div class="footer-bottom">&copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?> MIRAS — <?php esc_html_e( 'Tous droits réservés.', 'miras' ); ?></div>
  </div>
</footer>
<?php wp_footer(); ?></body></html>
