<?php
/**
 * MIRAS Theme functions.
 *
 * @package MIRAS
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'MIRAS_THEME_VERSION', '1.4.4' );

add_action( 'wp_enqueue_scripts', 'miras_theme_enqueue_assets', 10 );
function miras_theme_enqueue_assets() {
    wp_enqueue_style( 'miras-style', get_stylesheet_uri(), array(), MIRAS_THEME_VERSION );
    wp_enqueue_script( 'miras-script', get_template_directory_uri() . '/assets/js/miras.js', array(), MIRAS_THEME_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'miras_signature_assets', 120 );
function miras_signature_assets() {
    wp_enqueue_style( 'miras-signature', get_template_directory_uri() . '/assets/css/miras-signature.css', array( 'miras-style' ), MIRAS_THEME_VERSION );
    if ( is_front_page() ) {
        wp_enqueue_style( 'miras-home', get_template_directory_uri() . '/assets/css/miras-home.css', array( 'miras-signature' ), MIRAS_THEME_VERSION );
    }
}


add_action( 'template_redirect', 'miras_theme_legacy_routes' );
function miras_theme_legacy_routes() {
    if ( ! is_404() ) {
        return;
    }
    $path = trim( (string) wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/' );
    if ( 'nos-repas' === $path || 'nos-abonnements' === $path || 'composer' === $path ) {
        wp_safe_redirect( home_url( '/composez-votre-commande/' ), 302 );
        exit;
    }
    if ( 'faq' === $path || 'questions-frequentes' === $path ) {
        wp_safe_redirect( home_url( '/#faq' ), 302 );
        exit;
    }
}

add_action( 'after_setup_theme', 'miras_theme_setup' );
function miras_theme_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
    add_theme_support( 'custom-logo', array( 'height' => 60, 'width' => 200 ) );
    add_theme_support( 'woocommerce' );
    add_theme_support( 'align-wide' );
    add_theme_support( 'responsive-embeds' );

    register_nav_menus( array(
        'primary' => __( 'Menu principal MIRAS', 'miras' ),
        'footer'  => __( 'Menu pied de page MIRAS', 'miras' ),
    ) );
}

add_action( 'widgets_init', 'miras_theme_widgets_init' );
function miras_theme_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Zone widgets pied de page', 'miras' ),
        'id'            => 'footer-widgets',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ) );
}

/**
 * WooCommerce: declare theme support explicitly.
 */
add_action( 'after_setup_theme', 'miras_theme_woocommerce_support' );
function miras_theme_woocommerce_support() {
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );
}

add_action( 'template_redirect', 'miras_theme_story_and_legacy_routes' );
function miras_theme_story_and_legacy_routes() {
    if ( ! is_404() ) {
        return;
    }
    $path = trim( (string) wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/' );
    if ( 'notre-histoire' === $path ) {
        status_header( 200 );
        nocache_headers();
        get_header();
        echo '<main class="miras-story-page">';
        echo '<header class="story-intro"><p class="story-kicker">NOTRE HISTOIRE</p><h1>La naissance d’un héritage</h1></header>';
        miras_theme_story_chapter( '01', 'À L’ORIGINE', '01-a-l-origine.webp', 'Tout héritage commence quelque part.', 'Avant que MIRAS ne devienne un nom, il n’y avait qu’une histoire d’amour. Une cuisine, deux cœurs et des repas préparés avec tendresse.' );
        miras_theme_story_chapter( '02', 'LES SOUVENIRS', '02-les-souvenirs.webp', 'Certains instants ne nous quittent jamais.', 'La vie les a conduits sur des chemins différents. Le temps a passé. Leurs routes se sont séparées, mais les souvenirs sont restés.' );
        miras_theme_story_chapter( '03', 'LA TRANSFORMATION', '03-la-transformation.webp', 'Un amour. Mille nouveaux départs.', 'Ce qui était autrefois préparé pour une seule personne allait désormais être partagé avec le monde. Un souvenir personnel est devenu une mission. C’est ainsi que MIRAS est né.' );
        miras_theme_story_chapter( '04', 'LA PROMESSE INVISIBLE', '04-la-promesse-invisible.webp', 'Elle ne l’a jamais su. Et cela lui suffisait.', 'Un jour, elle a reçu un repas MIRAS, sans connaître l’histoire qui se cachait derrière. De loin, il l’a vue sourire. Il avait offert au monde ce qu’autrefois il lui offrait à elle. Puis, il est parti discrètement.' );
        echo '<section class="story-signature"><p>MIRAS</p><h2>Plus qu’un repas.<br><em>Un héritage.</em></h2><p>Né d’un souvenir. Fait pour être partagé.</p><p>Certaines histoires ne se racontent pas. Elles se transmettent.</p></section>';
        echo '</main>';
        get_footer();
        exit;
    }
    if ( 'nos-repas' === $path || 'nos-abonnements' === $path || 'composer' === $path ) {
        wp_safe_redirect( home_url( '/composez-votre-commande/' ), 302 );
        exit;
    }
    if ( 'faq' === $path || 'questions-frequentes' === $path ) {
        wp_safe_redirect( home_url( '/#faq' ), 302 );
        exit;
    }
}

function miras_theme_story_chapter( $number, $label, $image, $title, $text ) {
    $alt = '';
    if ( '01-a-l-origine.webp' === $image ) {
        $alt = 'Peinture : un jeune couple cuisine ensemble dans une cuisine chaleureuse, une casserole fumante devant eux.';
    } elseif ( '02-les-souvenirs.webp' === $image ) {
        $alt = 'Peinture : le couple, assis de dos, contemple un ciel étoilé au-dessus des lumières de la ville.';
    } elseif ( '03-la-transformation.webp' === $image ) {
        $alt = 'Peinture : le jeune homme prépare des repas MIRAS pour de nombreuses personnes, devant des boîtes portant le logo MIRAS.';
    } else {
        $alt = 'Peinture : une jeune femme sourit en recevant un repas MIRAS parmi ses amis ; au loin, un jeune homme la regarde.';
    }
    echo '<article class="story-chapter">';
    echo '<figure><img src="' . esc_url( get_template_directory_uri() . '/assets/images/story/' . $image ) . '" alt="' . esc_attr( $alt ) . '" loading="lazy" width="512" height="768"></figure>';
    echo '<div class="story-chapter-copy"><p class="chapter-label">' . esc_html( $number ) . ' — ' . esc_html( $label ) . '</p><h2>' . esc_html( $title ) . '</h2><p>' . esc_html( $text ) . '</p></div>';
    echo '</article>';
}

add_filter( 'wp_nav_menu_objects', 'miras_theme_navigation_labels', 20, 2 );
function miras_theme_navigation_labels( $items, $args ) {
    $has_story = false;
    foreach ( $items as $item ) {
        $title = strtolower( remove_accents( trim( wp_strip_all_tags( $item->title ) ) ) );
        if ( 'notre histoire' === $title ) {
            $item->title = 'NOTRE HISTOIRE';
            $item->url = home_url( '/notre-histoire/' );
            $has_story = true;
        } elseif ( 'nos repas' === $title || 'menu' === $title ) {
            $item->url = home_url( '/composez-votre-commande/' );
        } elseif ( 'faq' === $title || 'questions frequentes' === $title ) {
            $item->url = home_url( '/#faq' );
        }
    }
    if ( ! $has_story && 'primary' === ( $args->theme_location ?? '' ) ) {
        $story = (object) array(
            'ID' => 0,
            'db_id' => 0,
            'menu_item_parent' => 0,
            'object_id' => 0,
            'post_parent' => 0,
            'type' => 'custom',
            'object' => 'custom',
            'type_label' => 'Lien personnalisé',
            'title' => 'NOTRE HISTOIRE',
            'url' => home_url( '/notre-histoire/' ),
            'target' => '',
            'attr_title' => '',
            'description' => '',
            'classes' => array(),
            'xfn' => '',
        );
        $items[] = $story;
    }
    return $items;
}
