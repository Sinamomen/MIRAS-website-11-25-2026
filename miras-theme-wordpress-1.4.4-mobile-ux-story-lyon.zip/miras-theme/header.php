<?php
/** Header template. @package MIRAS */
$home = home_url( '/' );
$nav_items = array(
    array( 'label' => 'Accueil', 'url' => $home ),
    array( 'label' => 'Menu', 'url' => home_url( '/composez-votre-commande/' ) ),
    array( 'label' => 'Abonnements', 'url' => $home . '#nos-abonnements' ),
    array( 'label' => 'NOTRE HISTOIRE', 'url' => home_url( '/notre-histoire/' ) ),
    array( 'label' => 'Contact', 'url' => home_url( '/contact/' ) ),
    array( 'label' => 'FAQ', 'url' => $home . '#faq' ),
);
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>><head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<link rel="preload" as="image" href="<?php echo esc_url( get_template_directory_uri() . '/assets/images/miras-hero-wide.webp' ); ?>" imagesrcset="<?php echo esc_url( get_template_directory_uri() . '/assets/images/miras-hero-wide-768.webp' ); ?> 768w, <?php echo esc_url( get_template_directory_uri() . '/assets/images/miras-hero-wide.webp' ); ?> 1280w" imagesizes="100vw">
<?php wp_head(); ?>
</head><body <?php body_class(); ?>><?php wp_body_open(); ?>
<header class="site-header">
  <div class="header-inner">
    <div class="wordmark">
      <?php if ( has_custom_logo() ) { the_custom_logo(); } else { ?><a href="<?php echo esc_url( $home ); ?>">MIRAS</a><?php } ?>
    </div>
    <div class="header-actions">
      <a class="header-account" href="<?php echo esc_url( function_exists('wc_get_page_permalink') ? wc_get_page_permalink('myaccount') : wp_login_url() ); ?>" aria-label="<?php esc_attr_e( 'Mon compte', 'miras' ); ?>"><span class="account-silhouette" aria-hidden="true"></span></a>
      <button class="nav-toggle" aria-label="<?php esc_attr_e( 'Ouvrir le menu', 'miras' ); ?>" aria-expanded="false" aria-controls="mainNav" id="navToggle"><span></span><span></span><span></span></button>
    </div>
    <nav class="main-nav" id="mainNav" aria-label="<?php esc_attr_e( 'Menu principal', 'miras' ); ?>">
      <div class="main-nav-inner">
        <div class="main-nav-emblem" aria-hidden="true"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/miras-lily-emblem.svg' ); ?>" alt="" width="96" height="96"></div>
        <ul>
          <?php foreach ( $nav_items as $index => $item ) : ?>
            <li class="nav-item-<?php echo esc_attr( $index + 1 ); ?>"><a href="<?php echo esc_url( $item['url'] ); ?>"><?php echo esc_html( $item['label'] ); ?><span class="nav-arrow" aria-hidden="true">↗</span></a></li>
          <?php endforeach; ?>
        </ul>
        <p class="main-nav-signature">Plus qu’un repas. Un héritage.</p>
      </div>
    </nav>
  </div>
</header>
