<?php
/**
 * Template for when no posts are found.
 *
 * @package MIRAS
 */
?>
<div class="container section">
    <h2><?php esc_html_e( 'Aucun contenu trouvé', 'miras' ); ?></h2>
    <p><?php esc_html_e( 'Désolé, aucun contenu ne correspond à votre recherche.', 'miras' ); ?></p>
</div>
