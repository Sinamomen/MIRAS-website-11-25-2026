<?php
/**
 * Default content template.
 *
 * @package MIRAS
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="container section">
        <?php if ( has_post_thumbnail() ) : ?>
            <div class="post-thumbnail"><?php the_post_thumbnail( 'large' ); ?></div>
        <?php endif; ?>
        <h1 class="entry-title"><?php the_title(); ?></h1>
        <div class="entry-content">
            <?php the_content(); ?>
        </div>
    </div>
</article>
